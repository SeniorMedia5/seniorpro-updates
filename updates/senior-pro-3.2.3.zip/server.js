'use strict';
/* ============================================================
   Senior Pro — Server
   - Document store (JSON per collection) on SQLite
   - Token authentication (bcrypt hashed passwords)
   - Explicit static file allowlist (never exposes DB/source)
   ============================================================ */

const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const path = require('path');
const os = require('os');
const { execFileSync } = require('child_process');

const APP_VERSION = require('./package.json').version;
const paths = require('./lib/paths');
const { applyMigrations } = require('./lib/migrations');
const updater = require('./lib/updater');

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const ROOT = __dirname;

/* ---------- Crash diagnostics (added after an unexplained silent exit) ----------
   Any fatal error is recorded to logs/crash.log BEFORE the process dies,
   so the owner can see exactly why the server stopped. */
(function installCrashLoggers() {
  const fsx = require('fs');
  function logCrash(kind, detail) {
    try {
      const dir = (typeof paths !== 'undefined' && paths.dirs && paths.dirs.logs) || __dirname;
      fsx.mkdirSync(dir, { recursive: true });
      fsx.appendFileSync(path.join(dir, 'crash.log'),
        `[${new Date().toISOString()}] ${kind}: ${detail}\n\n`, 'utf8');
    } catch (e) { /* never crash the crash logger */ }
  }
  process.on('uncaughtException', (err) => {
    logCrash('uncaughtException', (err && err.stack) || String(err));
    process.exit(1);
  });
  process.on('unhandledRejection', (reason) => {
    logCrash('unhandledRejection', (reason && reason.stack) || String(reason));
    /* rejection recorded; keep running like the default behavior of a handler */
  });
  process.on('exit', (code) => {
    if (code !== 0) logCrash('exit', `process exiting with code ${code}`);
  });
})();

/* Database lives in a fixed data dir outside the app folder.
   Migration from the old in-app senior.db happens on first run (in start()). */
let DB_FILE = null;
let DB_MIGRATED_FROM = null;
let db = null; // opened in start() after the data dir / migration is resolved
let server = null;

/* ---------- Collections ---------- */
const ARRAY_KEYS = [
  'customers', 'repairs', 'products', 'purchases', 'porders', 'sales',
  'suppliers', 'employees', 'installments', 'categories', 'orders',
  'quotes', 'returns', 'damages', 'backups'
];
const OBJECT_KEYS = ['settings', 'machine', 'license'];
const COLLECTION_KEYS = new Set([...ARRAY_KEYS, ...OBJECT_KEYS, 'users']);

const ALL_VIEWS = [
  'dashboard', 'customers', 'repairs', 'new-repair', 'devices', 'inventory',
  'damages', 'sales', 'installments', 'purchases', 'financial', 'reports', 'employees', 'settings'
];

const DEFAULT_SETTINGS = {
  company: 'Senior Pro',
  invPrefix: 'INV-',
  repPrefix: 'RP-',
  tax: 15,
  currency: 'جنيه مصري (ج.م)',
  cr: '',
  taxno: '',
  mobile: '01005171136',
  phone: '01279599146',
  address: 'مصر - اسكندرية'
};

/* ============================================================
   Hardware fingerprint
   Built from CPU / motherboard / BIOS / system UUID / fixed disks.
   Any change in one of these components produces a new fingerprint,
   which invalidates the previous license binding.
   ============================================================ */
const HW_PS_SCRIPT = [
  "$ErrorActionPreference = 'SilentlyContinue'",
  "$cpu = Get-CimInstance -ClassName Win32_Processor | Select-Object -First 1 -ExpandProperty ProcessorId",
  "$board = Get-CimInstance -ClassName Win32_BaseBoard | Select-Object -First 1",
  "$bios = Get-CimInstance -ClassName Win32_BIOS | Select-Object -First 1",
  "$sys = Get-CimInstance -ClassName Win32_ComputerSystemProduct | Select-Object -First 1",
  "$disks = Get-CimInstance -ClassName Win32_DiskDrive | Where-Object { $_.MediaType -match 'Fixed' } | ForEach-Object { $_.SerialNumber }",
  "[pscustomobject]@{",
  "  cpu = [string]$cpu",
  "  board = (@($board.Manufacturer, $board.Product, $board.SerialNumber) -join '|')",
  "  bios = (@($bios.Manufacturer, $bios.SMBIOSBIOSVersion, $bios.SerialNumber) -join '|')",
  "  uuid = [string]$sys.UUID",
  "  disks = (@($disks) -join ',')",
  "} | ConvertTo-Json -Compress"
].join('\n');

const HW_JUNK = /^(none|unknown|default string|to be filled by o\.e\.m\.?|o\.e\.m\.?|not specified|not applicable|n\/a|na|0+|serialnumber|system serial number|base board serial number|chassis serial number|invalid|no asset tag)$/i;

function cleanHwPart(value) {
  const s = String(value == null ? '' : value)
    .replace(/\u0000/g, '')
    .trim()
    .replace(/\s+/g, ' ');
  if (!s || HW_JUNK.test(s)) return '';
  return s.toUpperCase();
}

let HW_INFO_CACHE = null;
function readHardwareInfo() {
  if (HW_INFO_CACHE) return HW_INFO_CACHE;
  let info = {};
  if (process.platform === 'win32') {
    try {
      const out = execFileSync('powershell.exe', [
        '-NoProfile', '-NonInteractive', '-NoLogo', '-Command', HW_PS_SCRIPT
      ], { encoding: 'utf8', timeout: 12000, windowsHide: true });
      const start = out.indexOf('{');
      if (start >= 0) info = JSON.parse(out.slice(start));
    } catch (e) {
      info = {};
    }
  }
  HW_INFO_CACHE = (info && typeof info === 'object') ? info : {};
  return HW_INFO_CACHE;
}

function hardwareFingerprint() {
  const info = readHardwareInfo();
  const disks = String(info.disks || '')
    .split(',')
    .map(cleanHwPart)
    .filter(Boolean)
    .sort();

  const parts = [
    'cpu=' + cleanHwPart(info.cpu),
    'board=' + cleanHwPart(info.board),
    'bios=' + cleanHwPart(info.bios),
    'uuid=' + cleanHwPart(info.uuid),
    'disks=' + disks.join('+')
  ];

  const fromHardware = parts.some(p => !p.endsWith('='));
  if (!fromHardware) {
    // Non-Windows or restricted WMI: fall back to stable OS identifiers.
    parts.push(
      'os=' + cleanHwPart(os.platform() + ' ' + os.arch()),
      'host=' + cleanHwPart(os.hostname()),
      'cpuModel=' + cleanHwPart((os.cpus()[0] || {}).model || ''),
      'mem=' + Math.round(os.totalmem() / (1024 ** 3)) + 'GB'
    );
  }

  const digest = crypto.createHash('sha256')
    .update('SeniorPro|' + parts.join('|'))
    .digest('hex')
    .toUpperCase();

  return {
    id: (digest.match(/.{4}/g) || []).slice(0, 8).join('-'),
    source: fromHardware ? 'hardware' : 'os'
  };
}

let HW_FINGERPRINT = null;
function getFingerprint() {
  if (!HW_FINGERPRINT) HW_FINGERPRINT = hardwareFingerprint();
  return HW_FINGERPRINT;
}

/* ---------- sqlite helpers ---------- */
const run = (sql, params = []) => new Promise((resolve, reject) => {
  db.run(sql, params, function (err) { err ? reject(err) : resolve(this); });
});
const getRow = (sql, params = []) => new Promise((resolve, reject) => {
  db.get(sql, params, (err, row) => err ? reject(err) : resolve(row));
});

async function readDoc(key) {
  const row = await getRow('SELECT data FROM store WHERE key = ?', [key]);
  if (!row) return null;
  try { return JSON.parse(row.data); } catch (e) { return null; }
}

async function writeDoc(key, value) {
  await run(
    `INSERT INTO store (key, data, updated) VALUES (?, ?, ?)
     ON CONFLICT(key) DO UPDATE SET data = excluded.data, updated = excluded.updated`,
    [key, JSON.stringify(value), Date.now()]
  );
}

function defaultFor(key) {
  return ARRAY_KEYS.includes(key) ? [] : {};
}

/* ---------- users ---------- */
function publicUser(u) {
  if (!u) return null;
  const { passHash, ...safe } = u;
  return { ...safe, hasPass: !!passHash };
}

async function getUsers() {
  const users = await readDoc('users');
  return Array.isArray(users) ? users : [];
}

function httpError(status, message) {
  const err = new Error(message);
  err.status = status;
  return err;
}

/* ---------- sessions ---------- */
const SESSION_TTL = 30 * 24 * 60 * 60 * 1000; // 30 days
const sessions = new Map(); // token -> { username, exp }

function issueToken(username) {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { username, exp: Date.now() + SESSION_TTL });
  return token;
}

function bearer(req) {
  const h = req.get('authorization') || '';
  const m = h.match(/^Bearer\s+([a-f0-9]{64})$/i);
  return m ? m[1] : '';
}

async function auth(req, res, next) {
  try {
    const token = bearer(req);
    const s = token && sessions.get(token);
    if (!s || s.exp < Date.now()) {
      if (token) sessions.delete(token);
      return res.status(401).json({ error: 'انتهت الجلسة، يرجى تسجيل الدخول' });
    }
    const users = await getUsers();
    const user = users.find(u => String(u.user).toLowerCase() === String(s.username).toLowerCase());
    if (!user || user.status === 'موقوف') {
      sessions.delete(token);
      return res.status(401).json({ error: 'الحساب غير متاح' });
    }
    req.user = user;
    req.token = token;
    next();
  } catch (e) {
    next(e);
  }
}

function requireAdmin(req, res, next) {
  if (!req.user || req.user.role !== 'مدير النظام') {
    return res.status(403).json({ error: 'هذه العملية لمدير النظام فقط' });
  }
  next();
}

async function verifyPassword(pass, hash) {
  if (!hash) return false;
  if (String(hash).startsWith('$2')) return bcrypt.compare(pass, String(hash));
  // Backward compatibility with old unsalted SHA-256 hashes. Re-hashed on next password change.
  if (/^[a-f0-9]{64}$/i.test(String(hash))) {
    return crypto.createHash('sha256').update(String(pass)).digest('hex') === String(hash).toLowerCase();
  }
  return false;
}

/* ---------- login rate limit ---------- */
const loginAttempts = new Map(); // ip -> { count, first, blockedUntil }
const MAX_ATTEMPTS = 5;
const WINDOW_MS = 5 * 60 * 1000;

function loginBlocked(ip) {
  const a = loginAttempts.get(ip);
  if (!a) return 0;
  if (a.blockedUntil && a.blockedUntil > Date.now()) return a.blockedUntil - Date.now();
  if (a.first && Date.now() - a.first > WINDOW_MS) loginAttempts.delete(ip);
  return 0;
}

function noteLoginFailure(ip) {
  const now = Date.now();
  let a = loginAttempts.get(ip);
  if (!a || now - a.first > WINDOW_MS) a = { count: 0, first: now };
  a.count += 1;
  if (a.count >= MAX_ATTEMPTS) a.blockedUntil = now + WINDOW_MS;
  loginAttempts.set(ip, a);
}

/* ---------- middleware ---------- */
app.disable('x-powered-by');
app.use(express.json({ limit: '25mb' }));

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Cache-Control', req.path.startsWith('/api/') ? 'no-store' : 'no-cache');
  next();
});

/* ---------- public routes ---------- */
app.get('/api/health', (req, res) => res.json({ ok: true, time: Date.now(), version: APP_VERSION }));

app.post('/api/login', async (req, res, next) => {
  try {
    const ip = req.ip || req.socket.remoteAddress || 'unknown';
    const blocked = loginBlocked(ip);
    if (blocked) {
      return res.status(429).json({ error: 'محاولات كثيرة. حاول بعد ' + Math.ceil(blocked / 60000) + ' دقيقة' });
    }
    const { user, pass } = req.body || {};
    if (typeof user !== 'string' || typeof pass !== 'string' || !user.trim() || !pass) {
      return res.status(400).json({ error: 'يرجى إدخال اسم المستخدم وكلمة المرور' });
    }
    const users = await getUsers();
    const found = users.find(u => String(u.user).toLowerCase() === user.trim().toLowerCase());
    const ok = found && found.status !== 'موقوف' && await verifyPassword(pass, found.passHash);
    if (!ok) {
      noteLoginFailure(ip);
      return res.status(401).json({ error: 'اسم المستخدم أو كلمة المرور غير صحيحة' });
    }
    loginAttempts.delete(ip);
    res.json({ ok: true, token: issueToken(found.user), user: publicUser(found) });
  } catch (e) { next(e); }
});

/* ---------- authenticated routes ---------- */
app.get('/api/session', auth, (req, res) => {
  res.json({ ok: true, user: publicUser(req.user) });
});

// Hardware fingerprint used for license binding (never derived from the browser).
app.get('/api/machine-id', auth, (req, res) => {
  const fp = getFingerprint();
  res.json({ ok: true, id: fp.id, source: fp.source });
});

// License sheet endpoint (owner's Google Sheet via Apps Script).
// Public like /api/health: the client needs it right after login to report
// its fingerprint and pull its activation decision from the sheet.
app.get('/api/license-config', (req, res) => {
  let cfg = {};
  try { cfg = updater.readJsonNoBom(path.join(ROOT, 'update-config.json')); } catch (e) {}
  res.json({ ok: true, sheetUrl: String(cfg.licenseSheetUrl || '') });
});

app.post('/api/logout', auth, (req, res) => {
  sessions.delete(req.token);
  res.json({ ok: true });
});

/* users management (admin only) — must be declared before /api/:key */
app.post('/api/users', auth, requireAdmin, async (req, res, next) => {
  try {
    const b = req.body || {};
    const username = String(b.user || '').trim();
    if (!/^[A-Za-z0-9._-]{3,32}$/.test(username)) {
      return res.status(400).json({ error: 'اسم الدخول يجب أن يكون 3-32 حرفاً إنجليزياً أو رقماً' });
    }
    const users = await getUsers();
    const idx = users.findIndex(u => String(u.user).toLowerCase() === username.toLowerCase());
    const isNew = idx < 0;

    if (isNew && (!b.password || String(b.password).length < 6)) {
      return res.status(400).json({ error: 'كلمة المرور مطلوبة (6 أحرف على الأقل) للمستخدم الجديد' });
    }

    const isSelf = String(req.user.user).toLowerCase() === username.toLowerCase();
    if (isSelf && b.status === 'موقوف') {
      return res.status(400).json({ error: 'لا يمكنك إيقاف حسابك الحالي' });
    }
    if (isSelf && b.role && b.role !== req.user.role) {
      return res.status(400).json({ error: 'لا يمكنك تغيير دورك أثناء تسجيل الدخول' });
    }
    if (!isNew && users[idx].role === 'مدير النظام' && b.role && b.role !== 'مدير النظام') {
      const admins = users.filter(u => u.role === 'مدير النظام' && u.status !== 'موقوف');
      if (admins.length <= 1) return res.status(400).json({ error: 'يجب أن يبقى مدير نظام واحد على الأقل' });
    }

    const base = isNew ? { user: username, created: Date.now(), passHash: '' } : users[idx];
    const nextUser = {
      ...base,
      name: b.name !== undefined ? String(b.name).trim() : base.name,
      email: b.email !== undefined ? String(b.email).trim() : (base.email || ''),
      role: b.role || base.role || 'كاشير',
      status: b.status || base.status || 'نشط',
      perms: Array.isArray(b.perms) ? b.perms.filter(v => ALL_VIEWS.includes(v)) : (base.perms || [])
    };
    if (!nextUser.name) return res.status(400).json({ error: 'اسم المستخدم الكامل مطلوب' });
    if (b.password) {
      if (String(b.password).length < 6) return res.status(400).json({ error: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' });
      nextUser.passHash = await bcrypt.hash(String(b.password), 10);
    }

    if (isNew) users.push(nextUser); else users[idx] = nextUser;
    await writeDoc('users', users);
    res.json({ ok: true, user: publicUser(nextUser) });
  } catch (e) { next(e); }
});

app.delete('/api/users/:username', auth, requireAdmin, async (req, res, next) => {
  try {
    const target = String(req.params.username || '').toLowerCase();
    if (!target) return res.status(400).json({ error: 'اسم المستخدم مطلوب' });
    if (target === String(req.user.user).toLowerCase()) {
      return res.status(400).json({ error: 'لا يمكنك حذف حسابك الحالي' });
    }
    const users = await getUsers();
    const victim = users.find(u => String(u.user).toLowerCase() === target);
    if (!victim) return res.status(404).json({ error: 'المستخدم غير موجود' });
    if (victim.role === 'مدير النظام' && users.filter(u => u.role === 'مدير النظام').length <= 1) {
      return res.status(400).json({ error: 'لا يمكن حذف آخر مدير نظام' });
    }
    await writeDoc('users', users.filter(u => String(u.user).toLowerCase() !== target));
    res.json({ ok: true });
  } catch (e) { next(e); }
});

/* ============================================================
   Auto-update API (before the generic /api/:key routes)
   ============================================================ */
const fsSync = require('fs');
app.get('/api/update/status', auth, async (req, res) => {
  res.json({ ok: true, ...updater.status(), dbFile: DB_FILE, migratedFrom: DB_MIGRATED_FROM, backups: paths.listBackups() });
});

app.post('/api/update/check', auth, requireAdmin, async (req, res) => {
  const r = await updater.checkUpdate(true);
  res.json({ ok: r.ok, ...r, ...updater.status() });
});

app.post('/api/update/download', auth, requireAdmin, async (req, res) => {
  if (updater.status().phase === 'downloading') {
    return res.json({ ok: false, reason: 'التحميل جارٍ بالفعل', ...updater.status() });
  }
  // Respond immediately; progress is polled via /api/update/status.
  res.json({ ok: true, started: true });
  updater.downloadUpdate().catch(() => {});
});

app.post('/api/update/install', auth, requireAdmin, async (req, res) => {
  const st = updater.status();
  if (st.phase !== 'downloaded') {
    return res.status(400).json({ ok: false, error: 'لا توجد حزمة محمّلة ومتحقق منها' });
  }
  res.json({ ok: true, restarting: true });
  setTimeout(() => updater.installUpdate().catch(() => {}), 300);
});

app.post('/api/update/skip', auth, requireAdmin, (req, res) => {
  res.json({ ok: true, ...updater.skipVersion(), ...updater.status() });
});

app.get('/api/update/settings', auth, (req, res) => {
  res.json({ ok: true, feedUrl: updater.status().feedUrl });
});

app.put('/api/update/settings', auth, requireAdmin, async (req, res, next) => {
  try {
    const feed = String((req.body || {}).feedUrl || '').trim();
    if (feed && !/^https?:\/\/[^\s]+$/i.test(feed)) {
      return res.status(400).json({ ok: false, error: 'رابط مصدر التحديثات يجب أن يبدأ بـ http:// أو https://' });
    }
    const cfgFile = path.join(ROOT, 'update-config.json');
    let cfg = {};
    try { cfg = updater.readJsonNoBom(cfgFile); } catch (e) {}
    cfg.feed = feed;
    updater.writeFileHard(cfgFile, JSON.stringify(cfg, null, 2), 'utf8');
    updater.init({ APP_ROOT: ROOT, dbFile: DB_FILE, paths: paths.dirs, APP_VERSION, closeAll: shutdown });
    res.json({ ok: true, feedUrl: feed });
  } catch (e) { next(e); }
});

/* generic document store */
app.get('/api/:key', auth, async (req, res, next) => {
  try {
    const key = req.params.key;
    if (!COLLECTION_KEYS.has(key)) return res.status(404).json({ error: 'غير موجود' });
    if (key === 'users') {
      return res.json((await getUsers()).map(publicUser));
    }
    const doc = await readDoc(key);
    res.json(doc === null ? defaultFor(key) : doc);
  } catch (e) { next(e); }
});

const saveDoc = async (req, res, next) => {
  try {
    const key = req.params.key;
    if (key === 'users') return res.status(403).json({ error: 'استخدم واجهة إدارة المستخدمين' });
    if (!COLLECTION_KEYS.has(key)) return res.status(404).json({ error: 'غير موجود' });

    const value = req.body;
    if (ARRAY_KEYS.includes(key) && !Array.isArray(value)) {
      return res.status(400).json({ error: 'البيانات يجب أن تكون مصفوفة' });
    }
    if (OBJECT_KEYS.includes(key) && (value === null || typeof value !== 'object' || Array.isArray(value))) {
      return res.status(400).json({ error: 'البيانات يجب أن تكون كائناً' });
    }
    const size = Buffer.byteLength(JSON.stringify(value || null));
    if (size > 20 * 1024 * 1024) return res.status(413).json({ error: 'حجم البيانات كبير جداً' });

    await writeDoc(key, value);
    res.json({ ok: true });
  } catch (e) { next(e); }
};

app.put('/api/:key', auth, saveDoc);
// Backward-compatible alias for old clients.
app.post('/api/:key', auth, saveDoc);

app.delete('/api/:key', auth, requireAdmin, async (req, res, next) => {
  try {
    const key = req.params.key;
    if (!COLLECTION_KEYS.has(key)) return res.status(404).json({ error: 'غير موجود' });
    if (key === 'users') return res.status(403).json({ error: 'استخدم واجهة إدارة المستخدمين' });
    await run('DELETE FROM store WHERE key = ?', [key]);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

/* ---------- static allowlist ---------- */
/* No browser caching for app files: after every update the client MUST get
   the fresh code (stale cached JS/CSS breaks the UI after updates, because
   the old ?v= asset tags never changed). Localhost — cost is negligible. */
const NO_CACHE = (req, res, next) => { res.setHeader('Cache-Control', 'no-cache'); next(); };
const sendIndex = (req, res) => { res.setHeader('Cache-Control', 'no-cache'); res.sendFile(path.join(ROOT, 'index.html')); };
app.get('/', sendIndex);
app.get('/index.html', sendIndex);
app.get('/login.html', NO_CACHE, (req, res) => res.sendFile(path.join(ROOT, 'login.html')));
app.get('/senior-pro-logo.html', NO_CACHE, (req, res) => res.sendFile(path.join(ROOT, 'senior-pro-logo.html')));

app.use('/css', NO_CACHE, express.static(path.join(ROOT, 'css'), { fallthrough: false, etag: true }));
app.use('/js', NO_CACHE, express.static(path.join(ROOT, 'js'), { fallthrough: false, etag: true }));
app.use('/vendor', NO_CACHE, express.static(path.join(ROOT, 'vendor'), { fallthrough: false, etag: true }));
app.use('/icons', NO_CACHE, express.static(path.join(ROOT, 'icons'), { fallthrough: false, etag: true }));

/* ---------- errors & fallback ---------- */
app.use('/api', (req, res) => res.status(404).json({ error: 'مسار غير موجود' }));
app.use((req, res) => res.status(404).send('Not found'));

app.use((err, req, res, next) => {
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'صيغة JSON غير صحيحة' });
  }
  console.error(err);
  res.status(err.status || 500).json({ error: err.status ? err.message : 'خطأ داخلي في الخادم' });
});

/* ---------- start ---------- */
async function initDb() {
  await run(`CREATE TABLE IF NOT EXISTS store (
    key TEXT PRIMARY KEY,
    data TEXT NOT NULL,
    updated INTEGER NOT NULL
  )`);

  const users = await readDoc('users');
  if (!Array.isArray(users) || !users.length) {
    const password = process.env.ADMIN_PASSWORD || 'admin123';
    const passHash = await bcrypt.hash(password, 10);
    await writeDoc('users', [{
      user: 'admin',
      name: 'مدير النظام',
      role: 'مدير النظام',
      email: '',
      status: 'نشط',
      perms: ALL_VIEWS.slice(),
      passHash,
      created: Date.now()
    }]);
    console.log(`تم إنشاء حساب المدير الافتراضي: admin / ${password}`);
    if (password === 'admin123') console.log('⚠  غيّر كلمة المرور الافتراضية من شاشة المستخدمين.');
  }

  const settings = await readDoc('settings');
  if (!settings || typeof settings !== 'object' || Array.isArray(settings)) {
    await writeDoc('settings', DEFAULT_SETTINGS);
  }
}

/* ---------- Exclusive instance lock ----------
   On Windows two processes can silently bind the SAME port (SO_REUSEADDR),
   so a port test is NOT enough: two servers sharing one SQLite DB causes
   silent crashes. A lock file holding the live PID guarantees a single
   server per data dir. Stale locks (dead PID) are cleared automatically. */
function lockPath() { return path.join(paths.dirs.root, 'server.lock'); }
function pidAlive(pid) {
  if (!pid) return false;
  try { process.kill(pid, 0); return true; } catch (e) { return false; }
}
function acquireInstanceLock(retriesLeft) {
  const lf = lockPath();
  try {
    const fd = fsSync.openSync(lf, 'wx');
    fsSync.writeSync(fd, String(process.pid));
    fsSync.closeSync(fd);
    return true;
  } catch (e) {
    if (e.code !== 'EEXIST') return true; // best effort: never block startup on FS errors
    let pid = 0;
    try { pid = Number(fsSync.readFileSync(lf, 'utf8').trim()) || 0; } catch (err) {}
    if (pidAlive(pid)) {
      /* Another live server holds the lock. Wait briefly — covers the
         auto-update restart race (old process exits right after spawning us). */
      if (retriesLeft > 0) {
        const busy = new Promise((resolve) => setTimeout(() => resolve(acquireInstanceLock(retriesLeft - 1)), 400));
        return { wait: busy };
      }
      return false;
    }
    try { fsSync.unlinkSync(lf); } catch (err) {}
    return acquireInstanceLock(0); // stale lock cleared → retry immediately
  }
}
function releaseInstanceLock() {
  try {
    const pid = Number(fsSync.readFileSync(lockPath(), 'utf8').trim()) || 0;
    if (pid === process.pid) fsSync.unlinkSync(lockPath());
  } catch (e) { /* already gone */ }
}

async function start() {
  try {
    // 0) Single-instance guard (before touching the DB).
    paths.ensureDirs();
    const lockResult = acquireInstanceLock(10);
    if (lockResult && typeof lockResult === 'object' && lockResult.wait) {
      const finalResult = await lockResult.wait;
      if (finalResult !== true) {
        console.error('يوجد خادم Senior Pro يعمل بالفعل على نفس قاعدة البيانات — لن يُبدأ خادم ثانٍ.');
        process.exit(0);
      }
    } else if (lockResult !== true) {
      console.error('يوجد خادم Senior Pro يعمل بالفعل على نفس قاعدة البيانات — لن يُبدأ خادم ثانٍ.');
      process.exit(0);
    }
    process.on('exit', releaseInstanceLock);

    // 1) Resolve the data dir and migrate an old in-app DB if present.
    const info = await paths.resolveDatabase();
    DB_FILE = info.dbFile;
    DB_MIGRATED_FROM = info.migratedFrom;
    db = new sqlite3.Database(DB_FILE);

    // 2) Base table (needed by migrations), then schema migrations.
    await run(`CREATE TABLE IF NOT EXISTS store (
      key TEXT PRIMARY KEY,
      data TEXT NOT NULL,
      updated INTEGER NOT NULL
    )`);
    await applyMigrations(db);

    // 3) Seed defaults.
    await initDb();

    // 4) Auto-updater wiring + daily backup policy.
    updater.init({ APP_ROOT: paths.APP_ROOT, dbFile: DB_FILE, paths: paths.dirs, APP_VERSION, closeAll: shutdown });
    paths.dailyBackupIfNeeded(DB_FILE).catch(() => {});
    updater.startAutoCheck();

    // 5) Listen.
    server = app.listen(PORT, () => {
      console.log(`Senior Pro server running on http://localhost:${PORT}`);
      console.log(`App version: ${APP_VERSION}`);
      console.log(`Database: ${DB_FILE}`);
      if (DB_MIGRATED_FROM) console.log(`تم ترحيل قاعدة البيانات من: ${DB_MIGRATED_FROM}`);
      console.log(`مجلد البيانات: ${paths.dirs.root}`);
      try {
        const fp = getFingerprint();
        console.log(`Hardware fingerprint: ${fp.id} (${fp.source})`);
      } catch (e) {}
    });
    server.on('error', (err) => {
      if (err.code === 'EADDRINUSE') console.error(`المنفذ ${PORT} مستخدم بالفعل.`);
      else console.error(err);
      process.exit(1);
    });
  } catch (err) {
    console.error('تعذر تشغيل الخادم:', err.message);
    paths.logDb('فشل بدء التشغيل: ' + err.message);
    process.exit(1);
  }
}

start();

function shutdown() {
  try { if (server) server.close(); } catch (e) {}
  try { if (db) db.close(() => process.exit(0)); else process.exit(0); } catch (e) { process.exit(0); }
  setTimeout(() => process.exit(0), 2000).unref();
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
