'use strict';
/* ============================================================
   Senior Pro — Auto-update system test suite
   Runs REAL end-to-end scenarios on an ISOLATED copy of the app
   (temp dir, own data dir, own port, local mock update feed).
   Does NOT touch the real project or the real database.
   Usage: node scripts/test-updater.js
   ============================================================ */

const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const crypto = require('crypto');
const { execFile, spawn } = require('child_process');
const zip = require('../lib/zip');

const ROOT = path.resolve(__dirname, '..');
const TMP = path.join(os.tmpdir(), 'senior-upd-test-' + Date.now());

/* Kill orphaned servers from previous runs (they are detached after update-restart) */
function killOrphans() {
  try {
    const out = require('child_process').execSync(
      `powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \\"Name='node.exe'\\" | Where-Object { $_.CommandLine -match 'senior-upd-test' } | Select-Object -ExpandProperty ProcessId"`,
      { encoding: 'utf8', timeout: 15000 });
    String(out).split(/\s+/).filter(Boolean).forEach(pid => {
      try { process.kill(Number(pid), 'SIGKILL'); } catch (e) {}
    });
  } catch (e) {}
}

/* Random free port per run to avoid any collision */
const PORT = 30000 + Math.floor(Math.random() * 20000);
const FEED_PORT_BASE = 40000 + Math.floor(Math.random() * 5000);

const results = [];
function report(id, name, pass, detail) {
  results.push({ id, name, pass, detail });
  console.log(`${pass ? '✓' : '✗ FAIL'} T${id} ${name}${detail ? ' — ' + detail : ''}`);
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function copyApp(dest, version, extra) {
  const files = ['package.json', 'server.js', 'index.html', 'login.html', 'senior-pro-logo.html', 'update-config.json', 'desktop-launcher.js'];
  const dirs = ['js', 'css', 'vendor', 'icons', 'lib'];
  fs.mkdirSync(dest, { recursive: true });
  for (const f of files) {
    const src = path.join(ROOT, f);
    if (!fs.existsSync(src)) continue;
    if (f === 'package.json') {
      const p = JSON.parse(fs.readFileSync(src, 'utf8'));
      p.version = version;
      fs.writeFileSync(path.join(dest, f), JSON.stringify(p, null, 2));
    } else fs.copyFileSync(src, path.join(dest, f));
  }
  for (const d of dirs) fs.cpSync(path.join(ROOT, d), path.join(dest, d), { recursive: true });
  // Minimal node_modules (dependency-aware, like build-exe)
  const nm = path.join(dest, 'node_modules');
  fs.mkdirSync(nm, { recursive: true });
  const seen = new Set();
  const resolveDep = (name) => {
    if (seen.has(name)) return; seen.add(name);
    const src = path.join(ROOT, 'node_modules', name);
    if (!fs.existsSync(src)) return;
    fs.cpSync(src, path.join(nm, name), { recursive: true });
    try {
      const deps = JSON.parse(fs.readFileSync(path.join(src, 'package.json'), 'utf8')).dependencies || {};
      Object.keys(deps).forEach(d => resolveDep(d.startsWith('@') ? d.split('/')[0] : d));
    } catch (e) {}
  };
  ['express', 'sqlite3', 'bcryptjs'].forEach(resolveDep);
  (extra || []).forEach(f => fs.copyFileSync(f.src, path.join(dest, f.dest)));
}

function startServer(appDir, dataDir, env = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [path.join(appDir, 'server.js')], {
      cwd: appDir,
      env: { ...process.env, SENIOR_DATA_DIR: dataDir, PORT: String(PORT), ...env },
      stdio: ['ignore', 'pipe', 'pipe']
    });
    let out = '';
    const onData = (d) => {
      out += d.toString();
      if (out.includes('running on')) { child.stdout.removeAllListeners('data'); child.stderr.removeAllListeners('data'); resolve(child); }
    };
    child.stdout.on('data', onData);
    child.stderr.on('data', onData);
    child.on('exit', (code) => reject(new Error('server exited early: ' + code + '\n' + out)));
    setTimeout(() => reject(new Error('timeout waiting for server\n' + out)), 30000);
  });
}

function api(port, method, urlPath, token, body) {
  return new Promise((resolve, reject) => {
    const data = body ? JSON.stringify(body) : null;
    const req = http.request({
      host: '127.0.0.1', port, path: urlPath, method,
      headers: {
        ...(token ? { Authorization: 'Bearer ' + token } : {}),
        ...(data ? { 'Content-Type': 'application/json' } : {})
      }
    }, res => {
      let buf = '';
      res.on('data', d => buf += d);
      res.on('end', () => { try { resolve({ status: res.statusCode, json: JSON.parse(buf) }); } catch (e) { resolve({ status: res.statusCode, text: buf }); } });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

async function login(port) {
  const r = await api(port, 'POST', '/api/login', null, { user: 'admin', pass: 'admin123' });
  return r.json.token;
}

/* ---------- mock update feed ---------- */
function buildPackage(version, extraFiles = []) {
  const pkgPath = path.join(ROOT, 'package.json');
  const p = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  p.version = version;
  const entries = [];
  const addFile = (rel, data) => entries.push({ name: rel, data });
  addFile('package.json', JSON.stringify(p, null, 2));
  ['server.js', 'index.html', 'login.html', 'senior-pro-logo.html', 'update-config.json', 'desktop-launcher.js'].forEach(f => {
    const src = path.join(ROOT, f);
    if (fs.existsSync(src)) addFile(f, fs.readFileSync(src));
  });
  ['js', 'css', 'vendor', 'icons', 'lib'].forEach(d => {
    (function walk(cur, rel) {
      for (const e of fs.readdirSync(cur, { withFileTypes: true })) {
        const relPath = rel ? rel + '/' + e.name : e.name;
        const abs = path.join(cur, e.name);
        if (e.isDirectory()) walk(abs, relPath);
        else addFile(relPath, fs.readFileSync(abs));
      }
    })(path.join(ROOT, d), d);
  });
  (extraFiles || []).forEach(f => addFile(f.name, f.data));
  return zip.pack(entries);
}

function startFeed(manifest, zipBuf, feedPort) {
  const server = http.createServer((req, res) => {
    if (req.url.endsWith('update-manifest.json')) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(manifest));
    } else if (req.url.includes('.zip')) {
      res.writeHead(200, { 'Content-Type': 'application/zip', 'Content-Length': zipBuf.length });
      res.end(zipBuf);
    } else { res.writeHead(404); res.end(); }
  });
  return new Promise(resolve => server.listen(feedPort, '127.0.0.1', () => resolve(server)));
}

function signManifest(m) {
  const key = fs.readFileSync(path.join(ROOT, 'keys', 'release-private.pem'), 'utf8');
  const data = [m.product || 'SeniorManagement', m.version, m.date || '', m.channel || 'stable', m.package, m.sha256, m.size || 0].join('|');
  m.signature = crypto.sign(null, Buffer.from(data, 'utf8'), crypto.createPrivateKey(key)).toString('base64');
}

(async () => {
  console.log('مجلد الاختبار المعزول:', TMP);
  const APP = path.join(TMP, 'app');
  const DATA = path.join(TMP, 'data');
  const FEED = path.join(TMP, 'feed');
  let newToken = null;

  /* ============ T1: DB migration from the app folder ============ */
  // Build an "old install": app dir with a legacy senior.db holding real data.
  copyApp(APP, '3.1.0');
  const legacyDb = path.join(APP, 'senior.db');
  {
    // Create the legacy DB with seed data via seed.js in a temp data mode
    // Instead: run the test app once to create DB, insert data via API, then restart-copy.
    const s1 = await startServer(APP, path.join(TMP, 'data-seed'));
    const t1 = await login(PORT);
    await api(PORT, 'PUT', '/api/customers', t1, [{ name: 'عميل اختبار الترحيل', phone: '0100000000', debt: 250, repairs: 0, payments: 0, type: 'عميل جديد' }]);
    await api(PORT, 'PUT', '/api/products', t1, [{ name: 'شاشة اختبار', cat: 'شاشات', buy: 400, sell: 600, qty: 5, low: 1 }]);
    childExit(s1);
    await sleep(500);
    // "Old install" now: legacy db sits in the APP folder (like the current real project)
    fs.copyFileSync(path.join(TMP, 'data-seed', 'data', 'senior.db'), legacyDb);
  }

  let srv;
  try {
    srv = await startServer(APP, DATA);
    const out = srv.stdout ? '' : '';
    // Migration should have moved the DB into DATA/data
    const migrated = fs.existsSync(path.join(DATA, 'data', 'senior.db'));
    const token = await login(PORT);
    const customers = await api(PORT, 'GET', '/api/customers', token);
    const okData = Array.isArray(customers.json) && customers.json.some(c => c.name === 'عميل اختبار الترحيل');
    const products = await api(PORT, 'GET', '/api/products', token);
    const okProd = Array.isArray(products.json) && products.json.some(p => p.name === 'شاشة اختبار');
    const preMigrationBackup = fs.existsSync(path.join(DATA, 'backups')) && fs.readdirSync(path.join(DATA, 'backups')).some(f => f.startsWith('pre-migration-'));
    report(1, 'ترحيل قاعدة البيانات القديمة إلى مجلد البيانات', migrated && okData && okProd && preMigrationBackup,
      `db في data dir: ${migrated}، بيانات العملاء سليمة: ${okData}، المنتجات سليمة: ${okProd}، نسخة ما قبل الترحيل: ${preMigrationBackup}`);
    const legacyStillThere = fs.existsSync(legacyDb); // original kept untouched
    report(1.1, 'الملف القديم لم يُحذف (نسخة إضافية)', legacyStillThere);

    /* ============ T2: feed not configured ============ */
    {
      const r = await api(PORT, 'POST', '/api/update/check', token);
      report(2, 'عدم ضبط مصدر التحديثات → رسالة واضحة دون انهيار',
        r.json.ok === false && String(r.json.error || '').includes('لم يتم ضبط'),
        `error=${r.json.error}, feedUrl=${r.json.feedUrl}`);
    }

    /* ============ T3: no new version available ============ */
    const pkgSame = buildPackage('3.1.0');
    const manifestSame = { product: 'SeniorManagement', version: '3.1.0', date: '2026-11-15', channel: 'stable', package: 'senior-pro-3.1.0.zip', sha256: crypto.createHash('sha256').update(pkgSame).digest('hex'), size: pkgSame.length, notes: [] };
    signManifest(manifestSame);
    const feed1 = await startFeed(manifestSame, pkgSame, FEED_PORT_BASE);
    await api(PORT, 'PUT', '/api/update/settings', token, { feedUrl: 'http://127.0.0.1:' + FEED_PORT_BASE + '/update-manifest.json' });
    {
      const r = await api(PORT, 'POST', '/api/update/check', token);
      report(3, 'لا توجد تحديثات (نفس الإصدار)', r.json.ok === true && r.json.available === false && r.json.phase === 'up-to-date', `phase=${r.json.phase}`);
    }
    feed1.close();

    /* ============ T4: update available + What's New ============ */
    const MARKER = 'UPD_MARKER-3.2.0-' + crypto.randomBytes(3).toString('hex');
    const pkgNew = buildPackage('3.2.0', [{ name: 'update-test/marker.txt', data: Buffer.from(MARKER) }]);
    const manifestNew = { product: 'SeniorManagement', version: '3.2.0', date: '2026-11-15', channel: 'stable', package: 'senior-pro-3.2.0.zip', sha256: crypto.createHash('sha256').update(pkgNew).digest('hex'), size: pkgNew.length, notes: ['ميزة جديدة رقم 1', 'ميزة جديدة رقم 2'] };
    signManifest(manifestNew);
    const feed2 = await startFeed(manifestNew, pkgNew, FEED_PORT_BASE + 1);
    await api(PORT, 'PUT', '/api/update/settings', token, { feedUrl: 'http://127.0.0.1:' + (FEED_PORT_BASE + 1) + '/update-manifest.json' });
    {
      const r = await api(PORT, 'POST', '/api/update/check', token);
      report(4, 'اكتشاف إصدار جديد + ملاحظات What\'s New',
        r.json.ok && r.json.available === true && r.json.version === '3.2.0' && r.json.notes && r.json.notes.length === 2,
        `phase=${r.json.phase}, latest=${r.json.latest ? r.json.latest.version : null}, feedUrl=${r.json.feedUrl}, err=${r.json.lastCheckError}`);
    }

    /* ============ T5: download with progress + hash verification ============ */
    {
      const s = await api(PORT, 'POST', '/api/update/download', token);
      if (!s.json.ok) { report(5, 'بدء التحميل', false, String(s.json.reason)); }
      let done = null;
      for (let i = 0; i < 60; i++) {
        await sleep(300);
        const st = await api(PORT, 'GET', '/api/update/status', token);
        done = st.json;
        if (st.json.phase === 'downloaded' || st.json.phase === 'error') break;
      }
      const pkgFile = path.join(DATA, 'updates', 'package-3.2.0.zip');
      const downloaded = done && done.phase === 'downloaded' && fs.existsSync(pkgFile);
      report(5, 'تحميل الحزمة والتحقق من SHA256', !!downloaded, `phase=${done && done.phase}`);

      /* ============ T6: corrupted package is rejected (digest mismatch) ============ */
      const badPkg = Buffer.from(pkgNew); badPkg[100] = badPkg[100] ^ 0xFF;
      // Manifest still declares the GOOD sha256 — the served bytes were tampered with.
      const feed3 = await startFeed(manifestNew, badPkg, FEED_PORT_BASE + 2);
      await api(PORT, 'PUT', '/api/update/settings', token, { feedUrl: 'http://127.0.0.1:' + (FEED_PORT_BASE + 2) + '/update-manifest.json' });
      await api(PORT, 'POST', '/api/update/check', token); // phase = available again
      // phase = available again (3.2.0 > 3.1.0)
      await api(PORT, 'POST', '/api/update/download', token);
      let badRejected = false;
      for (let i = 0; i < 40; i++) {
        await sleep(300);
        const st = await api(PORT, 'GET', '/api/update/status', token);
        if (st.json.phase === 'error') { badRejected = true; break; }
        if (st.json.phase === 'downloaded') break;
      }
      feed3.close();
      report(6, 'رفض حزمة تالفة (فشل SHA256)', badRejected);
      // Re-download the good one for T7
      feed2.close();

      /* ============ T7: install & restart ============ */
      const feed2b = await startFeed(manifestNew, pkgNew, FEED_PORT_BASE + 1);
      await api(PORT, 'PUT', '/api/update/settings', token, { feedUrl: 'http://127.0.0.1:' + (FEED_PORT_BASE + 1) + '/update-manifest.json' });
      await api(PORT, 'POST', '/api/update/check', token);
      await api(PORT, 'POST', '/api/update/download', token);
      let ready = false;
      for (let i = 0; i < 60; i++) {
        await sleep(300);
        const st = await api(PORT, 'GET', '/api/update/status', token);
        if (st.json.phase === 'downloaded') { ready = true; break; }
        if (st.json.phase === 'error') break;
      }
      report(7.1, 'إعادة تحميل الحزمة السليمة', ready);
      if (ready) {
        let preUpdateBackupExists = false;
        await api(PORT, 'POST', '/api/update/install', token);
        // wait for restart: server should go down then come back with version 3.2.0
        let newSrv = null, version = null, restarted = false;
        for (let i = 0; i < 40; i++) {
          await sleep(500);
          try {
            const h = await new Promise((resolve, reject) => {
              const req = http.get({ host: '127.0.0.1', port: PORT, path: '/api/health' }, res => { let b = ''; res.on('data', d => b += d); res.on('end', () => resolve(JSON.parse(b))); });
              req.on('error', reject); req.setTimeout(2000, () => { req.destroy(); reject(new Error('t')); });
            });
            if (h.version === '3.2.0') { version = h.version; restarted = true; break; }
          } catch (e) { /* not up yet */ }
        }
        // data preserved?
        let dataOk = false;
        try {
          newToken = await login(PORT);
          const customers = await api(PORT, 'GET', '/api/customers', newToken);
          dataOk = Array.isArray(customers.json) && customers.json.some(c => c.name === 'عميل اختبار الترحيل');
        } catch (e) { dataOk = false; }
        const markerOk = fs.existsSync(path.join(APP, 'update-test', 'marker.txt')) && fs.readFileSync(path.join(APP, 'update-test', 'marker.txt'), 'utf8') === MARKER;
        preUpdateBackupExists = fs.readdirSync(path.join(DATA, 'backups')).some(f => f.startsWith('pre-update-'));
        report(7, 'تثبيت التحديث وإعادة التشغيل التلقائي', restarted && version === '3.2.0', `version=${version}`);
        report(7.2, 'بقاء بيانات العملاء بعد التحديث', dataOk);
        report(7.3, 'ملفات التحديث الجديدة مثبتة (marker)', markerOk);
        report(7.4, 'نسخة احتياطية قبل التحديث', preUpdateBackupExists);
        // T8: skip/postpone (requires a completed check on the NEW server instance)
        try {
          const chk = await api(PORT, 'POST', '/api/update/check', newToken);
          const sk = await api(PORT, 'POST', '/api/update/skip', newToken);
          const skippedFile = fs.existsSync(path.join(DATA, 'skipped-version.txt'));
          report(8, 'تأجيل إصدار', sk.json.ok === true && skippedFile,
            `check(phase=${chk.json.phase}, latest=${chk.json.latest ? chk.json.latest.version : 'null'}) → skip=${JSON.stringify(sk.json.skipped || sk.json.reason || '')}`);
        } catch (e) { report(8, 'تأجيل إصدار', false, e.message); }
      }
      feed2b.close();
    }

    childExit(srv);
  } catch (e) {
    report(0, 'تشغيل نسخة الاختبار', false, e.message);
    try { srv && childExit(srv); } catch (e2) {}
  }

  /* ============ T9: corrupted legacy DB is NOT migrated over ============ */
  try {
    const APP2 = path.join(TMP, 'app-corrupt');
    const DATA2 = path.join(TMP, 'data-corrupt');
    copyApp(APP2, '3.1.0');
    fs.writeFileSync(path.join(APP2, 'senior.db'), Buffer.from('هذا الملف ليس قاعدة بيانات'.repeat(50), 'utf8'));
    const p = spawn(process.execPath, [path.join(APP2, 'server.js')], { cwd: APP2, env: { ...process.env, SENIOR_DATA_DIR: DATA2, PORT: String(PORT + 1) }, stdio: 'ignore' });
    let exitedWithMsg = false;
    p.on('exit', () => { exitedWithMsg = true; });
    await sleep(6000);
    // Either it exits with the safety error or refuses to create an empty DB over it.
    const noEmptyDb = !fs.existsSync(path.join(DATA2, 'data', 'senior.db'));
    try { p.kill(); } catch (e) {}
    report(9, 'قاعدة بيانات قديمة تالفة → لن تُنشأ قاعدة فارغة فوقها', noEmptyDb);
  } catch (e) { report(9, 'قاعدة بيانات قديمة تالفة', false, e.message); }

  /* ============ T10: feed down / wrong URL handled gracefully ============ */
  {
    const APP3 = path.join(TMP, 'app-badfeed');
    const DATA3 = path.join(TMP, 'data-badfeed');
    copyApp(APP3, '3.1.0');
    fs.writeFileSync(path.join(APP3, 'update-config.json'), JSON.stringify({ feed: 'http://127.0.0.1:' + (FEED_PORT_BASE + 999) + '/update-manifest.json', publicKey: JSON.parse(fs.readFileSync(path.join(ROOT, 'update-config.json'), 'utf8')).publicKey }));
    const p = spawn(process.execPath, [path.join(APP3, 'server.js')], { cwd: APP3, env: { ...process.env, SENIOR_DATA_DIR: DATA3, PORT: String(PORT + 2) }, stdio: 'ignore' });
    let alive = true;
    p.on('exit', () => { alive = false; });
    await sleep(6000);
    report(10, 'مصدر تحديثات غير متصل → الخادم يعمل طبيعياً', alive);
    try { p.kill(); } catch (e) {}
  }

  /* ============ summary ============ */
  const passed = results.filter(r => r.pass).length;
  console.log(`\n===== النتيجة: ${passed}/${results.length} اختبار ناجح =====`);
  if (passed !== results.length) process.exitCode = 1;
  fs.writeFileSync(path.join(TMP, 'results.json'), JSON.stringify(results, null, 2));
})().catch(e => { console.error('خطأ في سكربت الاختبار:', e); process.exitCode = 1; });

function childExit(child) { try { child.kill(); } catch (e) {} }