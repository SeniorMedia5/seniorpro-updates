'use strict';
/* ============================================================
   Senior Pro — Publish tool (uploads a release to GitHub)
   Prerequisite: npm run release has built dist/ files.
   Usage:
     npm run publish
     node scripts/publish.js --repo Owner/name   (first time)
   What it does:
     1. Clones/refreshes the updates repo into
        %LOCALAPPDATA%\SeniorManagement\gh-repo
     2. Copies dist/senior-pro-<ver>.zip + dist/update-manifest.json
        into the repo's updates/ folder.
     3. Commits + pushes. The feed URL (raw.githubusercontent)
        then serves the new manifest to all clients.
     4. Verifies the live manifest is reachable & signature-valid.
   The repo must be PUBLIC (clients fetch it without auth).
   ============================================================ */

const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'update-config.json'), 'utf8'));
const version = require(path.join(ROOT, 'package.json')).version;

function findGh() {
  if (process.env.GH_EXE && fs.existsSync(process.env.GH_EXE)) return process.env.GH_EXE;
  const candidates = [
    path.join(process.env.LOCALAPPDATA || '', 'Programs', 'gh-cli', 'bin', 'gh.exe'),
    'gh.exe'
  ].filter(Boolean);
  for (const c of candidates) {
    try { execFileSync(c, ['--version'], { stdio: 'ignore' }); return c; } catch (e) {}
  }
  return null;
}

function git(dir, args) {
  return execFileSync('git', args, { cwd: dir, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }).trim();
}

/* args */
let repoArg = null;
process.argv.slice(2).forEach((a, i, arr) => { if (a === '--repo') repoArg = arr[i + 1]; });
const repo = repoArg || cfg.repo;
if (!repo || !repo.includes('/')) {
  console.error('حدد المستودع أول مرة: node scripts/publish.js --repo Owner/name');
  process.exit(1);
}
if (!cfg.repo || cfg.repo !== repo) {
  cfg.repo = repo;
  fs.writeFileSync(path.join(ROOT, 'update-config.json'), JSON.stringify(cfg, null, 2), 'utf8');
}

const gh = findGh();
if (!gh) { console.error('✗ لم أجد gh.exe — ثبّت GitHub CLI'); process.exit(1); }

const owner = repo.split('/')[0];
const FEED = `https://raw.githubusercontent.com/${repo}/main/updates/update-manifest.json`;

const zipFile = path.join(ROOT, 'dist', `senior-pro-${version}.zip`);
const manifestFile = path.join(ROOT, 'dist', 'update-manifest.json');
if (!fs.existsSync(zipFile) || !fs.existsSync(manifestFile)) {
  console.error(`✗ ملفات dist ناقصة — نفّذ أولاً: npm run release -- --version ${version} --notes "..." --feed ${FEED}`);
  process.exit(1);
}

/* 1) ensure clone */
const cloneDir = path.join(process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'),
  'SeniorManagement', 'gh-repo');
if (!fs.existsSync(path.join(cloneDir, '.git'))) {
  fs.rmSync(cloneDir, { recursive: true, force: true });
  fs.mkdirSync(path.dirname(cloneDir), { recursive: true });
  console.log('استنساخ المستودع...');
  execFileSync(gh, ['repo', 'clone', repo, cloneDir, '--', '--depth', '1'], { stdio: 'inherit' });
} else {
  git(cloneDir, ['fetch', 'origin']);
  try { git(cloneDir, ['reset', '--hard', 'origin/main']); } catch (e) { git(cloneDir, ['checkout', 'main']); }
}

/* 2) copy release files */
const updatesDir = path.join(cloneDir, 'updates');
fs.mkdirSync(updatesDir, { recursive: true });
fs.copyFileSync(zipFile, path.join(updatesDir, path.basename(zipFile)));
fs.copyFileSync(manifestFile, path.join(updatesDir, 'update-manifest.json'));

/* 3) commit + push */
git(cloneDir, ['add', '.']);
let hasChanges = true;
try {
  git(cloneDir, ['diff', '--cached', '--quiet']);
  hasChanges = false; // exit 0 = nothing staged
} catch (e) { /* exit 1 = changes staged */ }

if (hasChanges) {
  git(cloneDir, ['commit', '-m', `Release ${version}`]);
  console.log('رفع التحديث إلى GitHub...');
  git(cloneDir, ['push', 'origin', 'main']);
  console.log(`✓ تم رفع الإصدار ${version}`);
} else {
  console.log('ℹ لا تغييرات — هذا الإصدار مرفوع بالفعل');
}

console.log('');
console.log('=== رابط مصدر التحديثات (Feed URL) ===');
console.log(FEED);
console.log('');
console.log('يجب أن يكون في update-config.json لدى كل العملاء — وسيأتي مدمجاً في التحديث القادم تلقائياً.');

/* 4) verify live manifest (raw CDN may lag ~1 min) */
(async () => {
  for (let i = 0; i < 12; i++) {
    try {
      const res = await fetch(FEED + '?nocache=' + Date.now());
      if (res.ok) {
        const m = JSON.parse(await res.text());
        if (m.version === version) {
          // signature check with the embedded public key
          const data = [m.product, m.version, m.date, m.channel, m.package, m.sha256, m.size].join('|');
          const ok = crypto.verify(null, Buffer.from(data), crypto.createPublicKey(cfg.publicKey), Buffer.from(m.signature, 'base64'));
          console.log(`✓ البيان منشور ومتاح على الإنترنت (v${m.version}، التوقيع ${ok ? 'سليم ✓' : 'فاسد ✗'})`);
          return;
        }
      }
    } catch (e) {}
    await new Promise(r => setTimeout(r, 10000));
  }
  console.warn('⚠ لم أستطع التحقق من الرابط بعد (قد يتأخر CDN دقيقة) — جرّب فتح الرابط لاحقاً.');
})();
