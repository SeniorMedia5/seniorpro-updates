'use strict';
/* ============================================================
   Senior Pro — Desktop launcher (used by the EXE build)
   1. If the server is ALREADY running (e.g. background instance),
      just open another app window and exit — the user always
      gets a window when they double-click the shortcut.
   2. Otherwise start the server, wait for readiness, then open
      the app in a STANDALONE application window (Edge/Chrome
      "app mode"): no address bar, no tabs, no browser UI.
   Falls back to the default browser if no app-mode browser.
   ============================================================ */

const { spawn, exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const http = require('http');

const PORT = process.env.PORT || 3000;
const APP_URL = 'http://localhost:' + PORT;

/* Candidate browsers in order of preference (Edge ships with Windows). */
function findAppBrowser() {
  const env = process.env;
  const candidates = [
    path.join(env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(env['ProgramFiles'] || 'C:\\Program Files', 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(env.LOCALAPPDATA || '', 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(env['ProgramFiles'] || 'C:\\Program Files', 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'Google', 'Chrome', 'Application', 'chrome.exe'),
    path.join(env.LOCALAPPDATA || '', 'Google', 'Chrome', 'Application', 'chrome.exe')
  ];
  return candidates.find(p => p && fs.existsSync(p)) || null;
}

/* Open the standalone application window (own taskbar icon). */
function openWindow() {
  const browser = findAppBrowser();
  if (browser) {
    try {
      spawn(browser, ['--app=' + APP_URL, '--window-size=1400,900'], {
        detached: true, stdio: 'ignore'
      }).unref();
      console.log('تم فتح البرنامج في نافذة مستقلة');
      return true;
    } catch (e) { /* fall through */ }
  }
  try { exec('cmd /c start "" "' + APP_URL + '"'); } catch (e) {
    console.log('افتح المتصفح على: ' + APP_URL);
  }
  return false;
}

/* Already running? → open a window for it and let this instance go. */
http.get(APP_URL + '/api/health', (res) => {
  res.resume();
  if (res.statusCode === 200) {
    console.log('الخادم يعمل بالفعل — فتح نافذة للنسخة العاملة');
    openWindow();
    process.exit(0); // window lives in its own Edge process
  }
  /* non-200: treat as broken server below */
  startFresh();
}).on('error', startFresh);

let started = false;
function startFresh() {
  if (started) return;
  started = true;
  /* Quick retries: a running server may be briefly busy (startup/backup) —
     never spawn a second one because of a transient check failure. */
  let tries = 0;
  (function recheck() {
    http.get(APP_URL + '/api/health', (res) => {
      res.resume();
      if (res.statusCode === 200) { openWindow(); process.exit(0); return; }
      if (++tries < 3) setTimeout(recheck, 400);
      else bootServer();
    }).on('error', () => {
      if (++tries < 3) setTimeout(recheck, 400);
      else bootServer();
    });
  })();
}

function bootServer() {
  require('./server.js'); // starts the local server (single-instance locked)

  /* Wait until the server answers, then open the app window. */
  (function waitAndOpen(attempt) {
    attempt = attempt || 0;
    http.get(APP_URL + '/api/health', (res) => {
      res.resume();
      if (res.statusCode === 200) { openWindow(); return; }
      if (attempt < 50) setTimeout(() => waitAndOpen(attempt + 1), 300);
      else console.error('تعذر الاتصال بالخادم');
    }).on('error', () => {
      if (attempt < 50) setTimeout(() => waitAndOpen(attempt + 1), 300);
      else console.error('تعذر الاتصال بالخادم');
    });
  })();
}
