'use strict';
/* ============================================================
   Senior Pro — Release tool
   Usage:
     node scripts/release.js --version 3.3.0 --notes "ميزة أ؛ ميزة ب" [--feed URL]
   What it does:
     1. Bumps package.json version.
     2. Packs the application files into dist/<package>.zip
        (excludes: DB, node_modules, keys, dist, logs, data).
     3. Computes SHA256 + Ed25519 signature with keys/release-private.pem.
     4. Writes dist/update-manifest.json ready to upload to the feed.
   ============================================================ */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zip = require('../lib/zip');

const ROOT = path.resolve(__dirname, '..');
const pkg = require(path.join(ROOT, 'package.json'));

/* Files/folders included in an update package */
const INCLUDE_FILES = [
  'package.json', 'server.js', 'seed.js', 'index.html', 'login.html',
  'senior-pro-logo.html', 'update-config.json', 'README.md',
  'desktop-launcher.js', 'run-silent.vbs'
];
const INCLUDE_DIRS = ['js', 'css', 'vendor', 'icons', 'lib', 'scripts'];
const EXCLUDE_FILES = [
  'license-generator.html',          // never publish the owner's key tool
  'senior.db', 'update-manifest.json'
];
const EXCLUDE_RX = [/^senior\.db/i, /^\.git/i, /^\.env$/i, /^keys[\\\/]/i, /^dist[\\\/]/i, /^data[\\\/]/i, /^node_modules[\\\/]/];

function args() {
  const out = {};
  process.argv.slice(2).forEach((a, i, arr) => {
    if (a.startsWith('--')) out[a.slice(2)] = arr[i + 1] && !arr[i + 1].startsWith('--') ? arr[i + 1] : true;
  });
  return out;
}

function collectFiles() {
  const files = [];
  for (const f of INCLUDE_FILES) {
    const p = path.join(ROOT, f);
    if (fs.existsSync(p)) files.push({ rel: f, abs: p });
  }
  for (const d of INCLUDE_DIRS) {
    const dir = path.join(ROOT, d);
    if (!fs.existsSync(dir)) continue;
    (function walk(cur, rel) {
      for (const e of fs.readdirSync(cur, { withFileTypes: true })) {
        const relPath = rel ? rel + '/' + e.name : e.name;
        if (EXCLUDE_RX.some(rx => rx.test(relPath))) continue;
        if (EXCLUDE_FILES.includes(e.name)) continue;
        const abs = path.join(cur, e.name);
        if (e.isDirectory()) walk(abs, relPath);
        else files.push({ rel: relPath, abs });
      }
    })(dir, d);
  }
  return files;
}

function sign(data, keyFile) {
  if (!fs.existsSync(keyFile)) {
    console.error('✗ لا يوجد مفتاح توقيع: ' + keyFile);
    console.error('  أنشئه مرة واحدة: node -e "..." أو انسخ keys/release-private.pem بأمان.');
    process.exit(1);
  }
  const key = fs.readFileSync(keyFile, 'utf8');
  return crypto.sign(null, Buffer.from(data, 'utf8'), crypto.createPrivateKey(key)).toString('base64');
}

(async () => {
  const a = args();
  const version = a.version ? String(a.version).trim() : null;
  if (!version || !/^\d+\.\d+\.\d+$/.test(version)) {
    console.error('الاستخدام: node scripts/release.js --version 3.3.0 --notes "..." [--feed URL]');
    process.exit(1);
  }
  const notes = a.notes ? String(a.notes).split(/[؛;]/).map(s => s.trim()).filter(Boolean) : [];
  const feed = a.feed ? String(a.feed) : null;

  // 1) Bump version
  pkg.version = version;
  fs.writeFileSync(path.join(ROOT, 'package.json'), JSON.stringify(pkg, null, 2) + '\n', 'utf8');
  console.log(`✓ رقم الإصدار في package.json → ${version}`);

  // 2) Feed URL into update-config.json FIRST (so the package contains the final file)
  if (feed) {
    const cfgPath = path.join(ROOT, 'update-config.json');
    let cfgText = fs.readFileSync(cfgPath, 'utf8');
    if (cfgText.charCodeAt(0) === 0xFEFF) cfgText = cfgText.slice(1);
    const cfg = JSON.parse(cfgText);
    cfg.feed = feed;
    fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2), 'utf8');
    console.log('✓ رابط مصدر التحديثات في update-config.json → ' + feed);
  }

  // 3) Build the package zip (single build — hashes always match contents)
  const dist = path.join(ROOT, 'dist');
  fs.mkdirSync(dist, { recursive: true });
  const packageName = `senior-pro-${version}.zip`;
  const packagePath = path.join(dist, packageName);
  const files = collectFiles();
  const buf = zip.pack(files.map(f => ({ name: f.rel, data: fs.readFileSync(f.abs) })));
  fs.writeFileSync(packagePath, buf);
  const sha256 = crypto.createHash('sha256').update(buf).digest('hex');
  console.log(`✓ الحزمة: dist/${packageName} (${files.length} ملف، ${(buf.length / 1048576).toFixed(2)} MB)`);

  // 4) Per-file hashes for deep verification
  const fileHashes = {};
  for (const f of files) {
    fileHashes[f.rel] = crypto.createHash('sha256').update(fs.readFileSync(f.abs)).digest('hex');
  }

  const manifest = {
    product: 'SeniorManagement',
    version,
    date: new Date().toISOString().slice(0, 10),
    channel: 'stable',
    minSupported: '3.0.0',
    notes,
    package: packageName,
    sha256,
    size: buf.length,
    files: fileHashes
  };
  manifest.signature = sign([manifest.product, manifest.version, manifest.date, manifest.channel, manifest.package, manifest.sha256, manifest.size].join('|'), path.join(ROOT, 'keys', 'release-private.pem'));

  fs.writeFileSync(path.join(dist, 'update-manifest.json'), JSON.stringify(manifest, null, 2), 'utf8');
  console.log('✓ البيان: dist/update-manifest.json (موقّع Ed25519)');

  console.log('\n=== خطوات النشر ===');
  console.log('1. ارفع الملفين إلى مجلد الإصدارات في الاستضافة:');
  console.log(`   - ${packageName}`);
  console.log('   - update-manifest.json');
  console.log('2. تأكد أن رابط update-manifest.json مطابق لما في update-config.json.');
  console.log('3. افتح البرنامج → الإعدادات → تحديث البرنامج → التحقق من وجود تحديثات.');
})();

/* Rebuild note: file hashes inside the manifest are computed from the same
   files that go into the final zip (collectFiles() re-reads after config write). */
