'use strict';
/* ============================================================
   Senior Pro — EXE / portable build
   Usage: node scripts/build-exe.js [--out dist]
   Produces: dist/SeniorPro-<version>-win64/ (portable, ready to zip)
     - SeniorPro.exe        (node runtime copy; run with desktop-launcher.js)
     - install.ps1          (installs to Program Files + shortcuts)
     - uninstall.ps1        (removes app; PRESERVES %LOCALAPPDATA% data)
     - full app + node_modules
   Then: Compress the folder into SeniorPro-<version>-setup.zip
   ============================================================ */

const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const zip = require('../lib/zip');

const ROOT = path.resolve(__dirname, '..');
const pkg = require(path.join(ROOT, 'package.json'));
const VERSION = pkg.version;
const OUT = path.join(ROOT, 'dist', `SeniorPro-${VERSION}-win64`);

const COPY_FILES = [
  'package.json', 'server.js', 'seed.js', 'index.html', 'login.html',
  'senior-pro-logo.html', 'update-config.json', 'README.md', 'desktop-launcher.js'
];
const COPY_DIRS = ['js', 'css', 'vendor', 'icons', 'lib', 'scripts'];
const NODE_MODULES_KEEP = ['express', 'sqlite3', 'bcryptjs'];

function args() {
  const out = {};
  process.argv.slice(2).forEach((a, i, arr) => {
    if (a.startsWith('--')) out[a.slice(2)] = arr[i + 1] && !arr[i + 1].startsWith('--') ? arr[i + 1] : true;
  });
  return out;
}

function rmrf(p) { fs.rmSync(p, { recursive: true, force: true }); }

const INSTALL_PS = `# Senior Pro __VER__ — Installer
param([string]$DestDir = '')
$ErrorActionPreference = 'Stop'
$src = $PSScriptRoot
$dest = if ($DestDir) { $DestDir } else { Join-Path $env:ProgramFiles 'SeniorPro' }
Write-Host "تثبيت Senior Pro __VER__ إلى $dest ..."
New-Item -ItemType Directory -Force $dest | Out-Null
Copy-Item -Path (Join-Path $src '*') -Destination $dest -Recurse -Force

# Shortcuts (desktop + start menu) — open server + browser
$ws = New-Object -ComObject WScript.Shell
$lnkArgs = 'desktop-launcher.js'
$icoFile = Join-Path $dest 'icons\\senior-pro.ico'
foreach ($loc in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  $lnk = $ws.CreateShortcut((Join-Path $loc 'Senior Pro.lnk'))
  $lnk.TargetPath = Join-Path $dest 'SeniorPro.exe'
  $lnk.Arguments = $lnkArgs
  $lnk.WorkingDirectory = $dest
  $lnk.IconLocation = if (Test-Path $icoFile) { $icoFile } else { Join-Path $dest 'SeniorPro.exe' }
  $lnk.Save()
}
# Uninstaller shortcut
$ulnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Programs')) 'Uninstall Senior Pro.lnk'))
$ulnk.TargetPath = 'powershell.exe'
$ulnk.Arguments = '-NoProfile -ExecutionPolicy Bypass -File ' + (Join-Path $dest 'uninstall.ps1')
$ulnk.Save()

# Hide code files from the client — only the EXE stays visible.
# Hidden files keep working normally (the server reads them as usual).
Set-Content -Path (Join-Path $dest '.hidden-install') -Value '1'
attrib +h (Join-Path $dest '*') /s /d | Out-Null
attrib -h (Join-Path $dest 'SeniorPro.exe')
if (Test-Path $icoFile) { attrib -h $icoFile }

Write-Host '✓ تم التثبيت. بيانات البرنامج في %LOCALAPPDATA%\\SeniorManagement ولن تُحذف عند إلغاء التثبيت.'
Write-Host 'شغّل البرنامج من اختصار Senior Pro على سطح المكتب.'
`;

const UNINSTALL_PS = `# Senior Pro — Uninstaller (data is preserved)
param([string]$DestDir = '')
$ErrorActionPreference = 'SilentlyContinue'
$dest = if ($DestDir) { $DestDir } else { Join-Path $env:ProgramFiles 'SeniorPro' }
Get-Process SeniorPro -ErrorAction SilentlyContinue | Stop-Process -Force
foreach ($loc in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs'))) {
  Remove-Item (Join-Path $loc 'Senior Pro.lnk') -Force
  Remove-Item (Join-Path $loc 'Uninstall Senior Pro.lnk') -Force
}
Remove-Item $dest -Recurse -Force
Write-Host '✓ تم إلغاء التثبيت.'
Write-Host 'بياناتك (قاعدة البيانات والنسخ الاحتياطية) محفوظة في:' (Join-Path $env:LOCALAPPDATA 'SeniorManagement')
`;

(async () => {
  const a = args();
  rmrf(OUT);
  fs.mkdirSync(OUT, { recursive: true });

  // 1) App files
  for (const f of COPY_FILES) {
    const src = path.join(ROOT, f);
    if (fs.existsSync(src)) fs.copyFileSync(src, path.join(OUT, f));
  }
  for (const d of COPY_DIRS) {
    const src = path.join(ROOT, d);
    if (fs.existsSync(src)) fs.cpSync(src, path.join(OUT, d), { recursive: true });
  }

  // 2) node_modules (only production dependencies + their deps)
  const nm = path.join(OUT, 'node_modules');
  fs.mkdirSync(nm, { recursive: true });
  const seen = new Set();
  const resolveDep = (name) => {
    if (seen.has(name)) return;
    seen.add(name);
    const src = path.join(ROOT, 'node_modules', name);
    if (!fs.existsSync(src)) { console.warn('⚠ حزمة مفقودة: ' + name); return; }
    fs.cpSync(src, path.join(nm, name), { recursive: true });
    const pj = path.join(src, 'package.json');
    if (fs.existsSync(pj)) {
      try {
        const deps = JSON.parse(fs.readFileSync(pj, 'utf8')).dependencies || {};
        Object.keys(deps).forEach(d => {
          const scoped = d.startsWith('@') ? d.split('/')[0] : d;
          resolveDep(scoped);
        });
      } catch (e) {}
    }
  };
  NODE_MODULES_KEEP.forEach(resolveDep);

  // 3) EXE: copy the node runtime as SeniorPro.exe (runs desktop-launcher.js)
  const nodeSrc = process.execPath;
  fs.copyFileSync(nodeSrc, path.join(OUT, 'SeniorPro.exe'));
  console.log(`✓ SeniorPro.exe (${(fs.statSync(nodeSrc).size / 1048576).toFixed(1)} MB من ${nodeSrc})`);

  // 4) installer / uninstaller scripts — UTF-8 **with BOM** so Windows
  //    PowerShell 5.1 parses the Arabic text correctly (without BOM it
  //    reads the file as ANSI and the script breaks).
  fs.writeFileSync(path.join(OUT, 'install.ps1'), '\ufeff' + INSTALL_PS.replace(/__VER__/g, VERSION), 'utf8');
  fs.writeFileSync(path.join(OUT, 'uninstall.ps1'), '\ufeff' + UNINSTALL_PS.replace(/__VER__/g, VERSION), 'utf8');

  // 5) zip the portable folder
  const entries = [];
  (function walk(dir, rel) {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const relPath = rel ? rel + '/' + e.name : e.name;
      const abs = path.join(dir, e.name);
      if (e.isDirectory()) walk(abs, relPath);
      else entries.push({ name: relPath, data: fs.readFileSync(abs) });
    }
  })(OUT, '');
  const setupZip = path.join(ROOT, 'dist', `SeniorPro-${VERSION}-setup.zip`);
  fs.writeFileSync(setupZip, zip.pack(entries));
  console.log(`✓ حزمة التوزيع: dist/SeniorPro-${VERSION}-setup.zip (${(fs.statSync(setupZip).size / 1048576).toFixed(1)} MB، ${entries.length} ملف)`);
  console.log('\nللتثبيت: فك الضغط ثم تشغيل install.ps1 (زر يمين → تشغيل بـ PowerShell)');

  /* Total-size report */
  let total = 0;
  for (const e of entries) total += e.data.length;
  console.log(`حجم المجلد المحمول: ${(total / 1048576).toFixed(1)} MB`);

  /* 6) Single-file installer EXE via Inno Setup (if installed) */
  const innoPaths = [
    'C:\\Program Files\\Inno Setup 7\\ISCC.exe',
    'C:\\Program Files\\Inno Setup 6\\ISCC.exe',
    'C:\\Program Files (x86)\\Inno Setup 6\\ISCC.exe'
  ];
  const iscc = innoPaths.find(p => fs.existsSync(p));
  if (!iscc) {
    console.warn('⚠ لم يُعثر على Inno Setup (ISCC.exe) — تخطّي بناء ملف التثبيت Setup.exe');
    console.warn('  ثبّته من https://jrsoftware.org/isdl.php ثم أعد npm run build-exe');
    return;
  }

  // Marker file: tells the auto-updater to keep code files hidden after updates.
  fs.writeFileSync(path.join(OUT, '.hidden-install'), '1', 'utf8');

  const iss = String.raw`[Setup]
AppId={{8C1F2A9E-6B4D-4E7A-9F3C-5D2E1B0A7C61}
AppName=Senior Pro
AppVersion=${VERSION}
AppVerName=Senior Pro ${VERSION}
AppPublisher=Senior Pro
DefaultDirName={localappdata}\Programs\SeniorPro
DefaultGroupName=Senior Pro
UninstallDisplayName=Senior Pro
UninstallDisplayIcon={app}\icons\senior-pro.ico
SetupIconFile=${ROOT}\icons\senior-pro.ico
OutputDir=${ROOT}\dist
OutputBaseFilename=SeniorPro-${VERSION}-Setup
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
CloseApplications=no
DisableProgramGroupPage=yes

[Languages]
Name: "arabic"; MessagesFile: "compiler:Languages\Arabic.isl"

[Files]
Source: "${OUT}\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{autodesktop}\Senior Pro"; Filename: "{app}\SeniorPro.exe"; Parameters: "desktop-launcher.js"; WorkingDir: "{app}"; IconFilename: "{app}\icons\senior-pro.ico"
Name: "{group}\Senior Pro"; Filename: "{app}\SeniorPro.exe"; Parameters: "desktop-launcher.js"; WorkingDir: "{app}"; IconFilename: "{app}\icons\senior-pro.ico"
Name: "{group}\إلغاء تثبيت Senior Pro"; Filename: "{uninstallexe}"

[Run]
Filename: "{sys}\cmd.exe"; Parameters: "/c attrib +h ""{app}\*"" /s /d & attrib -h ""{app}\SeniorPro.exe"" & attrib -h ""{app}\icons\senior-pro.ico"" & attrib -h ""{app}\unins000.exe"""; Flags: runhidden
Filename: "{app}\SeniorPro.exe"; Parameters: "desktop-launcher.js"; Description: "تشغيل Senior Pro"; Flags: nowait postinstall skipifsilent
`;
  const issPath = path.join(ROOT, 'dist', 'installer.iss');
  // UTF-8 BOM: Inno Setup requires it for non-ASCII text.
  fs.writeFileSync(issPath, '\ufeff' + iss, 'utf8');
  console.log('✓ سكربت المثبّت: dist/installer.iss');
  try {
    execFileSync(iscc, ['/Qp', issPath], { stdio: 'inherit' });
    const setupExe = path.join(ROOT, 'dist', `SeniorPro-${VERSION}-Setup.exe`);
    const sz = fs.statSync(setupExe).size;
    console.log(`✓ ملف التثبيت: dist/SeniorPro-${VERSION}-Setup.exe (${(sz / 1048576).toFixed(1)} MB)`);
    console.log('  يثبّت في %LOCALAPPDATA%\\Programs\\SeniorPro بدون صلاحيات مدير،');
    console.log('  مع اختصار على سطح المكتب بأيقونة البرنامج، وإخفاء ملفات الكود عن العميل.');
  } catch (e) {
    console.error('✗ فشل بناء ملف التثبيت:', (e.stderr || e.message || '').toString());
    process.exitCode = 1;
  }
})();
