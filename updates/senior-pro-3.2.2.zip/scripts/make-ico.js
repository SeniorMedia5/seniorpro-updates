'use strict';
/* ============================================================
   Senior Pro — PNG → ICO wrapper (dependency-free)
   Wraps an existing PNG into a valid .ico container so the
   installer/shortcut can use the real app logo as its icon.
   Usage: node scripts/make-ico.js [srcPng] [destIco]
   ============================================================ */

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const SRC = process.argv[2] ? path.resolve(process.argv[2]) : path.join(ROOT, 'icons', 'Icon-192.png');
const DEST = process.argv[3] ? path.resolve(process.argv[3]) : path.join(ROOT, 'icons', 'senior-pro.ico');

const png = fs.readFileSync(SRC);

/* PNG dimensions from the IHDR chunk (bytes 16..23: width, height big-endian) */
const pngW = png.readUInt32BE(16);
const pngH = png.readUInt32BE(20);
if (pngW !== pngH) throw new Error('الأيقونة المصدر ليست مربعة: ' + pngW + 'x' + pngH);

/* ICO header (6 bytes) + one directory entry (16 bytes) + PNG data.
   Windows Vista+ supports PNG-compressed entries directly. */
const ico = Buffer.alloc(22);
ico.writeUInt16LE(0, 0);          // reserved
ico.writeUInt16LE(1, 2);          // type: icon
ico.writeUInt16LE(1, 4);          // 1 image

const dir = ico;                  // entry starts at offset 6
dir.writeUInt8(pngW >= 256 ? 0 : pngW, 6);   // 0 = 256
dir.writeUInt8(pngH >= 256 ? 0 : pngH, 7);
dir.writeUInt8(0, 8);             // palette colors
dir.writeUInt8(0, 9);             // reserved
dir.writeUInt16LE(1, 10);         // planes
dir.writeUInt16LE(32, 12);        // bits per pixel
dir.writeUInt32LE(png.length, 14); // data size
dir.writeUInt32LE(22, 18);        // data offset

fs.writeFileSync(DEST, Buffer.concat([ico, png]));
console.log(`✓ أيقونة: ${path.relative(ROOT, DEST)} (${pngW}x${pngH}، ${(png.length / 1024).toFixed(0)} KB)`);
