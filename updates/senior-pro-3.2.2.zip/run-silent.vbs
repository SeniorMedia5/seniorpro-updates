' Senior Pro — silent launcher.
' Runs the app EXE with NO console window (intWindowStyle = 0).
' The desktop/start-menu shortcuts point at this file via wscript.
Set sh  = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = dir
sh.Run """" & dir & "\SeniorPro.exe"" desktop-launcher.js", 0, False
