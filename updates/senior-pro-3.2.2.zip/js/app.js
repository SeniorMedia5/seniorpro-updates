/* ============================================================
   Senior Pro — App
   ============================================================ */
'use strict';

const $ = (sel, ctx) => (ctx || document).querySelector(sel);
const $$ = (sel, ctx) => Array.from((ctx || document).querySelectorAll(sel));

/* ---------- Sample Data ---------- */
const STATUS = {
  received:   { label: 'مستلم',           chip: 'chip-gray'   },
  inspection: { label: 'قيد الفحص',       chip: 'chip-blue'   },
  approval:   { label: 'بانتظار الموافقة', chip: 'chip-amber' },
  parts:      { label: 'بانتظار الأجزاء',  chip: 'chip-purple' },
  repairing:  { label: 'قيد الإصلاح',      chip: 'chip-orange' },
  quality:    { label: 'فحص الجودة',       chip: 'chip-teal'   },
  completed:  { label: 'مكتمل',           chip: 'chip-green'  },
  delivered:  { label: 'مسلّم',           chip: 'chip-navy'   },
};

const SAMPLE_CUSTOMERS = [];

const SAMPLE_REPAIRS = [];

const DEVICES = [];

const SAMPLE_PRODUCTS = [];

const SAMPLE_SUPPLIERS = [];

const STOCK = [];

const SAMPLE_PORDERS = [];

const SAMPLE_INSTALLMENTS = [];

const SAMPLE_PURCHASES = [];

const AVATARS = ['av-1', 'av-2', 'av-3', 'av-4', 'av-5', 'av-6'];

/* ---------- Roles & Permissions ---------- */
const ALL_VIEWS = ['dashboard', 'customers', 'repairs', 'new-repair', 'devices', 'inventory', 'damages', 'sales', 'installments', 'purchases', 'financial', 'reports', 'employees', 'settings'];
const ROLES = {
  'مدير النظام': { chip: 'navy',  views: ALL_VIEWS },
  'كاشير':       { chip: 'red',   views: ['dashboard', 'customers', 'new-repair', 'sales', 'installments', 'reports'] },
  'فني':         { chip: 'blue',  views: ['dashboard', 'repairs', 'new-repair', 'devices', 'reports'] },
  'أمين مستودع': { chip: 'green', views: ['dashboard', 'inventory', 'damages', 'purchases', 'reports'] },
};
const ROLE_NAMES = Object.keys(ROLES);
const VIEW_LABELS = {
  dashboard: 'لوحة التحكم', customers: 'العملاء', repairs: 'الإصلاحات', 'new-repair': 'استلام جهاز',
  devices: 'الأجهزة', inventory: 'المخزون', damages: 'الهالك', sales: 'نقطة البيع', purchases: 'المشتريات',
  financial: 'المالية', reports: 'التقارير', employees: 'الموظفون', settings: 'الإعدادات', installments: 'خطط الأقساط',
};
const VIEW_ICONS = {
  dashboard: 'fa-gauge-high', customers: 'fa-users', repairs: 'fa-screwdriver-wrench', 'new-repair': 'fa-clipboard-list',
  devices: 'fa-mobile-screen-button', inventory: 'fa-boxes-stacked', damages: 'fa-recycle', sales: 'fa-cash-register', purchases: 'fa-cart-shopping',
  financial: 'fa-money-bill-trend-up', reports: 'fa-chart-column', employees: 'fa-user-tie', settings: 'fa-gear', installments: 'fa-calendar-check',
};
function roleDefaultViews(role) {
  return (ROLES[role] || ROLES['كاشير']).views.slice();
}
function applyPermChecks(role, perms) {
  const grid = $('#mu-perms');
  if (!grid) return;
  const isAdmin = role === 'مدير النظام';
  const base = isAdmin ? ALL_VIEWS.slice() : (Array.isArray(perms) && perms.length ? perms.slice() : roleDefaultViews(role));
  grid.querySelectorAll('input').forEach(cb => {
    cb.checked = base.includes(cb.value);
    cb.disabled = isAdmin;
    cb.closest('label').classList.toggle('disabled', isAdmin);
  });
  const note = $('#mu-perm-note');
  if (note) note.textContent = isAdmin ? '— مدير النظام لديه كل الصلاحيات' : '— حدد الأقسام المتاحة لهذا المستخدم';
}

/* ---------- Persistent data layer (document store + cache) ---------- */
const API_BASE = '/api';
const ARRAY_KEYS = ['customers','repairs','products','purchases','porders','sales','suppliers','employees','installments','categories','orders','quotes','returns','damages','backups'];
const OBJECT_KEYS = ['settings','machine','license'];
const DB_CACHE = {};
const WRITE_CHAINS = {};
let SAVE_ERROR_SHOWN = 0;
let MACHINE_ID = ''; // hardware fingerprint from the server

const NESTED_FIELDS = {
  customers: [],
  repairs: ['parts'],
  sales: ['items', 'payments'],
  purchases: ['lines'],
  porders: ['lines'],
  installments: ['items', 'payments'],
  orders: ['items'],
  quotes: ['items'],
  returns: ['items'],
  damages: ['lines'],
  users: ['perms']
};

function parseMaybeJSON(v) {
  if (typeof v !== 'string') return v;
  const s = v.trim();
  if (!s || (s[0] !== '[' && s[0] !== '{')) return v;
  try { return JSON.parse(s); } catch (e) { return v; }
}

function normalizeCollection(key, value) {
  if (ARRAY_KEYS.includes(key)) {
    if (!Array.isArray(value)) return [];
    const fields = NESTED_FIELDS[key] || [];
    return value.filter(x => x && typeof x === 'object').map(row => {
      const out = { ...row };
      fields.forEach(f => {
        if (out[f] !== undefined) out[f] = parseMaybeJSON(out[f]);
        if (['items','payments','parts','lines','perms'].includes(f) && !Array.isArray(out[f])) out[f] = [];
      });
      return out;
    });
  }
  if (key === 'users') {
    if (!Array.isArray(value)) return [];
    return value.filter(x => x && typeof x === 'object').map(row => {
      const out = { ...row };
      out.perms = Array.isArray(out.perms) ? out.perms : (parseMaybeJSON(out.perms) || []);
      if (!Array.isArray(out.perms)) out.perms = [];
      return out;
    });
  }
  if (OBJECT_KEYS.includes(key)) return (value && typeof value === 'object' && !Array.isArray(value)) ? value : {};
  return value;
}

function storedSessionRaw() {
  try { return sessionStorage.getItem('wdb_session') || localStorage.getItem('wdb_session'); } catch (e) { return null; }
}

function authToken() {
  try {
    const raw = storedSessionRaw();
    if (!raw) return '';
    return JSON.parse(raw).token || '';
  } catch (e) { return ''; }
}

function clearSession() {
  try { sessionStorage.removeItem('wdb_session'); localStorage.removeItem('wdb_session'); } catch (e) {}
  try { localStorage.removeItem('wdb_users'); } catch (e) {}
}

let AUTH_REDIRECT = false;
function goLogin() {
  if (AUTH_REDIRECT) return;
  AUTH_REDIRECT = true;
  clearSession();
  location.replace('login.html');
}

async function apiFetch(path, opts = {}) {
  const headers = { ...(opts.headers || {}) };
  const token = authToken();
  if (token) headers['Authorization'] = 'Bearer ' + token;
  if (opts.body !== undefined && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
  const res = await fetch(API_BASE + path, { ...opts, headers, cache: 'no-store' });
  if (res.status === 401) goLogin();
  return res;
}

function enqueueWrite(key, value) {
  const prev = WRITE_CHAINS[key] || Promise.resolve();
  const task = prev.catch(() => {}).then(async () => {
    const res = await apiFetch('/' + key, { method: 'PUT', body: JSON.stringify(value) });
    if (!res.ok && res.status !== 401) throw new Error('save failed (' + res.status + ')');
  });
  WRITE_CHAINS[key] = task;
  task.catch(() => {
    const now = Date.now();
    if (now - SAVE_ERROR_SHOWN > 8000) {
      SAVE_ERROR_SHOWN = now;
      toast('تعذر حفظ التغييرات على الخادم — تحقق من تشغيل الخادم', 'error');
    }
  });
  return task;
}

const DB = {
  async init() {
    const keys = [...ARRAY_KEYS, ...OBJECT_KEYS, 'users'];
    const results = await Promise.allSettled(keys.map(k => apiFetch('/' + k)));
    if (AUTH_REDIRECT) return false;
    let networkErrors = 0;
    for (let i = 0; i < keys.length; i++) {
      const r = results[i];
      if (r.status === 'rejected') { networkErrors++; continue; }
      const res = r.value;
      if (res.ok) {
        try { DB_CACHE[keys[i]] = normalizeCollection(keys[i], await res.json()); } catch (e) {}
      } else if (res.status !== 401) {
        networkErrors++;
      }
    }
    if (networkErrors >= keys.length) {
      toast('تعذر الاتصال بالخادم — شغّل الخادم بـ npm start', 'error');
      return true;
    }
    // Hardware fingerprint (source of truth for license binding).
    try {
      const mres = await apiFetch('/machine-id');
      if (mres.ok) {
        const mdata = await mres.json();
        if (mdata && mdata.id) MACHINE_ID = String(mdata.id).toUpperCase();
      }
    } catch (e) {}
    // Keep a small settings cache for the login page (logo / company name only).
    try { localStorage.setItem('wdb_settings', JSON.stringify(DB_CACHE.settings || {})); } catch (e) {}
    return true;
  },
  get(key, fallback) {
    return DB_CACHE[key] !== undefined ? DB_CACHE[key] : fallback;
  },
  set(key, val) {
    let snapshot;
    try { snapshot = JSON.parse(JSON.stringify(val)); } catch (e) { snapshot = val; }
    DB_CACHE[key] = snapshot;
    if (key === 'settings') {
      try { localStorage.setItem('wdb_settings', JSON.stringify(snapshot)); } catch (e) {}
    }
    return enqueueWrite(key, snapshot);
  },
  del(key) {
    delete DB_CACHE[key];
    return apiFetch('/' + key, { method: 'DELETE' }).catch(() => {});
  }
};

/* ---------- Backup & Restore System ---------- */
const BackupManager = {
  // Get all data from API via DB cache (synchronous — cache filled by DB.init on load)
  getAllData() {
    return {
      customers: DB.get('customers', []),
      repairs: DB.get('repairs', []),
      products: DB.get('products', []),
      purchases: DB.get('purchases', []),
      porders: DB.get('porders', []),
      sales: DB.get('sales', []),
      suppliers: DB.get('suppliers', []),
      employees: DB.get('employees', []),
      settings: DB.get('settings', {}),
      installments: DB.get('installments', []),
      categories: DB.get('categories', []),
      orders: DB.get('orders', []),
      quotes: DB.get('quotes', []),
      returns: DB.get('returns', []),
      damages: DB.get('damages', []),
    };
  },

  // Save all data to API via DB cache
  saveAllData(data) {
    if (!data || typeof data !== 'object') return Promise.resolve();
    const writes = [];
    ['customers', 'repairs', 'products', 'purchases', 'porders', 'sales', 'suppliers', 'employees', 'installments', 'categories', 'orders', 'quotes', 'returns', 'damages'].forEach(k => {
      if (Array.isArray(data[k])) writes.push(DB.set(k, data[k]));
    });
    if (data.settings !== undefined) writes.push(DB.set('settings', data.settings || {}));
    return Promise.all(writes);
  },

  // Export all data to JSON file
  exportData() {
    const data = this.getAllData();
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'senior-pro-backup-' + new Date().toISOString().slice(0, 10) + '.json';
    a.click();
    URL.revokeObjectURL(url);
    toast('تم تصدير بيانات النسخة الاحتياطية');
  },

  // Import data from JSON file with validation
  importData(file, options = { merge: false }) {
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const imported = JSON.parse(e.target.result);
        
        // Validate required fields
        const requiredFields = ['customers', 'repairs', 'products', 'purchases', 'sales', 'suppliers', 'employees', 'settings'];
        const optionalFields = ['porders', 'installments', 'categories', 'orders', 'quotes', 'returns', 'damages'];
        const hasAllFields = requiredFields.every(f => f in imported);
        
        if (!hasAllFields) {
          toast('الملف غير صالح - يفتقر إلى حقول البيانات المطلوبة', 'error');
          return;
        }

        // Show confirmation if not merge mode
        if (!options.merge) {
          const confirmed = confirm('هذا سيستبدل جميع البيانات الحالية. هل تريد المضي قدماً؟');
          if (!confirmed) return;
        }

        // Create backup before replace (protection)
        this.createAutoBackup();

        // Merge or replace
        if (options.merge) {
          // Merge logic - keep existing data and add/update from imported (by id/no/barcode/phone)
          const existing = this.getAllData();
          const mergeData = {
            customers: this.mergeByKey(existing.customers, imported.customers, (x) => x?.phone || x?.id || x?.name),
            repairs: this.mergeByKey(existing.repairs, imported.repairs, (x) => x?.id),
            products: this.mergeByKey(existing.products, imported.products, (x) => x?.barcode || x?.id || x?.name),
            purchases: this.mergeByKey(existing.purchases, imported.purchases, (x) => x?.no),
            porders: this.mergeByKey(existing.porders, imported.porders, (x) => x?.no),
            sales: this.mergeByKey(existing.sales, imported.sales, (x) => x?.no),
            suppliers: this.mergeByKey(existing.suppliers, imported.suppliers, (x) => x?.phone || x?.id || x?.name),
            employees: this.mergeByKey(existing.employees, imported.employees, (x) => x?.phone || x?.id || x?.name),
            installments: this.mergeByKey(existing.installments, imported.installments, (x) => x?.no),
            categories: this.mergeByKey(existing.categories, imported.categories, (x) => x?.id || x?.name),
            orders: this.mergeByKey(existing.orders, imported.orders, (x) => x?.no),
            quotes: this.mergeByKey(existing.quotes, imported.quotes, (x) => x?.no),
            returns: this.mergeByKey(existing.returns, imported.returns, (x) => x?.no),
            damages: this.mergeByKey(existing.damages || [], imported.damages || [], (x) => x?.no),
            settings: { ...(existing.settings || {}), ...(imported.settings || {}) },
          };
          await this.saveAllData(mergeData);
          toast('تم استيراد البيانات ودمجها مع البيانات الحالية');
          this.refreshInfo();
        } else {
          // Full replace — wait for all writes before reloading.
          await this.saveAllData(imported);
          toast('تم استبدال البيانات بنجاح');
          location.reload();
        }
      } catch (err) {
        toast('تعذر قراءة الملف - format غير صحيح', 'error');
      }
    };
    reader.onerror = () => toast('تعذر قراءة الملف', 'error');
    reader.readAsText(file);
  },

  // Merge two arrays by item key (imported item wins on conflict).
  // Falls back to mergeById for backward compatibility.
  mergeByKey(existing, imported, keyFn) {
    existing = Array.isArray(existing) ? existing : [];
    imported = Array.isArray(imported) ? imported : [];
    const map = new Map();
    const keyOf = (item) => {
      try {
        const k = keyFn ? keyFn(item) : (item && (item.id || item.no));
        return (k === undefined || k === null || k === '') ? null : String(k);
      } catch (e) { return null; }
    };
    existing.forEach(item => { const k = item && keyOf(item); if (k) map.set(k, item); else if (item) map.set('ex_' + Math.random().toString(36).slice(2, 10), item); });
    imported.forEach(item => {
      if (!item) return;
      const k = keyOf(item);
      if (k) map.set(k, item);
      else map.set('imp_' + Math.random().toString(36).slice(2, 10), item);
    });
    return Array.from(map.values());
  },

  // Merge two arrays by item id (imported item wins on conflict)
  mergeById(existing, imported) {
    return this.mergeByKey(existing, imported, (x) => x && (x.id || x.no));
  },

  // Create auto backup before restore or important operations
  createAutoBackup() {
    const backups = this.getBackups();
    const backupData = this.getAllData();
    const now = new Date();
    backups.push({
      date: now.toLocaleDateString() + ' ' + now.toLocaleTimeString(),
      ts: now.getTime(),
      data: JSON.stringify(backupData),
    });
    // Keep only last 5 backups
    if (backups.length > 5) backups.shift();
    DB.set('backups', backups);
    toast('تم إنشاء نسخة احتياطية تلقائية');
  },

  // Refresh the DB info panel after import/backup
  refreshInfo() {
    const info = this.getDatabaseInfo();
    if ($('#db-customers')) $('#db-customers').textContent = info.customers;
    if ($('#db-products')) $('#db-products').textContent = info.products;
    if ($('#db-repairs')) $('#db-repairs').textContent = info.repairs;
    if ($('#db-sales')) $('#db-sales').textContent = info.sales;
    if ($('#db-size')) $('#db-size').textContent = info.dataSize;
    if ($('#last-backup')) $('#last-backup').textContent = info.lastBackup;
    if ($('#backup-count')) $('#backup-count').textContent = this.getBackups().length;
  },

  // Get stored backups
  getBackups() {
    const backups = DB.get('backups', []);
    return Array.isArray(backups) ? backups : [];
  },

  // Get database info
  getDatabaseInfo() {
    const data = this.getAllData();
    const size = this.calcDataSize(data);
    return {
      customers: data.customers.length,
      products: data.products.length,
      repairs: data.repairs.length,
      sales: data.sales.length,
      purchases: data.purchases.length,
      suppliers: data.suppliers.length,
      employees: data.employees.length,
      totalRecords: data.customers.length + data.repairs.length + data.products.length + data.sales.length + data.purchases.length + data.suppliers.length + data.employees.length,
      dataSize: size,
      lastBackup: this.getBackups().length > 0 ? this.getBackups()[this.getBackups().length - 1]?.date : 'لا توجد نسخ',
    };
  },

  // Calculate approximate data size in KB
  calcDataSize(data) {
    const serialized = JSON.stringify(data);
    return Math.round(serialized.length / 1024) + ' KB';
  },
};

/* ---------- Event binding for backup system ---------- */
document.addEventListener('click', (e) => {
  const backupNow = e.target.closest('[data-action="backup-now"]');
  if (backupNow) { BackupManager.exportData(); return; }

  const restoreBackup = e.target.closest('[data-action="restore-backup"]');
  if (restoreBackup) { const el = $('#restore-file'); if (el) el.click(); return; }

  const importData = e.target.closest('[data-action="import-data"]');
  if (importData) { const el = $('#import-file'); if (el) el.click(); return; }

  const factoryReset = e.target.closest('[data-action="factory-reset"]');
  if (factoryReset) {
    if (!confirm('إعادة ضبط المصنع — سيتم مسح كل البيانات نهائياً والعودة إلى الوضع الافتراضي.')) return;
    if (!confirm('تأكيد نهائي؟ لا يمكن التراجع عن هذه العملية. سيتم إنشاء نسخة احتياطية تلقائية قبل المسح.')) return;
    BackupManager.createAutoBackup();
    const resetKeys = ['customers', 'repairs', 'products', 'purchases', 'porders', 'sales', 'suppliers', 'employees', 'settings', 'categories', 'installments', 'orders', 'quotes', 'returns', 'damages'];
    const writes = resetKeys.map(k => DB.set(k, k === 'settings' ? DEFAULT_SETTINGS : []));
    Promise.all(writes).then(() => {
      toast('تمت إعادة ضبط المصنع بنجاح');
      location.reload();
    }).catch(() => toast('تعذر إكمال إعادة الضبط — تحقق من اتصال الخادم', 'error'));
    return;
  }
});

// File change handlers: restore = replace, import = merge
document.addEventListener('change', (e) => {
  const restoreInput = e.target.closest('#restore-file');
  if (restoreInput && restoreInput.files && restoreInput.files[0]) {
    BackupManager.importData(restoreInput.files[0], { merge: false });
    restoreInput.value = '';
    return;
  }
  const importInput = e.target.closest('#import-file');
  if (importInput && importInput.files && importInput.files[0]) {
    BackupManager.importData(importInput.files[0], { merge: true });
    importInput.value = '';
    return;
  }
  const logoInput = e.target.closest('#logo-file');
  if (logoInput && logoInput.files && logoInput.files[0]) {
    handleLogoFile(logoInput.files[0]);
    logoInput.value = '';
  }
});

// Initialize backup system and update database info
function initBackupSystem() {
  BackupManager.refreshInfo();

  const autoSwitch = $('#auto-backup-switch');
  if (autoSwitch) {
    autoSwitch.addEventListener('change', () => {
      const statusEl = $('#auto-backup-status');
      if (statusEl) statusEl.textContent = autoSwitch.checked ? 'مفعل' : 'مقفل';
    });

    // Daily automatic backup (only while enabled)
    setInterval(() => {
      if (autoSwitch.checked) {
        BackupManager.createAutoBackup();
        BackupManager.refreshInfo();
      }
    }, 24 * 60 * 60 * 1000);
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initBackupSystem);
} else {
  initBackupSystem();
}

/* ---------- Currency system ---------- */
const CURRENCIES = {
  'ريال سعودي (ر.س)': 'ر.س',
  'جنيه مصري (ج.م)': 'ج.م',
  'دينار كويتي (د.ك)': 'د.ك',
  'درهم إماراتي (د.إ)': 'د.إ',
  'ريال قطري (ر.ق)': 'ر.ق',
};
const SYMBOL_TO_LABEL = Object.fromEntries(Object.entries(CURRENCIES).map(([k, v]) => [v, k]));
let CURRENCY = 'ج.م';
function curSymbol(v) { return CURRENCIES[v] || v; }
function cur(n) { return (Number(n) || 0).toLocaleString('en-US') + ' ' + CURRENCY; }
function sweepCurrency(from, to) {
  if (!from || from === to) return;
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const nodes = [];
  while (walker.nextNode()) {
    const t = walker.currentNode;
    if (!t.textContent.includes(from)) continue;
    let p = t.parentElement, skip = false;
    while (p) { if (p.tagName === 'SELECT' || p.tagName === 'OPTION' || p.hasAttribute('data-no-currency')) { skip = true; break; } p = p.parentElement; }
    if (!skip) nodes.push(t);
  }
  nodes.forEach(t => { t.textContent = t.textContent.split(from).join(to); });
}

let CUSTOMERS = DB.get('customers', SAMPLE_CUSTOMERS);
let REPAIRS = DB.get('repairs', SAMPLE_REPAIRS);
let PRODUCTS = DB.get('products', SAMPLE_PRODUCTS);
(function normalizeBarcodes() {
  let changed = false;
  PRODUCTS.forEach(p => {
    const n = p && p.barcode ? ean13Code(p.barcode) : '';
    if (n && n !== p.barcode) { p.barcode = n; changed = true; }
  });
  REPAIRS.forEach(r => {
    const n = r && r.barcode ? ean13Code(r.barcode) : '';
    if (n && n !== r.barcode) { r.barcode = n; changed = true; }
  });
  if (changed) { DB.set('products', PRODUCTS); DB.set('repairs', REPAIRS); }
})();
let PURCHASES = DB.get('purchases', SAMPLE_PURCHASES);
let INSTALLMENTS = DB.get('installments', SAMPLE_INSTALLMENTS);
(function backfillPurchaseLines() {
  let changed = false;
  PURCHASES.forEach(p => {
    if (Array.isArray(p.lines) && p.lines.length) return;
    const s = SAMPLE_PURCHASES.find(x => x.no === p.no);
    if (s && Array.isArray(s.lines)) { p.lines = s.lines.map(l => ({ ...l })); p.items = s.items; changed = true; }
  });
  if (changed) DB.set('purchases', PURCHASES);
})();
let PORDERS = DB.get('porders', SAMPLE_PORDERS);
(function backfillPOrders() {
  if (!Array.isArray(PORDERS)) return;
  let changed = false;
  PORDERS.forEach(p => {
    if (!Array.isArray(p.lines) || !p.lines.length) {
      const match = SAMPLE_PURCHASES.find(s => s.no === p.no) || SAMPLE_PORDERS.find(s => s.no === p.no);
      p.lines = (match && Array.isArray(match.lines) ? match.lines : []).map(l => ({ ...l }));
      changed = true;
    }
  });
  if (changed) DB.set('porders', PORDERS);
})();
let SUPPLIERS = DB.get('suppliers', SAMPLE_SUPPLIERS);
const DEFAULT_SETTINGS = { company: 'Senior Pro', invPrefix: 'INV-', repPrefix: 'RP-', tax: 15, currency: 'جنيه مصري (ج.م)', cr: '', taxno: '', mobile: '01005171136', phone: '01279599146', address: 'مصر - اسكندرية' };
let SETTINGS = { ...DEFAULT_SETTINGS };

function migrateCompanyInfo() {
  let changed = false;
  if (SETTINGS.company === 'سنيور برو لصيانة الأجهزة الإلكترونية') {
    SETTINGS.company = 'Senior Pro';
    changed = true;
  }
  ['company', 'mobile', 'phone', 'address'].forEach(k => {
    if (!SETTINGS[k]) {
      SETTINGS[k] = DEFAULT_SETTINGS[k];
      changed = true;
    }
  });
  if (SETTINGS.address && SETTINGS.address.includes('الرياض')) {
    SETTINGS.mobile = DEFAULT_SETTINGS.mobile;
    SETTINGS.phone = DEFAULT_SETTINGS.phone;
    SETTINGS.address = DEFAULT_SETTINGS.address;
    changed = true;
  }
  if (SETTINGS.currency === 'ريال سعودي (ر.س)') {
    SETTINGS.currency = 'جنيه مصري (ج.م)';
    changed = true;
  }
  return changed;
}

function migrateTerms() {
  let changed = false;
  if (!Array.isArray(SETTINGS.terms) || !SETTINGS.terms.length) {
    SETTINGS.terms = [
      'الورشة غير مسؤولة عن فقدان البيانات؛ ننصح بعمل نسخة احتياطية قبل الإصلاح.',
      'مدة الإصلاح التقديرية من 3 إلى 7 أيام عمل حسب توفر القطع.',
      'إذا لم يتم استلام الجهاز خلال 90 يوماً من تاريخ الإخطار، يحق للورشة التصرف بالجهاز.',
      'الدفع نقداً أو بالبطاقة عند التسليم، ورسوم الفحص غير مستردة.'
    ];
    changed = true;
  }
  if (typeof SETTINGS.receiptFooter !== 'string' || !SETTINGS.receiptFooter.trim()) {
    SETTINGS.receiptFooter = 'احتفظ بهذا الإيصال لاستلام جهازكم';
    changed = true;
  } else if (/^شكراً لثقتكم بنا\s*[—–-]?\s*/u.test(SETTINGS.receiptFooter)) {
    SETTINGS.receiptFooter = SETTINGS.receiptFooter.replace(/^شكراً لثقتكم بنا\s*[—–-]?\s*/u, '');
    changed = true;
  }
  if (typeof SETTINGS.printTerms !== 'boolean') { SETTINGS.printTerms = true; changed = true; }
  return changed;
}

function applySettingsMigrations() {
  let changed = migrateCompanyInfo();
  changed = migrateTerms() || changed;
  if (changed) DB.set('settings', SETTINGS);
}
let SALES = DB.get('sales', []);
let POS_CART = [];
let POS_FILTER = { q: '', cat: 'الكل' };
let CURRENT_TRACK_ID = null;
let CURRENT_RECEIPT = null;
let CURRENT_CUSTOMER_RECORD = null;
let REPAIR_PARTS = [];
let PO_LINES = [];
let QUOTES = DB.get('quotes', []);
let ORDERS = DB.get('orders', []);
let QUOTE_LINES = [];
let ORDER_LINES = [];
let POS_RETURN_LINES = [];

/* ---------- Session ---------- */
function readStoredSession() {
  try {
    const raw = sessionStorage.getItem('wdb_session') || localStorage.getItem('wdb_session') || 'null';
    const s = JSON.parse(raw);
    if (!s || typeof s !== 'object' || !s.user) return null;
    // Expiry: sessionStorage ~12h, localStorage (remember me) ~30 days
    const now = Date.now();
    const age = now - (Number(s.ts) || 0);
    const inLocal = !!localStorage.getItem('wdb_session');
    const maxAge = inLocal ? 30 * 24 * 3600 * 1000 : 12 * 3600 * 1000;
    if (!s.ts || age < 0 || age > maxAge) {
      try { sessionStorage.removeItem('wdb_session'); localStorage.removeItem('wdb_session'); } catch (e) {}
      return null;
    }
    return s;
  } catch (e) { return null; }
}
const SESSION = readStoredSession();
if (!SESSION) { location.replace('login.html'); }

function persistSession() {
  if (!SESSION) return;
  try {
    if (localStorage.getItem('wdb_session')) localStorage.setItem('wdb_session', JSON.stringify(SESSION));
    else sessionStorage.setItem('wdb_session', JSON.stringify(SESSION));
  } catch (e) {}
}

/* ---------- Users & permissions ---------- */
function getUsers() {
  const users = DB.get('users', []);
  return Array.isArray(users) ? users : [];
}

async function refreshUsers() {
  try {
    const res = await apiFetch('/users');
    if (res.ok) DB_CACHE['users'] = normalizeCollection('users', await res.json());
  } catch (e) {}
  return getUsers();
}

function apiError(payload, fallback) {
  return (payload && payload.error) || fallback;
}

async function upsertUser(payload) {
  const res = await apiFetch('/users', { method: 'POST', body: JSON.stringify(payload) });
  let data = {};
  try { data = await res.json(); } catch (e) {}
  if (!res.ok) throw new Error(apiError(data, 'تعذر حفظ المستخدم'));
  await refreshUsers();
  return data.user;
}

async function deleteUserAccount(username) {
  const res = await apiFetch('/users/' + encodeURIComponent(username), { method: 'DELETE' });
  let data = {};
  try { data = await res.json(); } catch (e) {}
  if (!res.ok) throw new Error(apiError(data, 'تعذر حذف المستخدم'));
  await refreshUsers();
}

function currentUserPerms() {
  const uname = SESSION && SESSION.user;
  const u = uname ? getUsers().find(x => x.user === uname) : null;
  if (u) {
    if (u.role === 'مدير النظام') return { views: ALL_VIEWS.slice(), chip: 'navy' };
    if (Array.isArray(u.perms) && u.perms.length) return { views: u.perms.slice(), chip: (ROLES[u.role] || {}).chip || 'blue' };
  }
  const role = (SESSION && SESSION.role) || 'مدير النظام';
  return ROLES[role] || ROLES['مدير النظام'];
}
function canView(view) {
  const perms = currentUserPerms();
  return perms.views.includes(view);
}
function isAdmin() {
  return (SESSION && SESSION.role) === 'مدير النظام';
}
// Money/profit figures and analytical reports are only for admins and users
// who were granted the financial or reports permission.
function canSeeFinancials() {
  if (isAdmin()) return true;
  return canView('financial') || canView('reports');
}
// Where to land when the requested view (usually the dashboard) is not allowed.
function firstAllowedView() {
  if (canView('dashboard')) return 'dashboard';
  const preferred = ['sales', 'new-repair', 'repairs', 'customers', 'devices',
    'inventory', 'damages', 'installments', 'purchases', 'financial',
    'reports', 'employees', 'settings'];
  return preferred.find(v => canView(v)) || ALL_VIEWS.find(v => canView(v)) || '';
}

function applyPermissions() {
  $$('.nav-item[data-view]').forEach(n => {
    n.style.display = canView(n.dataset.view) ? '' : 'none';
  });
  $$('.fab-item[data-view]').forEach(n => {
    n.style.display = canView(n.dataset.view) ? '' : 'none';
  });
  // Hide section captions that have no visible items left.
  $$('.nav-caption').forEach(cap => {
    let el = cap.nextElementSibling, anyVisible = false;
    while (el && !el.classList.contains('nav-caption')) {
      if (el.classList.contains('nav-item') && el.style.display !== 'none') { anyVisible = true; break; }
      el = el.nextElementSibling;
    }
    cap.style.display = anyVisible ? '' : 'none';
  });
  document.body.classList.toggle('hide-money', !canSeeFinancials());
  const cur = location.hash.replace('#/', '') || 'dashboard';
  if (!canView(cur)) {
    const landing = firstAllowedView();
    if (landing) showView(landing);
  }
}

const SAMPLE_RETURNS = [];
let RETURNS = DB.get('returns', SAMPLE_RETURNS);
let DAMAGES = DB.get('damages', []);
let DM_LINES = [];
let DM_FILTER = { from: '', to: '', all: true };
let DASH_PRIVACY = true; // dashboard figures hidden by default; eye button reveals them

// While privacy is on, chart tooltips (which reveal exact amounts) stay hidden.
if (typeof Chart !== 'undefined') {
  Chart.register({ id: 'dashPrivacyGuard', beforeTooltipDraw: () => !DASH_PRIVACY });
}

/* ---------- Employees ---------- */
const SAMPLE_EMPLOYEES = [];
let EMPLOYEES = DB.get('employees', SAMPLE_EMPLOYEES);

const SOCIAL_PLATFORMS = [
  { id: 'facebook',  name: 'فيسبوك',   icon: 'fa-brands fa-facebook-f' },
  { id: 'instagram', name: 'انستغرام', icon: 'fa-brands fa-instagram' },
  { id: 'whatsapp',  name: 'واتساب',   icon: 'fa-brands fa-whatsapp' },
  { id: 'x',         name: 'إكس (تويتر)', icon: 'fa-brands fa-x-twitter' },
  { id: 'tiktok',    name: 'تيك توك',  icon: 'fa-brands fa-tiktok' },
  { id: 'telegram',  name: 'تيليجرام', icon: 'fa-brands fa-telegram' },
  { id: 'snapchat',  name: 'سناب شات', icon: 'fa-brands fa-snapchat' },
  { id: 'youtube',   name: 'يوتيوب',   icon: 'fa-brands fa-youtube' },
];
function populateSocialSettings() {
  const list = Array.isArray(SETTINGS.social) ? SETTINGS.social : [];
  SOCIAL_PLATFORMS.forEach(p => {
    const item = list.find(s => s.id === p.id) || {};
    const cb = document.getElementById('so-' + p.id); if (cb) cb.checked = !!item.enabled;
    const url = document.getElementById('so-url-' + p.id); if (url) url.value = item.url || '';
  });
}
function shortURL(u) {
  let s = String(u || '').replace(/^https?:\/\//i, '').replace(/^www\./i, '').split(/[/?#]/).filter(Boolean).pop() || '';
  s = s.replace(/^@+/, '').trim();
  return s.length > 26 ? s.slice(0, 24) + '…' : s;
}
function populateInvoiceSettings() {
  const foot = $('#s-receipt-footer'); if (foot) foot.value = SETTINGS.receiptFooter || '';
  const pt = $('#s-print-terms'); if (pt) pt.checked = SETTINGS.printTerms !== false;
  (Array.isArray(SETTINGS.terms) ? SETTINGS.terms : []).forEach((t, i) => {
    const el = document.getElementById('s-term-' + i); if (el) el.value = t || '';
  });
}
function socialLinksHTML() {
  const list = Array.isArray(SETTINGS.social) ? SETTINGS.social.filter(s => s && s.enabled && s.url) : [];
  if (!list.length) return '';
  return `<div class="inv-social">${list.map(s => `<a href="${esc(safeURL(s.url))}" target="_blank" rel="noopener"><i class="${safeCls(s.icon, 'fa-solid fa-link')}"></i> ${esc(shortURL(s.url))}</a>`).join('')}</div>`;
}

/* ---------- Barcode & QR (SVG) ---------- */
const EAN_L = ['0001101','0011001','0010011','0111101','0100011','0110001','0101111','0111011','0110111','0001011'];
const EAN_G = ['0100111','0110011','0011011','0100001','0011101','0111001','0000101','0010001','0001001','0010111'];
const EAN_R = ['1110010','1100110','1101100','1000010','1011100','1001110','1010000','1000100','1001000','1110100'];
const EAN_LG = ['LLLLLL','LLGLGG','LLGGLG','LLGGGL','LGLLGG','LGGLLG','LGGGLL','LGLGLG','LGLGGL','LGGLGL'];

function ean13Code(digits) {
  let d = String(digits || '').replace(/\D/g, '');
  if (d.length > 12) d = d.slice(0, 12);
  while (d.length < 12) d = '0' + d;
  let sum = 0;
  for (let i = 0; i < 12; i++) sum += (i % 2 === 0 ? 1 : 3) * parseInt(d[i], 10);
  return d + ((10 - (sum % 10)) % 10);
}

function ean13Runs(code) {
  const f = parseInt(code[0], 10);
  const tbl = EAN_LG[f] || 'LLLLLL';
  let seq = '101';
  for (let i = 1; i <= 6; i++) seq += (tbl[i - 1] === 'L' ? EAN_L : EAN_G)[parseInt(code[i], 10)];
  seq += '01010';
  for (let i = 7; i < 13; i++) seq += EAN_R[parseInt(code[i], 10)];
  seq += '101';
  const runs = [];
  for (let i = 0; i < seq.length; i++) {
    const on = seq[i] === '1';
    if (runs.length && runs[runs.length - 1].on === on) runs[runs.length - 1].w++;
    else runs.push({ on, w: 1 });
  }
  return runs;
}

function genBarcode(el, digits, opts) {
  opts = opts || {};
  if (!el) return '';
  el.innerHTML = '';
  const raw = String(digits ?? '').replace(/\D/g, '');
  if (!raw) {
    el.style.display = 'flex'; el.style.alignItems = 'center'; el.style.justifyContent = 'center';
    el.innerHTML = '<span class="bc-empty">—</span>';
    return '';
  }
  const code = ean13Code(raw);
  const cls = el.classList;
  const isLg = cls.contains('barcode-lg'), isSm = cls.contains('barcode-sm');
  const barH = opts.barHmm != null ? parseFloat(opts.barHmm) : (isLg ? 44 : isSm ? 26 : 34);
  const h = (opts.barHmm != null ? barH + 'mm' : barH + 'px');
  const mod = isLg ? 2 : 1;
  el.style.display = 'flex';
  el.style.alignItems = 'stretch';
  el.style.gap = '0';
  el.style.height = h;
  ean13Runs(code).forEach(b => {
    const s = document.createElement('span');
    s.style.width = (b.w * mod * (opts.moduleScale || 1)) + 'px';
    s.style.height = h;
    s.style.background = b.on ? '#111' : 'transparent';
    s.style.display = 'block';
    el.appendChild(s);
  });
  return code;
}

/* Real QR rendering via the bundled qrcodejs lib. The previous pseudo-random
   fallback only *looked* like a QR code but was unscannable, so it now shows
   an honest placeholder instead of a misleading matrix. */
function renderQRBox(el, text, size) {
  if (!el) return;
  el.innerHTML = '';
  if (typeof QRCode !== 'undefined') {
    new QRCode(el, { text: String(text ?? ''), width: size, height: size, colorDark: '#0B2D5B', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.M });
  } else {
    el.innerHTML = '<div class="qr-unavailable"><i class="fa-solid fa-qrcode"></i><span>QR غير متاح</span></div>';
  }
}
function makeQR(seedStr) {
  const d = document.createElement('div');
  d.className = 'qr-unavailable';
  d.innerHTML = '<i class="fa-solid fa-qrcode"></i><span>QR غير متاح</span>';
  return d;
}

/* Next repair number preview — shared by the on-screen receipt form */
function nextRepairPreview() {
  const num = Math.max(2000, ...REPAIRS.map(r => parseInt((r.id || '').replace(/\D/g, '') || 0, 10))) + 1;
  const id = (SETTINGS.repPrefix || 'RP-') + num;
  const barcode = '628000000' + String(num).padStart(4, '0');
  return { num, id, barcode, qr: 'https://warsha.pro/' + id };
}
function updateReceiptCodes() {
  try {
    const p = nextRepairPreview();
    genBarcode($('#form-barcode'), p.barcode);
    renderQRBox($('#form-qr'), p.qr, 92);
    const nums = $$('#receipt-sheet .rcode-num');
    if (nums[0]) nums[0].textContent = p.barcode;
    if (nums[1]) nums[1].textContent = p.id;
    const no = document.querySelector('.r-repair-no b');
    if (no) no.textContent = p.id;
  } catch (e) {}
}

/* ---------- Rendering ---------- */
function esc(s) { return String(s ?? '').replace(/[&<>"'`]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;', '`': '&#96;' }[c])); }
// Allow-list sanitizers for values injected into class/style/url/src attributes
function safeCls(v, fallback = '') {
  const s = String(v ?? '').trim();
  return /^[a-zA-Z0-9_-]+( [a-zA-Z0-9_-]+)*$/.test(s) ? s : fallback;
}
function safeIcon(v) {
  const s = String(v ?? '').trim();
  return /^fa-[a-z0-9-]+$/.test(s) ? s : 'fa-box';
}
function safeURL(u) {
  const s = String(u ?? '').trim();
  return /^(https?:\/\/|mailto:|tel:|https:\/\/wa\.me\/|https:\/\/t\.me\/)/i.test(s) ? s : '#';
}
function safeLogo(src) {
  const s = String(src ?? '');
  return s.startsWith('data:image/') ? s : '';
}

function statusChip(status) {
  const s = STATUS[status] || STATUS.received;
  return `<span class="chip ${s.chip}">${s.label}</span>`;
}

function customerPayments(name) {
  const sales = sum(SALES.filter(s => s.customer === name), 'total');
  const unrecorded = REPAIRS.filter(r => r.customer === name && !r.paidNo && !r.revenueNo).reduce((s, r) => s + (Number(r.amount) || 0), 0);
  return sales + unrecorded;
}

function renderCustomers() {
  const tb = $('#customers-table');
  tb.innerHTML = CUSTOMERS.map((c, i) => `
    <tr data-customer="${esc(c.name)}">
      <td><div class="cell-user"><div class="avatar sm ${AVATARS[i % 6]}">${esc(c.name[0])}</div><div><b>${esc(c.name)}</b><small>${esc(c.type)}</small></div></div></td>
      <td dir="ltr" style="text-align:right">${esc(c.phone)}</td>
      <td>${esc(c.address)}</td>
      <td>${esc(c.repairs)} إصلاح</td>
      <td>${(Number(c.debt) || 0) > 0 ? `<b class="text-red">${cur(c.debt)}</b>` : '<span class="text-muted">—</span>'}</td>
      <td><b>${cur(customerPayments(c.name))}</b></td>
      <td>
        <div class="row-actions">
          <button class="icon-btn xs" data-action="view-customer"><i class="fa-solid fa-eye"></i></button>
          <button class="icon-btn xs" data-action="edit-customer"><i class="fa-solid fa-pen"></i></button>
          <button class="icon-btn xs danger" data-action="del-customer"><i class="fa-solid fa-trash"></i></button>
        </div>
      </td>
    </tr>`).join('');
  $('#customer-count').textContent = CUSTOMERS.length;
  renderCustomersStats();
  populatePosCustomers();
}

function renderRepairs(filter = 'all') {
  const tb = $('#repairs-table');
  const rows = REPAIRS.filter(r => filter === 'all' || r.status === filter);
  tb.innerHTML = rows.map(r => `
    <tr class="repair-row" data-id="${esc(r.id)}" data-status="${esc(r.status)}">
      <td><b class="repair-no">${esc(r.id)}</b></td>
      <td><div class="barcode barcode-sm" data-bc="${esc(r.barcode)}"></div><small class="bc-num">${esc(r.barcode)}</small></td>
      <td>${esc(r.customer)}</td>
      <td>${esc(r.device)}</td>
      <td>${statusChip(r.status)}</td>
      <td><b>${cur(r.amount)}</b></td>
      <td><span class="chip chip-orange">${esc(r.payment)}</span></td>
      <td>${esc(r.date)}</td>
      <td>
        <div class="row-actions">
          <button class="icon-btn xs" data-action="track-repair"><i class="fa-solid fa-location-arrow"></i></button>
          <button class="icon-btn xs" data-action="edit-repair"><i class="fa-solid fa-pen"></i></button>
        </div>
      </td>
    </tr>`).join('');
  $$('#repairs-table .barcode', tb).forEach(b => genBarcode(b, b.dataset.bc));
  renderStatusCounts();
  const cnt = $('#repairs-count');
  if (cnt) cnt.textContent = rows.length ? 'عرض ' + rows.length + ' من ' + REPAIRS.length + ' إصلاح' : 'لا توجد إصلاحات';
}

function renderStatusCounts() {
  const set = (id, n) => { const el = document.getElementById(id); if (el) el.textContent = n; };
  set('cnt-all', REPAIRS.length);
  Object.keys(STATUS).forEach(k => set('cnt-' + k, REPAIRS.filter(r => r.status === k).length));
}

/* ---------- Live data rendering (no demo data) ---------- */
const AR_MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
const MONTH_INDEX = { 'يناير': 0, 'فبراير': 1, 'مارس': 2, 'أبريل': 3, 'مايو': 4, 'يونيو': 5, 'يوليو': 6, 'أغسطس': 7, 'سبتمبر': 8, 'أكتوبر': 9, 'نوفمبر': 10, 'ديسمبر': 11 };

function monthOf(s) {
  if (!s) return -1;
  const m = MONTH_INDEX[(String(s).match(/(يناير|فبراير|مارس|أبريل|مايو|يونيو|يوليو|أغسطس|سبتمبر|أكتوبر|نوفمبر|ديسمبر)/) || [])[1]];
  return m == null ? -1 : m;
}
function toLatin(s) {
  return String(s)
    .replace(/[٠-٩]/g, c => '0123456789'['٠١٢٣٤٥٦٧٨٩'.indexOf(c)])
    .replace(/[۰-۹]/g, c => '0123456789'['۰۱۲۳۴۵۶۷۸۹'.indexOf(c)]);
}
function dayOf(s) {
  if (!s) return 0;
  const m = toLatin(s).match(/(\d+)/);
  return m ? parseInt(m[1], 10) || 0 : 0;
}
function yearOf(s) {
  if (!s) return -1;
  const m = toLatin(s).match(/(\d{4})/);
  return m ? parseInt(m[1], 10) || -1 : -1;
}
function isTodayStr(s) {
  if (!s) return false;
  const now = new Date();
  return dayOf(s) === now.getDate() && monthOf(s) === now.getMonth();
}
function lastMonthLabels(n) {
  const now = new Date(), out = [];
  for (let i = n - 1; i >= 0; i--) out.push(AR_MONTHS[new Date(now.getFullYear(), now.getMonth() - i, 1).getMonth()]);
  return out;
}
function monthSum(entries, field, n) {
  const labels = lastMonthLabels(n || 6);
  const now = new Date();
  const nowIdx = now.getFullYear() * 12 + now.getMonth();
  const data = labels.map(() => 0);
  (entries || []).forEach(e => {
    const m = monthOf(e.date);
    const y = yearOf(e.date);
    if (m < 0 || y < 0) return;
    const back = nowIdx - (y * 12 + m);
    const idx = labels.length - 1 - back;
    if (idx >= 0 && idx < labels.length) data[idx] += Number(e[field]) || 0;
  });
  return { labels, data };
}
function sum(entries, field) { return (entries || []).reduce((s, e) => s + (Number(e[field]) || 0), 0); }
function curSmall(v) { return (Number(v) || 0).toLocaleString('en-US') + ' <small>' + CURRENCY + '</small>'; }

/* ---------- Cost & profit (COGS) ---------- */
// Cost per sold unit: stored on the invoice when available, otherwise the product's buy price.
function saleItemCost(item) {
  if (!item) return 0;
  const qty = Number(item.qty) || 0;
  if (!qty) return 0;
  if (item.cost !== undefined && item.cost !== null && item.cost !== '') {
    const c = Number(item.cost);
    if (Number.isFinite(c)) return c * qty;
  }
  const p = PRODUCTS.find(x => x.name === item.name);
  const buy = p ? Number(p.buy) : 0;
  return (Number.isFinite(buy) ? buy : 0) * qty;
}
function saleCost(sale) {
  const items = sale && Array.isArray(sale.items) ? sale.items : [];
  return items.reduce((s, it) => s + saleItemCost(it), 0);
}
function salesCost(sales) {
  return (Array.isArray(sales) ? sales : []).reduce((s, x) => s + saleCost(x), 0);
}
function salesProfit(sales) {
  const list = Array.isArray(sales) ? sales : [];
  return sum(list, 'total') - salesCost(list);
}

// Monthly profit series (revenue − cost of goods sold) for the last n months.
function monthProfitSeries(n) {
  const labels = lastMonthLabels(n || 6);
  const now = new Date();
  const data = labels.map((_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - (labels.length - 1 - i), 1);
    const monthSales = SALES.filter(s => monthOf(s.date) === d.getMonth() && yearOf(s.date) === d.getFullYear());
    return salesProfit(monthSales);
  });
  return { labels, data };
}

function weeklyData() {
  const now = new Date();
  const wd = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const days = [];
  for (let i = 6; i >= 0; i--) { const d = new Date(now); d.setDate(now.getDate() - i); days.push({ y: d.getFullYear(), m: d.getMonth(), day: d.getDate(), wd: d.getDay() }); }
  const received = days.map(() => 0), delivered = days.map(() => 0);
  REPAIRS.forEach(r => {
    const hit = days.findIndex(d => d.day === dayOf(r.date) && d.m === monthOf(r.date) && (yearOf(r.date) < 0 || d.y === yearOf(r.date)));
    if (hit < 0) return;
    received[hit]++;
    if (r.status === 'delivered') delivered[hit]++;
  });
  return { labels: days.map(d => wd[d.wd]), received, delivered };
}

function salesByCategory() {
  const cats = ['شاشات', 'بطاريات', 'إكسسوارات', 'شواحن', 'قطع لابتوب', 'خدمات', 'أخرى'];
  const data = cats.map(() => 0);
  SALES.forEach(s => (s.items || []).forEach(it => {
    const name = it.name || '';
    let cat = 'أخرى';
    if (name.indexOf('إصلاح') === 0) cat = 'خدمات';
    else { const p = PRODUCTS.find(x => x.name === name); if (p) cat = p.cat || 'أخرى'; }
    const i = cats.indexOf(cat);
    if (i > -1) data[i] += (Number(it.price) || Number(it.total) || 0) * (Number(it.qty) || 1);
  }));
  return { labels: cats, data };
}

function renderDashboardStats() {
  const setStat = (n, v, t) => {
    const c = document.getElementById('st-card-' + n);
    if (!c) return;
    const vEl = c.querySelector('.stat-value');
    if (vEl) vEl.innerHTML = DASH_PRIVACY ? '•••' : v;
    const tEl = c.querySelector('.stat-trend');
    if (tEl) tEl.textContent = DASH_PRIVACY ? String(t || '').replace(/\d+/g, '•••') : (t || '');
  };
  const todayReps = REPAIRS.filter(r => isTodayStr(r.date));
  const todaySales = SALES.filter(s => isTodayStr(s.date));
  const revenue = sum(todaySales, 'total');
  const expenses = sum(PURCHASES.filter(p => isTodayStr(p.date)), 'total');
  const profit = salesProfit(todaySales);
  const waiting = REPAIRS.filter(r => r.status !== 'completed' && r.status !== 'delivered');
  const completed = REPAIRS.filter(r => r.status === 'completed' || r.status === 'delivered').length;
  setStat(1, todayReps.length, 'إصلاح اليوم');
  setStat(2, todayReps.filter(r => r.status === 'received').length, 'مستلمة اليوم');
  setStat(3, todayReps.filter(r => r.status === 'delivered').length, 'مسلّمة اليوم');
  setStat(4, curSmall(revenue), 'إيرادات اليوم');
  setStat(5, curSmall(expenses), 'مصروفات اليوم');
  setStat(6, curSmall(profit), 'بعد خصم التكلفة');
  setStat(7, waiting.length, waiting.filter(r => r.status === 'parts').length + ' بحاجة أجزاء');
  setStat(8, completed, 'مكتمل حتى الآن');
}

function renderNotifications() {
  const list = $('#np-list');
  if (!list) return;
  const ready = REPAIRS.filter(r => r.status === 'completed');
  const low = PRODUCTS.filter(p => (Number(p.qty) || 0) <= (Number(p.low) || 0));
  const items = [];
  ready.slice(0, 3).forEach(r => items.push(`<div class="np-item unread"><span class="np-ic ok"><i class="fa-solid fa-circle-check"></i></span><div><b>جهاز جاهز للتسليم</b><span>${esc(r.id)} — ${esc(r.device)}</span></div><small>الآن</small></div>`));
  low.slice(0, 3).forEach(p => items.push(`<div class="np-item unread"><span class="np-ic warn"><i class="fa-solid fa-triangle-exclamation"></i></span><div><b>مخزون منخفض</b><span>${esc(p.name)} وصل للحد الأدنى</span></div><small>الآن</small></div>`));
  const count = $('#np-count'); if (count) count.textContent = items.length;
  list.innerHTML = items.length ? items.join('') : '<div class="np-item"><span class="np-ic info"><i class="fa-solid fa-bell"></i></span><div><b>لا توجد إشعارات</b></div></div>';
}

function renderDashTimeline() {
  const tl = $('#dash-timeline');
  if (!tl) return;
  const items = REPAIRS.slice(0, 6).map(r => `<div class="tl-item">
    <span class="tl-dot ${r.status === 'delivered' ? 'ok' : r.status === 'completed' ? 'info' : 'warn'}"></span>
    <div class="tl-body"><p><b>${r.status === 'delivered' ? 'تسليم جهاز' : 'استلام جهاز'}</b> — ${esc(r.device)} #${esc(r.id)}</p>
    <span class="tl-time"><i class="fa-regular fa-clock"></i> ${esc(r.date)}</span></div>
    <span class="tl-tag ${r.status === 'delivered' ? 'tag-green' : 'tag-amber'}">${DASH_PRIVACY ? '•••' : cur(r.amount)}</span>
  </div>`);
  tl.innerHTML = items.length ? items.join('') : '<div class="empty-state">لا توجد نشاطات بعد</div>';
}

function renderDashTech() {
  const tb = $('#dash-tech-body');
  if (!tb) return;
  const techs = EMPLOYEES.filter(e => /فني/.test(e.role || '')).slice(0, 4);
  tb.innerHTML = techs.length ? techs.map((e, i) => {
    const pct = Math.min(100, Number(e.perf) || 0);
    const shown = DASH_PRIVACY ? '•••' : pct;
    return `<tr>
      <td><div class="cell-user"><div class="avatar sm av-${(i % 6) + 1}">${esc((e.name || '?')[0])}</div><div><b>${esc(e.name)}</b><small>${esc(e.role)}</small></div></div></td>
      <td><span class="chip chip-${e.chip || 'blue'}">${esc(e.role)}</span></td>
      <td>${shown}</td>
      <td><div class="progress"><span class="bar" style="width:${DASH_PRIVACY ? 0 : pct}%"></span></div><small class="pct">${shown}${DASH_PRIVACY ? '' : '%'}</small></td>
    </tr>`;
  }).join('') : '<tr><td colspan="4" class="empty-state">لا توجد بيانات لعرضها</td></tr>';
}

/* ---------- Dashboard privacy toggle ---------- */
function updateDashPrivacyBtn() {
  const view = document.getElementById('view-dashboard');
  if (view) view.classList.toggle('dash-privacy', DASH_PRIVACY);
  const btn = document.getElementById('dash-privacy-btn');
  if (!btn) return;
  const ic = btn.querySelector('i');
  const sp = btn.querySelector('span');
  if (ic) ic.className = 'fa-solid ' + (DASH_PRIVACY ? 'fa-eye-slash' : 'fa-eye');
  if (sp) sp.textContent = DASH_PRIVACY ? 'إظهار الأرقام' : 'إخفاء الأرقام';
  btn.title = DASH_PRIVACY ? 'إظهار الأرقام' : 'إخفاء الأرقام';
  btn.setAttribute('aria-pressed', String(!DASH_PRIVACY));
}
function applyDashPrivacy() {
  const view = document.getElementById('view-dashboard');
  if (view) view.classList.toggle('dash-privacy', DASH_PRIVACY);
  updateDashPrivacyBtn();
  renderDashboardStats();
  renderDashTimeline();
  renderDashTech();
  try { initCharts(); } catch (e) {}
}

function renderDevicesStats() {
  const cls = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  const d = REPAIRS.map(r => String(r.device || '').toLowerCase());
  const count = rx => d.filter(x => rx.test(x)).length;
  cls('dev-phones', count(/iphone|galaxy|pixel|huawei|xiaomi|oppo|هاتف|samsung|نوكيا/));
  cls('dev-laptops', count(/laptop|macbook|thinkpad|dell|asus|لابتوب/));
  cls('dev-tablets', count(/ipad|\btab\b|tablet|اللوحي|التبليت/));
  cls('dev-watches', count(/watch|ساعة/));
}

function renderInventoryStats() {
  const cls = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  cls('inv-total', PRODUCTS.length);
  const valEl = document.getElementById('inv-value');
  if (valEl) valEl.innerHTML = curSmall(PRODUCTS.reduce((s, p) => s + (Number(p.qty) || 0) * (Number(p.sell) || 0), 0));
  cls('inv-onorder', PORDERS.filter(p => p.status === 'قيد التوريد').length);
  cls('inv-low', PRODUCTS.filter(p => (Number(p.qty) || 0) <= (Number(p.low) || 0)).length);
}

function renderPurchasesStats() {
  const cls = (id, v, small) => { const el = document.getElementById(id); if (el) el.innerHTML = small ? curSmall(v) : v; };
  const now = new Date();
  const monthPurch = PURCHASES.filter(p => monthOf(p.date) === now.getMonth()).reduce((s, p) => s + (Number(p.total) || 0), 0);
  cls('pur-month', monthPurch, true);
  cls('pur-due', sum(PURCHASES, 'left'), true);
  cls('pur-completed', PURCHASES.filter(p => p.status === 'مدفوع').length);
  cls('pur-pending', PORDERS.filter(p => p.status !== 'مستلم').length);
}

function renderFinancialStats() {
  const setCard = (n, v, t) => {
    const c = document.getElementById('fin-card-' + n);
    if (!c) return;
    const vEl = c.querySelector('.stat-value'); if (vEl) vEl.innerHTML = curSmall(v);
    const tEl = c.querySelector('.stat-trend'); if (tEl) tEl.textContent = t || '';
  };
  const sales = sum(SALES, 'total');
  const purchases = sum(PURCHASES, 'total');
  const cogs = salesCost(SALES);
  const profit = sales - cogs;
  const purchaseDues = PURCHASES.reduce((s, p) => s + Math.max(0, (Number(p.total) || 0) - (Number(p.paid) || 0)), 0);
  setCard(1, sales, 'إجمالي المبيعات');
  setCard(2, purchases, 'إجمالي المشتريات');
  setCard(3, purchaseDues, 'مستحقات الموردين');
  setCard(4, profit, profit >= 0 ? 'ربح بعد خصم التكلفة' : 'خسارة بعد خصم التكلفة');
  const todaySales = SALES.filter(s => isTodayStr(s.date));
  const cls = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = cur(v); };
  cls('close-cash', sum(todaySales.filter(s => s.pay === 'نقداً'), 'total'));
  cls('close-card', sum(todaySales.filter(s => s.pay === 'بطاقة'), 'total'));
  cls('close-transfer', sum(todaySales.filter(s => s.pay === 'تحويل'), 'total'));
  cls('close-due', sum(todaySales.filter(s => s.pay === 'آجل'), 'total'));
  const todayExp = PURCHASES.filter(p => isTodayStr(p.date)).reduce((s, p) => s + (Number(p.total) || 0), 0);
  const expEl = document.getElementById('close-exp'); if (expEl) expEl.textContent = '-' + cur(todayExp);
  const netEl = document.getElementById('close-total'); if (netEl) netEl.textContent = cur(sum(todaySales, 'total') - todayExp);
  const taxRate = Number(SETTINGS.tax) || 0;
  // SALES/PURCHASES totals already include tax — extract the tax portion instead of taxing again
  const taxFrac = taxRate ? (taxRate / (100 + taxRate)) : 0;
  const tSales = sum(SALES, 'total') * taxFrac;
  const tPurch = sum(PURCHASES, 'total') * taxFrac;
  cls('tax-sales', tSales);
  cls('tax-purchases', tPurch);
  cls('tax-net', tSales - tPurch);
  const now = new Date();
  const sameMonth = (s) => monthOf(s) === now.getMonth() && yearOf(s) === now.getFullYear();
  const monthSales = SALES.filter(s => sameMonth(s.date)).reduce((s, x) => s + (Number(x.total) || 0), 0);
  const monthPurch = PURCHASES.filter(p => sameMonth(p.date)).reduce((s, x) => s + (Number(x.total) || 0), 0);
  const monthDues = PURCHASES.filter(p => sameMonth(p.date)).reduce((s, x) => s + Math.max(0, (Number(x.total) || 0) - (Number(x.paid) || 0)), 0);
  const monthProfit = salesProfit(SALES.filter(s => sameMonth(s.date)));
  const setMS = (id, v, pct) => {
    const el = document.getElementById(id); if (el) el.innerHTML = v;
    const bar = el && el.closest('.ms-bar'); if (bar) bar.style.setProperty('--p', pct + '%');
  };
  const maxV = Math.max(1, monthSales, monthPurch, monthDues, Math.abs(monthProfit));
  setMS('ms-sales', curSmall(monthSales), Math.round(monthSales / maxV * 100));
  setMS('ms-purchases', curSmall(monthPurch), Math.round(monthPurch / maxV * 100));
  setMS('ms-expenses', curSmall(monthDues), Math.round(monthDues / maxV * 100));
  setMS('ms-profit', curSmall(monthProfit), Math.round(Math.abs(monthProfit) / maxV * 100));
  const badges = $('#ms-badges');
  if (badges) {
    if (monthSales > 0) badges.innerHTML = '<span class="chip chip-blue">هامش ربح ' + Math.round(monthProfit / monthSales * 100) + '%</span>';
    else badges.innerHTML = '<span class="chip chip-blue">لا توجد بيانات بعد</span>';
  }
  // Keep charts in sync with the latest data (initCharts destroys previous instances first)
  try { initCharts(); } catch (e) {}
}

function renderEmployeeStats() {
  const cls = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  cls('emp-total', EMPLOYEES.length);
  cls('emp-techs', EMPLOYEES.filter(e => /فني/.test(e.role || '')).length);
  cls('emp-now', EMPLOYEES.filter(e => e.status === 'مباشر').length);
  const ratings = EMPLOYEES.map(e => Number(e.rating)).filter(n => !isNaN(n));
  cls('emp-rating', ratings.length ? (ratings.reduce((a, b) => a + b, 0) / ratings.length).toFixed(1) : 0);
}

function renderReportsPage() {
  const now = new Date();
  const period = $('#report-period'); if (period) period.textContent = 'هذا الشهر — ' + AR_MONTHS[now.getMonth()] + ' ' + now.getFullYear();
  const from = $('#report-from'); if (from) from.value = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
  const to = $('#report-to'); if (to) to.value = now.toISOString().slice(0, 10);
  const tb = $('#reports-customers-body');
  if (!tb) return;
  const row = (c, i) => {
    const pays = customerPayments(c.name);
    const purchases = SALES.filter(s => s.customer === c.name && s.kind !== 'repair').length;
    return `<tr><td><span class="rank ${i < 3 ? 'rank-' + (i + 1) : ''}">${i + 1}</span></td>
    <td><div class="cell-user"><div class="avatar sm av-${(i % 6) + 1}">${esc((c.name || '?')[0])}</div><div><b>${esc(c.name)}</b><small>${esc(c.type || 'عميل')}</small></div></div></td>
    <td>${c.repairs || 0}</td><td>${purchases}</td><td><b>${cur(pays)}</b></td><td>${esc(c.lastVisit || '—')}</td></tr>`;
  };
  const sorted = CUSTOMERS.slice().sort((a, b) => customerPayments(b.name) - customerPayments(a.name)).slice(0, 5);
  tb.innerHTML = sorted.length ? sorted.map(row).join('') : '<tr><td colspan="6" class="empty-state">لا توجد بيانات لعرضها</td></tr>';
}

function resetTrackCard() {
  const el = (id, v) => { const x = document.getElementById(id); if (x) x.textContent = v; };
  el('track-device-name', 'اختر إصلاحاً من الجدول');
  el('track-customer', 'لا يوجد إصلاح محدد');
  el('track-tech', '—');
  el('track-date', '—');
  el('track-amount', '—');
  const bc = $('#track-barcode');
  if (bc) { genBarcode(bc, ''); const lbl = bc.nextElementSibling; if (lbl) lbl.textContent = '—'; }
  const st = $('#track-status'); if (st) st.innerHTML = '<option value="">—</option>';
  const tl = $('#track-timeline'); if (tl) tl.innerHTML = '<div class="empty-state">اختر إصلاحاً من الجدول لعرض مساره</div>';
}

function populateCompanySettings() {
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v == null ? '' : v; };
  set('s-company-name', SETTINGS.company);
  set('s-cr', SETTINGS.cr);
  set('s-taxno', SETTINGS.taxno);
  set('s-mobile', SETTINGS.mobile);
  set('s-phone', SETTINGS.phone);
  set('s-address', SETTINGS.address);
  set('s-inv-prefix', SETTINGS.invPrefix || 'INV-');
  set('s-rep-prefix', SETTINGS.repPrefix || 'RP-');
  const tax = $('#s-tax-rate'); if (tax && SETTINGS.tax != null) tax.value = String(SETTINGS.tax);
  const curSel = $('#s-currency'); if (curSel && SETTINGS.currency) curSel.value = SETTINGS.currency;
  const t = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v || '—'; };
  t('rf-company', SETTINGS.company);
  t('rf-address', SETTINGS.address);
  t('rf-phone', SETTINGS.phone);
}

function fmtDate(ts) {
  if (!ts) return '—';
  try { return new Date(ts).toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' }); } catch (e) { return '—'; }
}

function populateLicensePanel() {
  const box = $('#license-panel-content');
  if (!box) return;
  window.senior.licenseStatus().then(st => {
    let chip, chipCls, chipIcon;
    let typeText = '—', expiryText = '—';
    if (st.state === 'active') {
      chipCls = 'active'; chipIcon = 'fa-circle-check';
      typeText = st.label;
      expiryText = st.expiresAt ? fmtDate(st.expiresAt) + (st.daysLeft ? ' (متبقي ' + st.daysLeft + ' يوم)' : '') : 'لا ينتهي';
      chip = 'مفعّل — ' + st.label;
    } else if (st.state === 'trial-active') {
      chipCls = 'trial'; chipIcon = 'fa-hourglass-half';
      typeText = 'فترة تجريبية';
      expiryText = 'متبقي ' + st.daysLeft + ' يوم';
      chip = 'فترة تجريبية — متبقي ' + st.daysLeft + ' يوم';
    } else if (st.state === 'expired') {
      chipCls = 'expired'; chipIcon = 'fa-triangle-exclamation';
      if (st.reason === 'annual') {
        typeText = 'سنوي (منتهي)';
        chip = 'انتهى الاشتراك السنوي';
      } else if (st.reason === 'hardware') {
        typeText = 'بصمة جهاز مختلفة';
        chip = 'تغيّرت بصمة الجهاز — يلزم كود جديد';
      } else {
        typeText = 'تجريبية (منتهية)';
        chip = 'انتهت الفترة التجريبية';
      }
    } else {
      chipCls = 'trial'; chipIcon = 'fa-hourglass-half';
      typeText = 'لم تبدأ بعد';
      chip = 'لم تبدأ الفترة التجريبية';
    }
    const canRekey = st.state !== 'active';
    box.innerHTML =
      '<div class="license-box">' +
      '<div class="license-status-line"><span class="license-chip ' + chipCls + '"><i class="fa-solid ' + chipIcon + '"></i> ' + chip + '</span></div>' +
      '<div class="license-grid">' +
      '<div class="license-item"><b>نوع الاشتراك</b><div>' + typeText + '</div></div>' +
      '<div class="license-item"><b>تاريخ الانتهاء</b><div>' + expiryText + '</div></div>' +
      '<div class="license-item"><b>بصمة الجهاز (العتاد)</b><div class="license-mc">' + st.machine + '</div></div>' +
      '</div>' +
      '<div class="license-note">البصمة مبنية على المعالج واللوحة الأم وBIOS وأقراص الجهاز. أي تغيير في هذه القطع أو نقل النسخة إلى جهاز آخر يولّد بصمة جديدة ويُلغي الترخيص القديم. أرسل البصمة الحالية لمدير النظام للحصول على كود جديد.</div>' +
      '<div class="license-actions"><button class="btn btn-accent btn-sm" id="lic-copy"><i class="fa-solid fa-copy"></i> نسخ بصمة الجهاز</button></div>' +
      (canRekey ?
        '<div class="license-rekey"><label>لديك كود تفعيل جديد؟</label>' +
        '<div style="display:flex;gap:8px;margin-top:8px">' +
        '<input type="text" id="lic-key" placeholder="SP1-L-EVER-XXXXXXXX" class="input-sm" style="flex:1" autocomplete="off">' +
        '<button class="btn btn-navy btn-sm" id="lic-apply">تفعيل</button></div>' +
        '<div id="lic-msg"></div></div>' : '') +
      '</div>';

    const copyBtn = $('#lic-copy');
    if (copyBtn) copyBtn.addEventListener('click', () => {
      navigator.clipboard.writeText(st.machine).then(() => toast('تم نسخ بصمة الجهاز'));
    });
    const applyBtn = $('#lic-apply');
    if (applyBtn) applyBtn.addEventListener('click', () => {
      const key = ($('#lic-key').value || '').trim();
      const msg = $('#lic-msg');
      if (!key) { msg.innerHTML = '<span style="color:#DC2626;font-size:12.5px">أدخل كود التفعيل أولاً</span>'; return; }
      applyBtn.disabled = true;
      window.senior.activate(key).then(res => {
        applyBtn.disabled = false;
        if (res && res.ok) {
          msg.innerHTML = '<span style="color:#16A34A;font-size:12.5px">' + esc(res.message) + ' — جارٍ إعادة التشغيل...</span>';
          setTimeout(() => window.senior.reload(), 1200);
        } else {
          msg.innerHTML = '<span style="color:#DC2626;font-size:12.5px">' + esc((res && res.message) || 'كود غير صحيح') + '</span>';
        }
      });
    });
  }).catch(() => {
    box.innerHTML = '<div class="license-loading">تعذر تحميل حالة الترخيص</div>';
  });
}

/* ---------- License enforcement: lock screen when expired ---------- */
function enforceLicense() {
  try {
    const st = licStatus();
    if (st.state !== 'expired') return false;
    const lock = $('#actlock');
    if (!lock) return false;
    lock.classList.add('show');
    const mc = $('#actlock-machine'); if (mc) mc.value = st.machine;
    const warn = $('#actlock-warn-text');
    if (warn) warn.textContent = st.reason === 'annual'
      ? 'انتهى اشتراك البرنامج من فضلك أدخل كود تفعيل جديد'
      : st.reason === 'hardware'
        ? 'تغيّرت بصمة العتاد (قرص/BIOS/لوحة أم أو نقل النسخة). أرسل البصمة الظاهرة لمدير النظام للحصول على كود تفعيل جديد'
        : 'هذه النسخة غير مرخصة من فضلك أدخل كود التفعيل';
    const key = $('#actlock-key');
    if (key) {
      setTimeout(() => key.focus(), 300);
      key.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { const b = document.querySelector('[data-action="actlock-go"]'); if (b) b.click(); }
      });
    }
    return true;
  } catch (e) { return false; }
}
function actlockMsg(text, ok) {
  const el = $('#actlock-msg');
  if (!el) return;
  el.textContent = text || '';
  el.className = 'actlock-msg ' + (ok ? 'ok' : 'err');
}

function renderCustomersStats() {
  const cls = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  const now = new Date();
  const monthCusts = new Set(REPAIRS.filter(r => monthOf(r.date) === now.getMonth() && (yearOf(r.date) < 0 || yearOf(r.date) === now.getFullYear())).map(r => r.customer));
  const activeCusts = new Set(REPAIRS.filter(r => Number(r.amount) > 0).map(r => r.customer));
  cls('cust-total', CUSTOMERS.length);
  cls('cust-active', activeCusts.size);
  cls('cust-month', monthCusts.size);
  cls('cust-loyal', CUSTOMERS.filter(c => /دائم/.test(c.type || '')).length);
}

function refreshLiveData() {
  renderDashboardStats();
  renderCustomersStats();
  renderNotifications();
  renderDashTimeline();
  renderDashTech();
  renderDevicesStats();
  renderInventoryStats();
  renderPurchasesStats();
  renderFinancialStats();
  renderEmployeeStats();
  renderReportsPage();
}

/* ---------- Repair parts (stock integration) ---------- */
function populateRepairPartsSelect() {
  const sel = $('#rp-part-select');
  if (!sel) return;
  const prev = sel.value;
  sel.innerHTML = PRODUCTS.map(p => `<option value="${esc(p.name)}">${esc(p.name)} — ${cur(p.sell)} (متوفر ${Number(p.qty) || 0})</option>`).join('');
  if (prev && PRODUCTS.some(p => p.name === prev)) sel.value = prev;
}

function renderRepairParts() {
  const box = $('#rp-parts-list');
  const empty = $('#rp-parts-empty');
  if (!box) return;
  if (empty) empty.style.display = REPAIR_PARTS.length ? 'none' : '';
  box.innerHTML = REPAIR_PARTS.map(p => `
    <div class="part-row">
      <span class="part-name">${esc(p.name)}</span>
      <span class="part-qty">أ— ${p.qty}</span>
      <span class="part-price">${cur((Number(p.price) || 0) * p.qty)}</span>
      <button class="icon-btn xs danger" data-action="remove-repair-part" data-part="${esc(p.name)}" title="إزالة"><i class="fa-solid fa-xmark"></i></button>
    </div>`).join('');
  if (typeof calcPricing === 'function') calcPricing();
}

/* ---------- Purchase invoice lines (product picker) ---------- */
function renderPOLines() {
  const box = $('#po-lines-list');
  if (!box) return;
  const empty = $('#po-lines-empty');
  if (empty) empty.style.display = PO_LINES.length ? 'none' : '';
  box.innerHTML = PO_LINES.map(l => `
    <div class="part-row">
      <span class="part-name">${esc(l.name)}</span>
      <span class="part-qty">
        <button class="icon-btn xs" data-action="po-line-qty" data-line="${esc(l.name)}" data-d="-1" title="تقليل"><i class="fa-solid fa-minus"></i></button>
        <b class="part-qty-num">${l.qty}</b>
        <button class="icon-btn xs" data-action="po-line-qty" data-line="${esc(l.name)}" data-d="1" title="زيادة"><i class="fa-solid fa-plus"></i></button>
      </span>
      <span class="part-price">${cur((Number(l.price) || 0) * l.qty)}</span>
      <button class="icon-btn xs danger" data-action="remove-po-line" data-line="${esc(l.name)}" title="إزالة"><i class="fa-solid fa-xmark"></i></button>
    </div>`).join('');
  const t = PO_LINES.reduce((s, l) => s + (Number(l.price) || 0) * l.qty, 0);
  const totalEl = $('#po-lines-total');
  if (totalEl) totalEl.textContent = cur(t);
  const itemsEl = $('#np-items');
  if (itemsEl) itemsEl.value = PO_LINES.length;
  const peItemsEl = $('#pe-items');
  if (peItemsEl) peItemsEl.value = PO_LINES.length;
  const peLabel = $('#pe-items-label');
  if (peLabel) peLabel.textContent = PO_LINES.length ? '— ' + PO_LINES.length + ' صنف' : '';
  const seItemsEl = $('#se-items');
  if (seItemsEl) seItemsEl.value = PO_LINES.length;
  const seLabel = $('#se-items-label');
  if (seLabel) seLabel.textContent = PO_LINES.length ? '— ' + PO_LINES.length + ' صنف' : '';
  const seData = $('#se-data');
  if (seData) {
    const disc = parseFloat(seData.dataset.disc || '0');
    const taxRate = parseFloat(seData.dataset.taxRate || '0');
    const taxEnabled = seData.dataset.taxEnabled !== 'false';
    const d = Math.min(disc, t);
    const tx = taxEnabled ? (t - d) * taxRate / 100 : 0;
    const seTotalEl = $('#se-total');
    if (seTotalEl) seTotalEl.value = Math.round((t - d + tx) * 100) / 100;
  }
}

/* ---------- Repair delivery → revenue ---------- */
function recordRepairPayment(r, amount, tag) {
  if (!r || amount <= 0) return '';
  const last = Math.max(0, ...SALES.map(s => parseInt((s.no || '').replace(/\D/g, '') || '0', 10)));
  const no = (SETTINGS.invPrefix || 'INV-') + (last + 1);
  const sale = {
    no,
    date: new Date().toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' }),
    time: new Date().toLocaleTimeString('ar-SA-u-ca-gregory', { hour: 'numeric', minute: '2-digit' }),
    items: [{ name: (tag === 'paid' ? 'دفعة استلام — إصلاح ' : 'باقي إصلاح ') + r.id, price: amount, qty: 1 }],
    sub: amount, disc: 0, tax: 0, taxRate: 0, total: amount,
    pay: r.payment || 'نقداً',
    cashier: SESSION ? (SESSION.name || 'مدير النظام') : 'مدير النظام',
    kind: 'repair', ref: r.id, customer: r.customer
  };
  SALES.unshift(sale);
  DB.set('sales', SALES);
  return no;
}

function recordRepairRevenue(r) {
  if (!r || r.status !== 'delivered' || r.revenueNo) return r && r.revenueNo;
  const amount = Math.max((Number(r.amount) || 0) - (Number(r.paid) || 0), 0);
  if (amount <= 0) return '';
  const rev = recordRepairPayment(r, amount, 'left');
  if (rev) r.revenueNo = rev;
  return rev;
}

function setRepairStatus(r, newStatus) {
  if (!r || r.status === newStatus) return;
  r.status = newStatus;
  let rev = r.revenueNo;
  if (newStatus === 'delivered' && !r.revenueNo) {
    rev = recordRepairRevenue(r);
  }
  DB.set('repairs', REPAIRS);
  renderRepairs();
  renderStatusCounts();
  updateTrackCard(r);
  renderFinancialStats(); renderDashboardStats(); renderCustomersStats();
  toast(`تم تحديث حالة ${r.id} إلى «${STATUS[newStatus]?.label || newStatus}»` + (rev ? ` — سُجل باقي المبلغ برقم ${rev}` : ''));
}

function renderDevices() {
  const tb = $('#devices-table');
  const list = REPAIRS.map(r => ({ device: r.device, serial: '', imei: '', customer: r.customer, status: r.status, tech: '', date: r.date, id: r.id }));
  if (!list.length) { tb.innerHTML = '<tr><td colspan="7" class="empty-state">لا توجد أجهزة بعد — استلم جهازاً من صفحة الاستلام</td></tr>'; return; }
  tb.innerHTML = list.map(d => `
    <tr>
      <td><div class="cell-user"><div class="dev-ic"><i class="fa-solid fa-mobile-screen-button"></i></div><div><b>${esc(d.device)}</b><small>${esc(d.id)}</small></div></div></td>
      <td>—</td>
      <td>${esc(d.customer)}</td>
      <td>${statusChip(d.status)}</td>
      <td>—</td>
      <td>${esc(d.date)}</td>
      <td><div class="row-actions"><button class="icon-btn xs" data-action="track-repair" title="تتبع"><i class="fa-solid fa-location-arrow"></i></button></div></td>
    </tr>`).join('');
}

function renderProducts() {
  const tb = $('#products-table');
  if (!tb) return;
  tb.innerHTML = PRODUCTS.map((p, i) => {
    const qty = Number(p.qty) || 0;
    const low = Number(p.low) || 0;
    const isLow = qty <= low;
    return `
    <tr data-product="${esc(p.name)}">
      <td><div class="cell-user"><div class="prod-ic">${['🖥','🔋','⚡','🧩','🎧','🖲'][i % 6]}</div><div><b>${esc(p.name)}</b></div></div></td>
      <td><div class="barcode barcode-sm" data-bc="${esc(p.barcode)}"></div><small class="bc-num">${esc(p.barcode)}</small></td>
      <td><span class="chip chip-blue">${esc(p.cat)}</span></td>
      <td><b>${cur(p.sell)}</b>${Number(p.minSell) > 0 ? `<small style="display:block;font-size:11px;color:var(--text-3)">أقل: ${cur(p.minSell)}</small>` : ''}</td>
      <td>${cur(p.buy)}</td>
      <td><b>${qty}</b></td>
      <td>${isLow ? `<span class="chip chip-red"><i class="fa-solid fa-triangle-exclamation"></i> ${qty === 0 ? 'نفد' : 'منخفض'}</span>` : `<span class="chip chip-green">متوفر</span>`}</td>
      <td><div class="row-actions">
        <button class="icon-btn xs" data-action="edit-product" title="تعديل"><i class="fa-solid fa-pen"></i></button>
        <button class="icon-btn xs danger" data-action="del-product" title="حذف"><i class="fa-solid fa-trash"></i></button>
      </div></td>
    </tr>`;
  }).join('');
  $$('#products-table .barcode', tb).forEach(b => genBarcode(b, b.dataset.bc));
  populateRepairPartsSelect();
  populatePosCustomers();
}

function renderSuppliers() {
  const tb = $('#suppliers-table');
  tb.innerHTML = SUPPLIERS.map((s, i) => `
    <tr data-supplier="${esc(s.name)}">
      <td><div class="cell-user"><div class="avatar sm av-${(i % 6) + 1}">${esc(s.name[0])}</div><b>${esc(s.name)}</b></div></td>
      <td dir="ltr" style="text-align:right">${esc(s.phone)}</td>
      <td>${esc(s.address)}</td>
      <td>${esc(s.cats)}</td>
      <td><b class="${s.due === 0 ? 'text-green' : 'text-red'}">${cur(s.due)}</b></td>
      <td><div class="row-actions">
        <button class="icon-btn xs" data-action="view-supplier" data-supplier="${esc(s.name)}" title="عرض"><i class="fa-solid fa-eye"></i></button>
        <button class="icon-btn xs" data-action="edit-supplier" data-supplier="${esc(s.name)}" title="تعديل"><i class="fa-solid fa-pen"></i></button>
        <button class="icon-btn xs" data-action="print-supplier" data-supplier="${esc(s.name)}" title="طباعة"><i class="fa-solid fa-print"></i></button>
        <button class="icon-btn xs danger" data-action="del-supplier" data-supplier="${esc(s.name)}" title="حذف"><i class="fa-solid fa-trash"></i></button>
      </div></td>
    </tr>`).join('');
}

function renderStock() {
  const tb = $('#stock-table');
  const rows = [];
  REPAIRS.forEach(r => (Array.isArray(r.parts) ? r.parts : []).forEach(p => {
    rows.push({ date: r.date || '', product: p.name || '', type: 'صادر', qty: p.qty || 0, ref: 'إصلاح #' + r.id, by: r.customer || '—' });
  }));
  DAMAGES.forEach(d => (Array.isArray(d.lines) ? d.lines : []).forEach(l => {
    rows.push({ date: d.dateText || isoToArabic(d.date), product: l.name || '', type: 'صادر', qty: l.qty || 0, ref: 'هالك ' + (d.no || ''), by: d.by || '—' });
  }));
  if (!rows.length) { tb.innerHTML = '<tr><td colspan="6" class="empty-state">لا توجد حركة مخزون بعد — تُسجّل تلقائياً عند خصم قطع من الإصلاحات أو تسجيل هالك</td></tr>'; return; }
  tb.innerHTML = rows.slice(0, 50).map(s => `
    <tr>
      <td>${esc(s.date)}</td>
      <td><b>${esc(s.product)}</b></td>
      <td>${s.type === 'وارد' ? '<span class="chip chip-green"><i class="fa-solid fa-arrow-down-long"></i> وارد</span>' : '<span class="chip chip-orange"><i class="fa-solid fa-arrow-up-long"></i> صادر</span>'}</td>
      <td><b>${s.qty}</b></td>
      <td>${esc(s.ref)}</td>
      <td>${esc(s.by)}</td>
    </tr>`).join('');
}

function renderPO() {
  const tb = $('#po-table');
  if (!tb) return;
  tb.innerHTML = PORDERS.map(p => `
    <tr>
      <td><b>${esc(p.no)}</b></td>
      <td>${esc(p.supplier)}</td>
      <td>${Number(p.items) || 0} صنف</td>
      <td><b>${cur(p.total)}</b></td>
      <td>${p.status === 'مستلم' ? '<span class="chip chip-green">مستلم</span>' : '<span class="chip chip-amber">قيد التوريد</span>'}</td>
      <td>${esc(p.date)}</td>
      <td><div class="row-actions">
        <button class="icon-btn xs" data-action="view-po" data-po="${esc(p.no)}" title="عرض"><i class="fa-solid fa-eye"></i></button>
        <button class="icon-btn xs" data-action="print-po" data-po="${esc(p.no)}" title="طباعة"><i class="fa-solid fa-print"></i></button>
        <button class="icon-btn xs danger" data-action="del-po" data-po="${esc(p.no)}" title="مسح"><i class="fa-solid fa-trash"></i></button>
      </div></td>
    </tr>`).join('');
}

function renderReturns() {
  const tb = $('#returns-table');
  if (!tb) return;
  if (!RETURNS.length) { tb.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#94A3B8;padding:22px">لا توجد مرتجعات بعد — اضغط «استلام مرتجع»</td></tr>'; return; }
  tb.innerHTML = RETURNS.map(r => {
    const prod = r.items ? r.items.map(i => i.name).join('، ') : (r.product || '—');
    const qty = r.items ? r.items.reduce((a, i) => a + i.qty, 0) : (r.qty || 0);
    const ref = r.saleNo || r.ref || '—';
    const type = r.type || 'جزئي';
    const amt = r.total != null ? r.total : (r.amount || 0);
    const status = r.status || 'مرتجع';
    const typeChip = type === 'للمورد'
      ? '<span class="chip chip-orange"><i class="fa-solid fa-truck"></i> للمورد</span>'
      : `<span class="chip chip-blue"><i class="fa-solid fa-user"></i> ${esc(type)}</span>`;
    return `<tr>
      <td><b>${esc(r.no || '—')}</b></td>
      <td><b>${esc(prod)}</b></td>
      <td>${qty}</td>
      <td>${esc(ref)}</td>
      <td>${typeChip}</td>
      <td><b class="text-red">${cur(amt)}</b></td>
      <td>${esc(r.date || '')}</td>
      <td>${status === 'مكتمل' ? '<span class="chip chip-green">مكتمل</span>' : '<span class="chip chip-amber">قيد المعالجة</span>'}</td>
      <td><div class="row-actions">
        <button class="icon-btn xs" data-action="view-return" data-return="${esc(r.no || '')}" title="عرض"><i class="fa-solid fa-eye"></i></button>
        <button class="icon-btn xs" data-action="print-return-pos" data-return="${esc(r.no || '')}" title="طباعة"><i class="fa-solid fa-print"></i></button>
        <button class="icon-btn xs danger" data-action="delete-return" data-return="${esc(r.no || '')}" title="حذف"><i class="fa-solid fa-trash"></i></button>
      </div></td>
    </tr>`;
  }).join('');
}

/* ---------- Damages / waste invoices ---------- */
function todayISO() {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}
function isoToArabic(iso) {
  const d = new Date(String(iso || '') + 'T00:00:00');
  if (isNaN(d.getTime())) return iso || '';
  return d.toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' });
}
function damageTotal(d) {
  const lines = Array.isArray(d && d.lines) ? d.lines : [];
  return d && d.total != null ? Number(d.total) || 0 : lines.reduce((s, l) => s + (Number(l.price) || 0) * (Number(l.qty) || 0), 0);
}
function filteredDamages() {
  if (DM_FILTER.all) return DAMAGES.slice();
  const from = DM_FILTER.from || '';
  const to = DM_FILTER.to || '';
  return DAMAGES.filter(d => {
    const dt = d.date || '';
    if (!dt) return false;
    if (from && dt < from) return false;
    if (to && dt > to) return false;
    return true;
  });
}
function renderDamages() {
  const tb = $('#damages-table');
  if (!tb) return;
  const list = filteredDamages();
  const total = list.reduce((s, d) => s + damageTotal(d), 0);
  const countEl = $('#dm-count'); if (countEl) countEl.textContent = list.length + ' فاتورة';
  const totalEl = $('#dm-total'); if (totalEl) totalEl.textContent = cur(total);
  if (!list.length) {
    tb.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#94A3B8;padding:26px">لا توجد فواتير هالك في هذه الفترة</td></tr>';
    return;
  }
  tb.innerHTML = list.map(d => {
    const lines = Array.isArray(d.lines) ? d.lines : [];
    const qty = lines.reduce((s, l) => s + (Number(l.qty) || 0), 0);
    const items = lines.length === 1 ? lines[0].name : lines.length + ' أصناف';
    return `<tr>
      <td><b>${esc(d.no || '—')}</b></td>
      <td>${esc(d.dateText || isoToArabic(d.date))}</td>
      <td><span class="chip chip-orange"><i class="fa-solid fa-recycle"></i> ${esc(d.type || 'الرئيسي')}</span></td>
      <td><b>${esc(items)}</b>${lines.length ? `<small style="display:block;font-size:11px;color:var(--text-3)">${qty} قطعة</small>` : ''}</td>
      <td><b class="text-red">${cur(damageTotal(d))}</b></td>
      <td><div class="row-actions">
        <button class="icon-btn xs" data-action="view-damage" data-damage="${esc(d.no || '')}" title="التفاصيل"><i class="fa-solid fa-eye"></i></button>
        <button class="icon-btn xs" data-action="print-damage" data-damage="${esc(d.no || '')}" title="طباعة"><i class="fa-solid fa-print"></i></button>
      </div></td>
      <td><button class="icon-btn xs danger" data-action="del-damage" data-damage="${esc(d.no || '')}" title="حذف واسترجاع الكمية"><i class="fa-solid fa-trash"></i></button></td>
    </tr>`;
  }).join('');
}
function renderDMLines() {
  const tb = $('#dm-lines-body');
  const empty = $('#dm-lines-empty');
  const table = $('#dm-lines-table');
  if (!tb) return;
  const has = DM_LINES.length > 0;
  if (empty) empty.style.display = has ? 'none' : '';
  if (table) table.style.display = has ? '' : 'none';
  tb.innerHTML = DM_LINES.map(l => `
    <tr>
      <td class="inv-name"><b>${esc(l.name)}</b></td>
      <td dir="ltr" style="text-align:right;font-family:Consolas,monospace">${esc(l.code || '')}</td>
      <td>${esc(l.unit || 'قطعة')}</td>
      <td>${cur(l.price)}</td>
      <td><b>${l.qty}</b></td>
      <td><b>${cur((Number(l.price) || 0) * l.qty)}</b></td>
      <td><button class="icon-btn xs danger" data-action="dm-remove-line" data-line="${esc(l.name)}" title="إزالة"><i class="fa-solid fa-xmark"></i></button></td>
    </tr>`).join('');
  const totalEl = $('#dm-lines-total');
  if (totalEl) totalEl.textContent = cur(DM_LINES.reduce((s, l) => s + (Number(l.price) || 0) * l.qty, 0));
}
function damageAddLine(auto) {
  const sel = $('#dm-product');
  let p = sel ? PRODUCTS.find(x => x.name === sel.value) : null;
  if (!p && auto) {
    const code = ($('#dm-code')?.value || '').trim().toLowerCase();
    if (code) p = PRODUCTS.find(x => String(x.barcode || '').toLowerCase() === code || String(x.name || '').toLowerCase() === code);
    if (p && sel) sel.value = p.name;
  }
  if (!p) { toast('اختر صنفاً أو امسح باركود صحيح', 'error'); return; }
  const qty = parseQty($('#dm-qty')?.value, 1);
  let price = Math.max(0, parseFloat($('#dm-price')?.value) || 0);
  if (!price) price = Number(p.buy) || 0;
  const unit = ($('#dm-unit')?.value || 'قطعة').trim() || 'قطعة';
  const inLines = DM_LINES.filter(l => l.name === p.name).reduce((s, l) => s + l.qty, 0);
  const have = Number(p.qty) || 0;
  if (inLines + qty > have) { toast(`الكمية أكبر من المتوفر في المخزون «${p.name}» (${have})`, 'error'); return; }
  const idx = DM_LINES.findIndex(l => l.name === p.name);
  if (idx > -1) DM_LINES[idx].qty += qty;
  else DM_LINES.push({ name: p.name, code: p.barcode || '', unit, price, qty });
  renderDMLines();
  const q = $('#dm-qty'); if (q) q.value = '1';
  const c = $('#dm-code'); if (c) c.value = p.barcode || '';
  const cp = $('#dm-price'); if (cp) cp.value = price;
  toast(`أُضيف «${p.name}» × ${qty}`, 'info');
}
function openDamageModal() {
  DM_LINES = [];
  const no = nextNum('DM-', DAMAGES);
  const prodOpts = PRODUCTS.map(p => `<option value="${esc(p.name)}">${esc(p.name)} — متوفر ${Number(p.qty) || 0}</option>`).join('');
  openModal(`
    <div class="modal-head"><h3><i class="fa-solid fa-recycle"></i> إضافة هالك</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="r-grid-2">
        <div class="field"><label>رقم الفاتورة</label><i class="fa-solid fa-file-invoice"></i><input type="text" id="dm-no" value="${esc(no)}" readonly></div>
        <div class="field"><label>التاريخ</label><i class="fa-solid fa-calendar"></i><input type="date" id="dm-date" value="${todayISO()}"></div>
        <div class="field"><label>بند الهالك</label><i class="fa-solid fa-tags"></i>
          <div class="select-wrap"><select id="dm-type"><option selected>الرئيسي</option><option>فرعي</option></select><i class="fa-solid fa-chevron-down"></i></div></div>
        <div class="field"><label>المخزن</label><i class="fa-solid fa-warehouse"></i>
          <div class="select-wrap"><select id="dm-store"><option selected>الرئيسي</option></select><i class="fa-solid fa-chevron-down"></i></div></div>
      </div>
      <div class="r-section" style="margin-top:14px">
        <legend><i class="fa-solid fa-box-open"></i> صنف الهالك</legend>
        <div class="parts-add dm-add">
          <div class="field grow"><label>الصنف</label>
            <div class="select-wrap"><select id="dm-product"><option value="">— اختر الصنف —</option>${prodOpts}</select><i class="fa-solid fa-chevron-down"></i></div>
          </div>
          <div class="field"><label>كود الصنف</label><i class="fa-solid fa-barcode"></i><input type="text" id="dm-code" placeholder="امسح الباركود ثم Enter"></div>
          <div class="field"><label>السعر</label><i class="fa-solid fa-tag"></i><input type="number" id="dm-price" min="0" step="0.01" value="0"></div>
          <div class="field"><label>الكمية</label><i class="fa-solid fa-hashtag"></i><input type="number" id="dm-qty" min="1" value="1"></div>
          <div class="field"><label>الوحدة</label><i class="fa-solid fa-ruler"></i><input type="text" id="dm-unit" value="قطعة"></div>
          <button class="btn btn-navy" data-action="dm-add-line"><i class="fa-solid fa-plus"></i> إضافة</button>
        </div>
        <div class="table-wrap" style="margin-top:10px">
          <table class="table" id="dm-lines-table" style="display:none">
            <thead><tr><th>الصنف</th><th>الكود</th><th>الوحدة</th><th>السعر</th><th>الكمية</th><th>الإجمالي</th><th></th></tr></thead>
            <tbody id="dm-lines-body"></tbody>
          </table>
          <div class="parts-empty" id="dm-lines-empty">لا توجد أصناف بعد — اختر الصنف والكمية ثم اضغط «إضافة»</div>
        </div>
      </div>
      <div class="cs-totals" style="margin-top:12px">
        <div><span>إجمالي الأصناف</span><b id="dm-lines-total">${cur(0)}</b></div>
      </div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" data-action="close-modal">إلغاء</button>
      <button class="btn btn-navy" data-action="save-damage-print"><i class="fa-solid fa-floppy-disk"></i> حفظ وطباعة</button>
      <button class="btn btn-accent" data-action="save-damage"><i class="fa-solid fa-check"></i> حفظ الفاتورة</button>
    </div>
  `);
  const prodSel = $('#dm-product');
  if (prodSel) prodSel.addEventListener('change', () => {
    const p = PRODUCTS.find(x => x.name === prodSel.value);
    if (!p) return;
    const codeEl = $('#dm-code'); if (codeEl) codeEl.value = p.barcode || '';
    const priceEl = $('#dm-price'); if (priceEl) priceEl.value = Number(p.buy) || 0;
  });
  const codeEl = $('#dm-code');
  if (codeEl) codeEl.addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    damageAddLine(true);
  });
  renderDMLines();
}
function saveDamage(printAfter) {
  if (!DM_LINES.length) { toast('أضف صنفاً واحداً على الأقل أولاً', 'error'); return; }
  // Re-validate stock at save time; stock may have changed since the lines were added.
  for (const l of DM_LINES) {
    const p = PRODUCTS.find(x => x.name === l.name);
    const have = p ? (Number(p.qty) || 0) : 0;
    if (!p || l.qty <= 0 || l.qty > have) {
      toast(`المخزون غير كافٍ للصنف «${l.name}» (المتاح: ${have})`, 'error');
      return;
    }
  }
  const dateISO = ($('#dm-date')?.value || '').trim() || todayISO();
  const d = {
    no: ($('#dm-no')?.value || '').trim() || nextNum('DM-', DAMAGES),
    date: dateISO,
    dateText: isoToArabic(dateISO),
    type: ($('#dm-type')?.value || 'الرئيسي').trim(),
    store: ($('#dm-store')?.value || 'الرئيسي').trim(),
    by: (SESSION && SESSION.name) || '',
    lines: DM_LINES.map(l => ({ ...l })),
    total: DM_LINES.reduce((s, l) => s + (Number(l.price) || 0) * l.qty, 0),
    createdAt: Date.now()
  };
  DAMAGES.unshift(d);
  DB.set('damages', DAMAGES);
  d.lines.forEach(l => {
    const p = PRODUCTS.find(x => x.name === l.name);
    if (p) p.qty = Math.max(0, (Number(p.qty) || 0) - (Number(l.qty) || 0));
  });
  DB.set('products', PRODUCTS);
  DM_LINES = [];
  closeModal();
  renderDamages(); renderProducts(); renderStock(); renderPOS();
  toast(`تم حفظ فاتورة الهالك ${d.no}`);
  if (printAfter) setTimeout(() => printDocument(buildDamageHTML(d)), 250);
}
function buildDamageHTML(d) {
  const lines = Array.isArray(d.lines) ? d.lines : [];
  return `
    <div class="inv-wrap">
      ${invoiceHead('فاتورة هالك', d.no, d.dateText || isoToArabic(d.date))}
      <div class="inv-info">
        <div><span>بند الهالك</span><b>${esc(d.type || 'الرئيسي')}</b></div>
        <div><span>المخزن</span><b>${esc(d.store || 'الرئيسي')}</b></div>
        <div><span>عدد الأصناف</span><b>${lines.length} صنف</b></div>
      </div>
      <table class="inv-table">
        <thead><tr><th>#</th><th>الصنف</th><th>الكود</th><th>الوحدة</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead>
        <tbody>${lines.map((l, i) => `<tr><td>${i + 1}</td><td class="inv-name">${esc(l.name)}</td><td dir="ltr" style="text-align:right">${esc(l.code || '')}</td><td>${esc(l.unit || 'قطعة')}</td><td>${l.qty}</td><td>${cur(l.price)}</td><td>${cur((Number(l.price) || 0) * l.qty)}</td></tr>`).join('')}</tbody>
      </table>
      <div class="inv-totals"><div class="inv-grand"><span>إجمالي الهالك</span><b>${cur(damageTotal(d))}</b></div></div>
      <div class="inv-foot"><p>${esc(SETTINGS.company || '')} — فاتورة هالك ${esc(d.no)}</p><small>${esc(d.by || '')}</small></div>
    </div>`;
}
function damageDetailsModal(d) {
  if (!d) return;
  const lines = Array.isArray(d.lines) ? d.lines : [];
  openModal(`
    <div class="modal-head"><h3><i class="fa-solid fa-recycle"></i> تفاصيل فاتورة الهالك ${esc(d.no)}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="inv-info" style="margin-bottom:12px">
        <div><span>التاريخ</span><b>${esc(d.dateText || isoToArabic(d.date))}</b></div>
        <div><span>بند الهالك</span><b>${esc(d.type || 'الرئيسي')}</b></div>
        <div><span>المخزن</span><b>${esc(d.store || 'الرئيسي')}</b></div>
      </div>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>الصنف</th><th>الكود</th><th>الوحدة</th><th>السعر</th><th>الكمية</th><th>الإجمالي</th></tr></thead>
        <tbody>${lines.map(l => `<tr><td><b>${esc(l.name)}</b></td><td dir="ltr" style="text-align:right">${esc(l.code || '')}</td><td>${esc(l.unit || 'قطعة')}</td><td>${cur(l.price)}</td><td>${l.qty}</td><td><b>${cur((Number(l.price) || 0) * l.qty)}</b></td></tr>`).join('')}</tbody>
      </table></div>
      <div class="cs-totals" style="margin-top:12px"><div><span>الإجمالي</span><b>${cur(damageTotal(d))}</b></div></div>
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" data-action="close-modal">إغلاق</button>
      <button class="btn btn-navy" data-action="print-damage" data-damage="${esc(d.no)}"><i class="fa-solid fa-print"></i> طباعة</button>
    </div>
  `);
}

function renderEmployees() {
  const grid = $('.employees-grid');
  if (grid) grid.innerHTML = EMPLOYEES.map(emp => {
    const perf = Math.min(100, Math.max(0, Number(emp.perf) || 0));
    return `
    <div class="emp-card card" data-emp="${esc(emp.name)}">
      <div class="emp-avatar ${safeCls(emp.color, 'av-1')}">${esc((emp.name || '?')[0])}</div>
      <h4>${esc(emp.name)}</h4>
      <span class="chip chip-${safeCls(emp.chip, 'blue')}">${esc(emp.role)}</span>
      <div class="emp-perf"><div class="progress"><span class="bar" style="width:${perf}%"></span></div><span class="pct">${perf}%</span></div>
      <div class="emp-stats"><div><b>${esc(emp.join)}</b><span>سنة الانضمام</span></div><div><b>${esc(emp.rating)}</b><span>التقييم</span></div></div>
      <div class="emp-actions">
        <button class="btn btn-ghost btn-sm" data-action="view-employee" data-emp="${esc(emp.name)}" title="عرض"><i class="fa-solid fa-eye"></i></button>
        <button class="btn btn-ghost btn-sm" data-action="edit-employee" data-emp="${esc(emp.name)}" title="تعديل بيانات الموظف"><i class="fa-solid fa-pen"></i></button>
        <button class="btn btn-ghost btn-sm danger" data-action="del-employee" data-emp="${esc(emp.name)}" title="حذف الموظف"><i class="fa-solid fa-trash"></i></button>
        </div>
      </div>`;
    }).join('');
  const tb = $('#emps-table');
  if (tb) tb.innerHTML = EMPLOYEES.map(emp => `
    <tr>
      <td><div class="cell-user"><div class="avatar sm ${safeCls(emp.color, 'av-1')}">${esc((emp.name || '?')[0])}</div><b>${esc(emp.name)}</b></div></td>
      <td>${esc(emp.role)}</td>
      <td>${esc(emp.attend)}</td>
      <td>${esc(emp.leave)}</td>
      <td>${emp.status === 'مباشر' ? '<span class="chip chip-green">مباشر</span>' : '<span class="chip chip-amber">إجازة</span>'}</td>
      <td>${esc(emp.task)}</td>
      <td><div class="row-actions">
        <button class="icon-btn xs" data-action="view-employee" data-emp="${esc(emp.name)}" title="عرض"><i class="fa-solid fa-eye"></i></button>
        <button class="icon-btn xs" data-action="edit-employee" data-emp="${esc(emp.name)}" title="تعديل"><i class="fa-solid fa-pen"></i></button>
        <button class="icon-btn xs danger" data-action="del-employee" data-emp="${esc(emp.name)}" title="حذف"><i class="fa-solid fa-trash"></i></button>
      </div></td>
    </tr>`).join('');
  const total = $('#emp-total'); if (total) total.textContent = EMPLOYEES.length;
}

function renderPurchases() {
  const tb = $('#purchases-table');
  tb.innerHTML = PURCHASES.map(p => `
    <tr data-po="${esc(p.no)}">
      <td><b>${esc(p.no)}</b></td>
      <td>${esc(p.supplier)}</td>
      <td>${Number(p.items) || 0} صنف</td>
      <td><b>${cur(p.total)}</b></td>
      <td>${cur(p.paid)}</td>
      <td class="${p.left === 0 ? 'text-green' : 'text-red'}"><b>${cur(p.left)}</b></td>
      <td>${p.status === 'مدفوع' ? '<span class="chip chip-green">مدفوع</span>' : p.status === 'جزئي' ? '<span class="chip chip-amber">جزئي</span>' : '<span class="chip chip-red">غير مدفوع</span>'}</td>
      <td>${esc(p.date)}</td>
      <td><div class="row-actions">
        <button class="icon-btn xs" data-action="view-purchase" data-po="${esc(p.no)}" title="عرض"><i class="fa-solid fa-eye"></i></button>
        <button class="icon-btn xs" data-action="edit-purchase" data-po="${esc(p.no)}" title="تعديل"><i class="fa-solid fa-pen"></i></button>
      </div></td>
    </tr>`).join('');
}

/* ---------- Installments ---------- */
function insPaid(plan) { return (plan.payments || []).reduce((s, p) => s + (Number(p.amount) || 0), 0); }
function insFinanced(plan) {
  const base = Math.max(0, (Number(plan.amount) || 0) - (Number(plan.down) || 0));
  const rate = Number(plan.rate) || 0;
  return Math.round(base * (1 + rate / 100));
}
function insInterest(plan) {
  const base = Math.max(0, (Number(plan.amount) || 0) - (Number(plan.down) || 0));
  return insFinanced(plan) - base;
}
function insTotal(plan) { return (Number(plan.down) || 0) + insFinanced(plan); }
function insRemaining(plan) { return Math.max(0, insTotal(plan) - (Number(plan.down) || 0) - insPaid(plan)); }
function insProgress(plan) { const t = insTotal(plan); return t ? Math.min(100, Math.round((((Number(plan.down) || 0) + insPaid(plan)) / t) * 100)) : 0; }
function insStatus(plan) {
  if (plan.status === 'مكتمل' || insRemaining(plan) === 0) return 'مكتمل';
  if (plan.status === 'متأخر') return 'متأخر';
  return 'نشط';
}
function insChip(status) {
  if (status === 'مكتمل') return '<span class="chip chip-green">مكتمل</span>';
  if (status === 'متأخر') return '<span class="chip chip-red">متأخر</span>';
  return '<span class="chip chip-blue">نشط</span>';
}

/* Payment schedule: coverage-based (partial/uneven payments map correctly),
   last row absorbs ceil() rounding so rows sum exactly to the financed amount */
function installmentSchedule(plan) {
  const months = Math.max(1, Number(plan.months) || 1);
  const financed = insFinanced(plan);
  const per = Math.max(0, Number(plan.perMonth) || 0);
  const pays = Array.isArray(plan.payments) ? plan.payments : [];
  const totalPaid = pays.reduce((s, p) => s + (Number(p.amount) || 0), 0);
  const rows = [];
  let acc = 0;
  for (let i = 0; i < months; i++) {
    const due = (i === months - 1) ? Math.max(0, financed - per * (months - 1)) : per;
    acc += due;
    const paid = Math.min(due, Math.max(0, totalPaid - (acc - due)));
    const pm = pays[i];
    rows.push({
      i: i + 1, amount: due, paid,
      date: (paid >= due && due > 0 && pm && pm.date) ? pm.date : plan.firstDue,
      note: (paid >= due && due > 0 && pm && pm.note) ? pm.note : '',
    });
  }
  return rows;
}

function renderInstallments(filter = 'all') {
  const tb = $('#installments-table');
  const match = (i) => filter === 'all' ? true : filter === 'نشط' ? insStatus(i) !== 'مكتمل' : insStatus(i) === filter;
  tb.innerHTML = INSTALLMENTS.filter(match).map(i => {
    const st = insStatus(i);
    return `
    <tr data-ins="${esc(i.no)}">
      <td><b>${esc(i.no)}</b></td>
      <td>${esc(i.customer)}</td>
      <td>${esc(i.device)}</td>
      <td><b>${cur(i.amount)}</b></td>
      <td>${cur(i.down)}</td>
      <td>${cur(i.perMonth)}</td>
      <td>${i.months} شهر</td>
      <td><b class="${insRemaining(i) === 0 ? 'text-green' : 'text-red'}">${cur(insRemaining(i))}</b></td>
      <td>${insChip(st)}</td>
      <td><div class="row-actions">
        <button class="icon-btn xs" data-action="view-installment" data-ins="${esc(i.no)}" title="عرض"><i class="fa-solid fa-eye"></i></button>
        <button class="icon-btn xs" data-action="pay-installment" data-ins="${esc(i.no)}" title="تسجيل دفعة"><i class="fa-solid fa-hand-holding-dollar"></i></button>
        <button class="icon-btn xs" data-action="print-installment" data-ins="${esc(i.no)}" title="طباعة"><i class="fa-solid fa-print"></i></button>
        <button class="icon-btn xs danger" data-action="del-installment" data-ins="${esc(i.no)}" title="حذف"><i class="fa-solid fa-trash"></i></button>
      </div></td>
    </tr>`;
  }).join('');
  $('#installments-count').textContent = INSTALLMENTS.length;
  $('#ins-active-count').textContent = INSTALLMENTS.filter(i => insStatus(i) !== 'مكتمل').length;
  $('#ins-total').textContent = cur(INSTALLMENTS.reduce((s, i) => s + insTotal(i), 0));
  $('#ins-paid').textContent = cur(INSTALLMENTS.reduce((s, i) => s + (Number(i.down) || 0) + insPaid(i), 0));
  $('#ins-remaining').textContent = cur(INSTALLMENTS.reduce((s, i) => s + insRemaining(i), 0));
}

function productPickOptions() {
  return `<option value="">— اختر منتجاً —</option>` + PRODUCTS.map(p => `<option value="${esc(p.name)}" data-price="${Number(p.sell) || 0}">${esc(p.name)} — ${cur(p.sell)}</option>`).join('');
}
function insItemRow(name, qty, price) {
  return `
    <div class="ins-item" data-name="${esc(name)}">
      <b>${esc(name)}</b>
      <input type="number" class="ins-item-qty" value="${esc(qty)}" min="1" title="الكمية">
      <input type="number" class="ins-item-price" value="${esc(price)}" min="0" title="سعر الوحدة">
      <span class="ins-item-total">${cur((Number(qty) || 0) * (Number(price) || 0))}</span>
      <button class="icon-btn xs danger" data-action="remove-ins-item" title="حذف"><i class="fa-solid fa-xmark"></i></button>
    </div>`;
}

function installmentAddModal(plan) {
  const isEdit = !!plan;
  const p = plan || { customer: '', items: [], amount: 0, down: 0, rate: 0, months: 6, perMonth: 0, fee: 0, firstDue: '', notes: '', status: 'نشط', payments: [] };
  const seedItems = Array.isArray(p.items) && p.items.length ? p.items : (p.device ? [{ name: p.device, qty: 1, price: (Number(p.amount) || 0) }] : []);
  const pFinanced = insFinanced(p);
  const pInterest = insInterest(p);
  openModal(`
    <div class="modal-head"><h3><i class="fa-solid fa-calendar-check"></i> ${isEdit ? 'تعديل خطة' : 'خطة تقسيط جديدة'}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="r-grid-2">
        <div class="field span-2"><label>العميل <b class="req">*</b></label><i class="fa-solid fa-user"></i>
          <input type="text" id="ins-customer" list="ins-customers" value="${esc(p.customer)}" placeholder="اسم العميل">
          <datalist id="ins-customers">${customersOptions()}</datalist>
        </div>
        <div class="field span-2">
          <label>المنتجات / الأجهزة <b class="req">*</b></label>
          <div class="ins-pick">
            <div class="select-wrap"><i class="fa-solid fa-chevron-down"></i><select id="ins-add-item">${productPickOptions()}</select></div>
            <button class="btn btn-ghost btn-sm" id="ins-add-item-btn"><i class="fa-solid fa-plus"></i> إضافة</button>
          </div>
          <div class="ins-items" id="ins-items">${seedItems.map(it => insItemRow(it.name, it.qty || 1, it.price || 0)).join('')}</div>
        </div>
        <div class="field"><label>إجمالي المبلغ <b class="req">*</b></label><i class="fa-solid fa-money-bill-wave"></i><input type="number" id="ins-amount" value="${esc(p.amount)}" placeholder="0"></div>
        <div class="field"><label>الدفعة المقدمة</label><i class="fa-solid fa-hand-holding-dollar"></i><input type="number" id="ins-down" value="${esc(p.down)}" placeholder="0"></div>
        <div class="field"><label>نسبة الزيادة (%)</label><i class="fa-solid fa-percent"></i><input type="number" id="ins-rate" value="${esc(p.rate || 0)}" placeholder="0" min="0" step="0.5"></div>
        <div class="field"><label>عدد الشهور</label><i class="fa-solid fa-calendar-week"></i><input type="number" id="ins-months" value="${esc(p.months)}" placeholder="6"></div>
        <div class="field"><label>أول استحقاق</label><i class="fa-regular fa-calendar"></i><input type="date" id="ins-first-due" value="${esc(p.firstDue)}"></div>
        <div class="field"><label>ملاحظات</label><i class="fa-solid fa-note-sticky"></i><input type="text" id="ins-notes" value="${esc(p.notes || '')}" placeholder="ملاحظات اختيارية"></div>
        <div class="ins-calc span-2">
          <div><span>الممول قبل الزيادة</span><b id="ins-financed">${cur(pFinanced - pInterest)}</b></div>
          <div><span>الفائدة بالمبلغ</span><b id="ins-interest">${cur(pInterest)}</b></div>
          <div><span>الممول النهائي</span><b id="ins-final">${cur(pFinanced)}</b></div>
        </div>
        <div class="ins-calc span-2">
          <div class="ins-grand"><span>الدفعة الشهرية</span><b id="ins-per-month">${cur(p.perMonth || Math.ceil(pFinanced / (p.months || 1)))}</b></div>
        </div>
      </div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-installment" data-ins="${esc(isEdit ? p.no : '')}"><i class="fa-solid fa-check"></i> ${isEdit ? 'حفظ التعديلات' : 'إضافة الخطة'}</button></div>
  `);
  const itemsBox = $('#ins-items');
  const calc = () => {
    const amount = parseFloat($('#ins-amount')?.value) || 0;
    const down = parseFloat($('#ins-down')?.value) || 0;
    const rate = parseFloat($('#ins-rate')?.value) || 0;
    const months = parseInt($('#ins-months')?.value) || 1;
    const base = Math.max(0, amount - down);
    const interest = base * rate / 100;
    const finalFinanced = Math.round(base + interest);
    $('#ins-financed').textContent = cur(base);
    $('#ins-interest').textContent = cur(interest);
    $('#ins-final').textContent = cur(finalFinanced);
    $('#ins-per-month').textContent = cur(months ? Math.ceil(finalFinanced / months) : 0);
  };
  const recalc = () => {
    const rows = [...itemsBox.querySelectorAll('.ins-item')];
    let sum = 0;
    rows.forEach(r => {
      const qty = parseFloat(r.querySelector('.ins-item-qty').value) || 0;
      const price = parseFloat(r.querySelector('.ins-item-price').value) || 0;
      r.querySelector('.ins-item-total').textContent = cur(qty * price);
      sum += qty * price;
    });
    const amountEl = $('#ins-amount');
    amountEl.value = sum || amountEl.value;
    amountEl.readOnly = rows.length > 0;
    calc();
  };
  const addBtn = $('#ins-add-item-btn');
  if (addBtn) addBtn.addEventListener('click', () => {
    const sel = $('#ins-add-item');
    const opt = sel?.selectedOptions[0];
    if (!opt || !opt.value) return;
    const existing = [...itemsBox.querySelectorAll('.ins-item')].find(r => r.dataset.name === opt.value);
    if (existing) {
      const qEl = existing.querySelector('.ins-item-qty');
      qEl.value = (parseInt(qEl.value) || 0) + 1;
    } else {
      itemsBox.insertAdjacentHTML('beforeend', insItemRow(opt.value, 1, opt.dataset.price || 0));
    }
    sel.value = '';
    recalc();
  });
  itemsBox.addEventListener('click', (ev) => {
    const btn = ev.target.closest('[data-action="remove-ins-item"]');
    if (btn) { btn.closest('.ins-item').remove(); recalc(); }
  });
  itemsBox.addEventListener('input', recalc);
  ['ins-amount', 'ins-down', 'ins-rate', 'ins-months'].forEach(id => { const el = $('#' + id); if (el) el.addEventListener('input', calc); });
  recalc();
}

function installmentPayModal(no) {
  const plan = INSTALLMENTS.find(x => x.no === no);
  if (!plan) return;
  const remaining = insRemaining(plan);
  openModal(`
    <div class="modal-head"><h3><i class="fa-solid fa-hand-holding-dollar"></i> تسجيل دفعة — ${esc(plan.no)}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="min-card" style="margin-bottom:14px"><i class="fa-solid fa-user ic-navy"></i><b>${esc(plan.customer)}</b><span>${esc(plan.device)} · المتبقي: ${cur(remaining)}</span></div>
      <div class="r-grid-2">
        <div class="field"><label>مبلغ الدفعة <b class="req">*</b></label><i class="fa-solid fa-money-bill-wave"></i><input type="number" id="pay-amount" value="${esc(Math.min(plan.perMonth || 0, remaining))}" placeholder="0"></div>
        <div class="field"><label>تاريخ الدفعة</label><i class="fa-regular fa-calendar"></i><input type="date" id="pay-date"></div>
        <div class="field span-2"><label>ملاحظات</label><i class="fa-solid fa-note-sticky"></i><input type="text" id="pay-note" placeholder="مثال: دفعة شهرية، تحويل بنكي..."></div>
      </div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-installment-pay" data-ins="${esc(plan.no)}"><i class="fa-solid fa-check"></i> تأكيد الدفعة</button></div>
  `);
}

function installmentViewModal(no) {
  const plan = INSTALLMENTS.find(x => x.no === no);
  if (!plan) return;
  const paid = insPaid(plan);
  const down = Number(plan.down) || 0;
  const remaining = insRemaining(plan);
  const prog = insProgress(plan);
  const sched = installmentSchedule(plan);
  const rows = sched.map(s => `
    <div class="mt-row"><span>${s.i}</span><span>${esc(s.date)}</span><b>${cur(s.amount)}</b>${s.paid >= s.amount && s.amount > 0 ? '<span class="chip chip-green">مدفوع</span>' : (s.paid > 0 ? '<span class="chip chip-blue">جزئي</span>' : '<span class="chip chip-amber">مستحق</span>')}</div>`).join('');
  openModal(`
    <div class="modal-head"><h3><i class="fa-solid fa-calendar-check"></i> خطة ${esc(plan.no)}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="grid-2" style="margin-bottom:14px">
        <div class="min-card"><i class="fa-solid fa-user ic-navy"></i><b>${esc(plan.customer)}</b><span>${esc(plan.device)}</span></div>
        <div class="min-card"><i class="fa-solid fa-coins ic-green"></i><b>${cur(plan.amount)}</b><span>المقدم ${cur(plan.down)} · الدفعة ${cur(plan.perMonth)}</span></div>
      </div>
      ${Array.isArray(plan.items) && plan.items.length > 1 ? `<div class="modal-table" style="margin-bottom:12px">
        <div class="mt-head"><span>#</span><span>المنتج</span><span>الكمية</span><span>السعر</span><span>الإجمالي</span></div>
        ${plan.items.map((it, idx) => `<div class="mt-row"><span>${idx + 1}</span><span>${esc(it.name)}</span><span>${it.qty}</span><span>${cur(it.price)}</span><b>${cur(it.qty * it.price)}</b></div>`).join('')}
      </div>` : ''}
      ${(Number(plan.rate) || 0) ? `<div class="ins-finance" style="margin-bottom:12px">
        <span>نسبة الزيادة <b>${plan.rate}%</b></span>
        <span>الممول قبل الزيادة <b>${cur(insFinanced(plan) - insInterest(plan))}</b></span>
        <span>+ الفائدة <b>${cur(insInterest(plan))}</b></span>
        <span>الممول النهائي <b>${cur(insFinanced(plan))}</b></span>
      </div>` : ''}
      <div class="progress-bar" style="margin-bottom:12px"><div class="progress-fill" style="width:${prog}%"></div><span>${prog}%</span></div>
      <div class="mini-labels"><span><b>المحصل (شامل المقدم):</b> ${cur(down + paid)}</span><span><b>المتبقي:</b> ${cur(remaining)}</span></div>
      <h4 style="margin:14px 0 8px;color:var(--primary-dark)"><i class="fa-solid fa-list"></i> جدول السداد</h4>
      <div class="modal-table">
        <div class="mt-head"><span>#</span><span>تاريخ الاستحقاق</span><span>المبلغ</span><span>الحالة</span></div>
        ${rows}
      </div>
      ${plan.notes ? `<p style="margin-top:10px;font-size:12px;color:var(--text-2)"><i class="fa-solid fa-note-sticky"></i> ${esc(plan.notes)}</p>` : ''}
    </div>
    <div class="modal-foot">
      <button class="btn btn-ghost" data-action="close-modal">إغلاق</button>
      ${insStatus(plan) !== 'مكتمل' ? `<button class="btn btn-accent" data-action="pay-installment" data-ins="${esc(plan.no)}"><i class="fa-solid fa-hand-holding-dollar"></i> تسجيل دفعة</button>` : ''}
      <button class="btn btn-navy" data-action="print-installment" data-ins="${esc(plan.no)}"><i class="fa-solid fa-print"></i> طباعة الجدول</button>
    </div>
  `);
}

function buildInstallmentHTML(plan) {
  const months = Math.max(1, Number(plan.months) || 1);
  const schedRows = installmentSchedule(plan).map(s => `
    <tr>
      <td>${s.i}</td>
      <td>${esc(s.date)}</td>
      <td>${cur(s.amount)}</td>
      <td>${s.paid >= s.amount && s.amount > 0 ? 'مدفوع' : (s.paid > 0 ? 'جزئي' : 'مستحق')}</td>
      <td>${esc(s.note || '—')}</td>
    </tr>`);
  const date = new Date().toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' });
  return `
    <div class="inv-wrap">
      ${invoiceHead('جدول خطة الأقساط', plan.no, date)}
      ${Array.isArray(plan.items) && plan.items.length > 1 ? `<table class="inv-table">
        <thead><tr><th>#</th><th>المنتج</th><th>الكمية</th><th>سعر الوحدة</th><th>الإجمالي</th></tr></thead>
        <tbody>${plan.items.map((it, idx) => `
          <tr><td>${idx + 1}</td><td class="inv-name">${esc(it.name)}</td><td>${it.qty}</td><td>${cur(it.price)}</td><td>${cur(it.qty * it.price)}</td></tr>`).join('')}
        </tbody>
      </table>` : ''}
      <table class="inv-details">
        <tr><td class="id-l">العميل</td><td>${esc(plan.customer)}</td><td class="id-l">الجهاز</td><td>${esc(plan.device)}</td></tr>
        <tr><td class="id-l">إجمالي المبلغ</td><td>${cur(plan.amount)}</td><td class="id-l">الدفعة المقدمة</td><td>${cur(plan.down)}</td></tr>
        <tr><td class="id-l">نسبة الزيادة</td><td>${(Number(plan.rate) || 0)}%</td><td class="id-l">الممول النهائي</td><td>${cur(insFinanced(plan))}</td></tr>
        <tr><td class="id-l">الدفعة الشهرية</td><td>${cur(plan.perMonth)}</td><td class="id-l">عدد الشهور</td><td>${months} شهر</td></tr>
      </table>
      <table class="inv-table">
        <thead><tr><th>#</th><th>تاريخ الاستحقاق</th><th>المبلغ</th><th>الحالة</th><th>ملاحظات</th></tr></thead>
        <tbody>${schedRows.join('')}</tbody>
      </table>
      <div class="inv-totals">
        <div><span>المحصل حتى الآن (شامل المقدم)</span><b>${cur((Number(plan.down) || 0) + insPaid(plan))}</b></div>
        <div><span>المتبقي</span><b>${cur(insRemaining(plan))}</b></div>
        <div class="inv-grand"><span>الحالة</span><b>${insStatus(plan)}</b></div>
      </div>
      <fieldset class="r-section r-signatures">
        <legend><i class="fa-solid fa-signature"></i> التوقيعات</legend>
        <div class="sign-grid">
          <div class="sign-box">
            <div class="sign-head"><i class="fa-solid fa-user"></i><span>توقيع العميل</span></div>
            <div class="sign-area"></div>
            <div class="sign-foot">${esc(plan.customer)}</div>
          </div>
          <div class="sign-box">
            <div class="sign-head"><i class="fa-solid fa-headset"></i><span>توقيع المستلم</span></div>
            <div class="sign-area"></div>
            <div class="sign-foot">${esc((SESSION && SESSION.name) || '')}</div>
          </div>
          <div class="sign-box">
            <div class="sign-head"><i class="fa-solid fa-user-gear"></i><span>توقيع الفني</span></div>
            <div class="sign-area"></div>
            <div class="sign-foot">${esc((SESSION && SESSION.name) || '')}</div>
          </div>
        </div>
      </fieldset>
      ${socialLinksHTML()}
      <div class="receipt-footer">
        <div class="rf-stamp">
          <div class="stamp"><i class="fa-solid fa-check-double"></i> معتمد · ${esc(SETTINGS.company || '')}</div>
          <p class="rf-thanks">شكراً لثقتكم بنا — نعتني بجهازكم كأنه جهازنا</p>
          <p class="rf-note">${esc(SETTINGS.receiptFooter || 'احتفظ بهذا الإيصال لاستلام جهازكم')}</p>
        </div>
      </div>
    </div>`;
}

/* ---------- Track timeline ---------- */
const STEPS = [
  { key: 'received',   label: 'تم الاستلام',     desc: 'تم استلام الجهاز من العميل وتسجيل البيانات' },
  { key: 'inspection', label: 'قيد الفحص',       desc: 'فحص الجهاز لتحديد العطل والتكلفة' },
  { key: 'approval',   label: 'بانتظار الموافقة', desc: 'تم إبلاغ العميل بالتكلفة وانتظار الموافقة' },
  { key: 'parts',      label: 'بانتظار الأجزاء',  desc: 'طلب قطع الغيار المطلوبة للإصلاح' },
  { key: 'repairing',  label: 'قيد الإصلاح',      desc: 'الفني يعمل على إصلاح الجهاز' },
  { key: 'quality',    label: 'فحص الجودة',       desc: 'التحقق من جودة الإصلاح قبل التسليم' },
  { key: 'completed',  label: 'مكتمل',           desc: 'الجهاز جاهز للتسليم' },
  { key: 'delivered',  label: 'تم التسليم',      desc: 'تم تسليم الجهاز للعميل وإتمام الدفع' },
];

function renderTrack(statusKey = 'repairing') {
  const idx = STEPS.findIndex(s => s.key === statusKey);
  const box = $('#track-timeline');
  box.innerHTML = STEPS.map((s, i) => {
    const cls = i < idx ? 'done' : i === idx ? 'current' : 'pending';
    const time = i < idx ? '<span class="tt-time"><i class="fa-regular fa-clock"></i> مكتمل</span>' : i === idx ? '<span class="tt-time"><i class="fa-regular fa-clock"></i> جاري الآن — تحديث: منذ 25 دقيقة</span>' : '';
    return `
      <div class="tt-step ${cls}">
        <div class="tt-dot"><i class="fa-solid fa-wrench"></i></div>
        <div class="tt-body">
          <div class="tt-title">${s.label}</div>
          <div class="tt-desc">${s.desc}</div>
          ${time}
        </div>
      </div>`;
  }).join('');
}

function updateTrackCard(repair) {
  if (!repair) return;
  CURRENT_TRACK_ID = repair.id;
  const b = $('#track-barcode');
  genBarcode(b, repair.barcode);
  $('#track-barcode').nextElementSibling.textContent = repair.id;
  $('#track-device-name').textContent = repair.device;
  $('#track-customer').textContent = `${repair.customer} — ${CUSTOMERS.find(c => c.name === repair.customer)?.phone || '05XXXXXXXX'}`;
  const amt = $('#track-amount'); if (amt) amt.textContent = cur(repair.amount);
  const paid = Number(repair.paid) || 0;
  const left = repair.left != null ? Number(repair.left) : Math.max((Number(repair.amount) || 0) - paid, 0);
  const tp = $('#track-paid'); if (tp) tp.textContent = `${cur(paid)} / ${cur(left)}`;
  const stSel = $('#track-status');
  if (stSel) {
    stSel.innerHTML = Object.keys(STATUS).map(k => `<option value="${k}" ${k === repair.status ? 'selected' : ''}>${STATUS[k].label}</option>`).join('');
  }
  renderTrack(repair.status);
}

/* ---------- Charts ---------- */
let charts = {};
const navy = '#0B2D5B', orange = '#FF7A00', blue = '#3B82F6', green = '#0EA56A', red = '#EF4444';

function chartFont(size = 11) {
  return { family: "'Cairo', sans-serif", size };
}

function initCharts() {
  if (typeof Chart === 'undefined') return;
  // Destroy previous instances so charts can be safely rebuilt after data changes
  Object.values(charts).forEach(c => { try { c && c.destroy(); } catch (e) {} });
  charts = {};
  Chart.defaults.font.family = "'Cairo', sans-serif";
  Chart.defaults.color = '#5B6B8C';
  Chart.defaults.borderColor = 'rgba(11,45,91,.06)';

  const incM = monthSum(SALES, 'total', 8);
  const expM = monthSum(PURCHASES, 'total', 8);
  const months = incM.labels;
  const income = incM.data;
  const expenses = expM.data;

  if ($('#chart-income')) {
    charts.income = new Chart($('#chart-income'), {
      type: 'bar',
      data: {
        labels: months,
        datasets: [
          { label: 'الإيرادات', data: income, backgroundColor: navy, borderRadius: 8, barPercentage: .55, categoryPercentage: .7 },
          { label: 'المصروفات', data: expenses, backgroundColor: orange, borderRadius: 8, barPercentage: .55, categoryPercentage: .7 },
        ],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'top', rtl: true, labels: { usePointStyle: true, pointStyle: 'circle', padding: 18 } },
          tooltip: { rtl: true, backgroundColor: '#081F3F', padding: 12, cornerRadius: 10, titleFont: chartFont(12, 700), bodyFont: chartFont(12) } },
        scales: {
          x: { grid: { display: false }, ticks: { font: chartFont() }, border: { display: false } },
          y: { grid: { color: 'rgba(11,45,91,.06)' }, border: { display: false }, ticks: { font: chartFont(), callback: v => (v / 1000) + 'k' } },
        },
      },
    });
  }

  if ($('#chart-weekly')) {
    const wk = weeklyData();
    const days = wk.labels;
    charts.weekly = new Chart($('#chart-weekly'), {
      type: 'line',
      data: {
        labels: days,
        datasets: [
          { label: 'مستلمة', data: wk.received, borderColor: navy, backgroundColor: 'rgba(11,45,91,.08)', fill: true, tension: .45, borderWidth: 3, pointRadius: 4, pointBackgroundColor: navy },
          { label: 'مسلّمة', data: wk.delivered, borderColor: orange, backgroundColor: 'rgba(255,122,0,.08)', fill: true, tension: .45, borderWidth: 3, pointRadius: 4, pointBackgroundColor: orange },
        ],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'top', rtl: true, labels: { usePointStyle: true, pointStyle: 'circle', padding: 18 } }, tooltip: { rtl: true, backgroundColor: '#081F3F', padding: 12, cornerRadius: 10 } },
        scales: {
          x: { grid: { display: false }, border: { display: false }, ticks: { font: chartFont() } },
          y: { grid: { color: 'rgba(11,45,91,.06)' }, border: { display: false }, ticks: { font: chartFont() } },
        },
      },
    });
  }

  if ($('#chart-status')) {
    const stKeys = ['received', 'inspection', 'approval', 'parts', 'repairing', 'quality', 'completed', 'delivered'];
    const stLabels = ['مستلم', 'قيد الفحص', 'بانتظار الموافقة', 'بانتظار الأجزاء', 'قيد الإصلاح', 'فحص الجودة', 'مكتمل', 'مسلّم'];
    const stColors = ['#94A3B8', blue, '#F59E0B', '#8B5CF6', orange, '#0D9488', green, navy];
    const stCnt = {};
    stKeys.forEach(k => { stCnt[k] = REPAIRS.filter(r => r.status === k).length; });
    charts.status = new Chart($('#chart-status'), {
      type: 'doughnut',
      data: {
        labels: stLabels,
        datasets: [{ data: stKeys.map(k => stCnt[k]), backgroundColor: stColors, borderWidth: 0, hoverOffset: 8 }],
      },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '68%',
        plugins: { legend: { display: false }, tooltip: { rtl: true, backgroundColor: '#081F3F', padding: 12, cornerRadius: 10 } },
      },
    });
    $('#status-legend').innerHTML = stKeys.map((k, i) =>
      `<span><i style="background:${stColors[i]}"></i> ${stLabels[i]} ${DASH_PRIVACY ? '•••' : stCnt[k]}</span>`).join('');
  }

  if ($('#chart-sources')) {
    charts.sources = new Chart($('#chart-sources'), {
      type: 'doughnut',
      data: {
        labels: ['عميل دائم', 'عميل', 'عميلة', 'عميل جديد', 'أخرى'],
        datasets: [{ data: ['عميل دائم', 'عميل', 'عميلة', 'عميل جديد', 'أخرى'].map(t => CUSTOMERS.filter(c => (c.type || 'أخرى') === t).length), backgroundColor: [navy, blue, orange, green, '#8B5CF6'], borderWidth: 0, hoverOffset: 8 }],
      },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '62%',
        plugins: { legend: { position: 'bottom', rtl: true, labels: { usePointStyle: true, pointStyle: 'circle', padding: 14, font: chartFont(11) } }, tooltip: { rtl: true, backgroundColor: '#081F3F', padding: 12, cornerRadius: 10 } },
      },
    });
  }

  if ($('#chart-cashflow')) {
    charts.cashflow = new Chart($('#chart-cashflow'), {
      type: 'line',
      data: {
        labels: monthSum(SALES, 'total').labels,
        datasets: [
          { label: 'الوارد', data: monthSum(SALES, 'total').data, borderColor: green, backgroundColor: 'rgba(14,165,106,.1)', fill: true, tension: .4, borderWidth: 3, pointRadius: 4 },
          { label: 'الصادر', data: monthSum(PURCHASES, 'total').data, borderColor: red, backgroundColor: 'rgba(239,68,68,.08)', fill: true, tension: .4, borderWidth: 3, pointRadius: 4 },
        ],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'top', rtl: true, labels: { usePointStyle: true, pointStyle: 'circle', padding: 18 } }, tooltip: { rtl: true, backgroundColor: '#081F3F', padding: 12, cornerRadius: 10 } },
        scales: {
          x: { grid: { display: false }, border: { display: false }, ticks: { font: chartFont() } },
          y: { grid: { color: 'rgba(11,45,91,.06)' }, border: { display: false }, ticks: { font: chartFont(), callback: v => (v / 1000) + 'k' } },
        },
      },
    });
  }

  if ($('#chart-expenses')) {
    charts.expenses = new Chart($('#chart-expenses'), {
      type: 'doughnut',
      data: {
        labels: ['إيجار', 'رواتب', 'قطع غيار', 'فواتير', 'تسويق'],
        datasets: [{ data: [0, 0, 0, 0, 0], backgroundColor: [navy, orange, blue, green, '#8B5CF6'], borderWidth: 0, hoverOffset: 8 }],
      },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '64%',
        plugins: { legend: { position: 'bottom', rtl: true, labels: { usePointStyle: true, pointStyle: 'circle', padding: 14, font: chartFont(11) } }, tooltip: { rtl: true, backgroundColor: '#081F3F', padding: 12, cornerRadius: 10 } },
      },
    });
  }

  if ($('#chart-sales-report')) {
    charts.salesReport = new Chart($('#chart-sales-report'), {
      type: 'bar',
      data: {
        labels: salesByCategory().labels,
        datasets: [{ label: 'المبيعات', data: salesByCategory().data, backgroundColor: [navy, blue, orange, green, '#8B5CF6', '#0D9488'], borderRadius: 8, barPercentage: .6 }],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { rtl: true, backgroundColor: '#081F3F', padding: 12, cornerRadius: 10, callbacks: { label: c => ' ' + (c.raw / 1000) + ' ألف ' + CURRENCY } } },
        scales: {
          x: { grid: { display: false }, border: { display: false }, ticks: { font: chartFont() } },
          y: { grid: { color: 'rgba(11,45,91,.06)' }, border: { display: false }, ticks: { font: chartFont(), callback: v => (v / 1000) + 'k' } },
        },
      },
    });
  }

  if ($('#chart-repairs-report')) {
    charts.repairsReport = new Chart($('#chart-repairs-report'), {
      type: 'doughnut',
      data: {
        labels: ['مستلم', 'قيد الفحص', 'بانتظار الموافقة', 'بانتظار الأجزاء', 'قيد الإصلاح', 'فحص الجودة', 'مكتمل', 'مسلّم'],
        datasets: [{ data: ['received', 'inspection', 'approval', 'parts', 'repairing', 'quality', 'completed', 'delivered'].map(k => REPAIRS.filter(r => r.status === k).length), backgroundColor: ['#94A3B8', blue, '#F59E0B', '#8B5CF6', orange, '#0D9488', green, navy], borderWidth: 0, hoverOffset: 8 }],
      },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '64%',
        plugins: { legend: { position: 'bottom', rtl: true, labels: { usePointStyle: true, pointStyle: 'circle', padding: 14, font: chartFont(11) } }, tooltip: { rtl: true, backgroundColor: '#081F3F', padding: 12, cornerRadius: 10 } },
      },
    });
  }

  if ($('#chart-tech-report')) {
    charts.techReport = new Chart($('#chart-tech-report'), {
      type: 'bar',
      data: {
        labels: EMPLOYEES.filter(e => /فني/.test(e.role || '')).map(e => e.name).slice(0, 6),
        datasets: [
          { label: 'الإنتاجية', data: EMPLOYEES.filter(e => /فني/.test(e.role || '')).map(e => Number(e.perf) || 0).slice(0, 6), backgroundColor: navy, borderRadius: 8, barPercentage: .5 },
          { label: 'التقييم', data: EMPLOYEES.filter(e => /فني/.test(e.role || '')).map(e => Number(e.rating) || 0).slice(0, 6), backgroundColor: orange, borderRadius: 8, barPercentage: .5 },
        ],
      },
      options: {
        responsive: true, maintainAspectRatio: false, indexAxis: 'y',
        plugins: { legend: { position: 'top', rtl: true, labels: { usePointStyle: true, pointStyle: 'circle', padding: 18 } }, tooltip: { rtl: true, backgroundColor: '#081F3F', padding: 12, cornerRadius: 10 } },
        scales: {
          x: { grid: { color: 'rgba(11,45,91,.06)' }, border: { display: false }, ticks: { font: chartFont() } },
          y: { grid: { display: false }, border: { display: false }, ticks: { font: chartFont() } },
        },
      },
    });
  }

  if ($('#chart-profit-report')) {
    const profitSeries = monthProfitSeries(6);
    charts.profitReport = new Chart($('#chart-profit-report'), {
      type: 'line',
      data: {
        labels: profitSeries.labels,
        datasets: [
          { label: 'الإيرادات', data: monthSum(SALES, 'total').data, borderColor: navy, backgroundColor: 'rgba(11,45,91,.08)', fill: true, tension: .4, borderWidth: 3, pointRadius: 4 },
          { label: 'صافي الربح', data: profitSeries.data, borderColor: orange, backgroundColor: 'rgba(255,122,0,.1)', fill: true, tension: .4, borderWidth: 3, pointRadius: 4 },
        ],
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'top', rtl: true, labels: { usePointStyle: true, pointStyle: 'circle', padding: 18 } }, tooltip: { rtl: true, backgroundColor: '#081F3F', padding: 12, cornerRadius: 10 } },
        scales: {
          x: { grid: { display: false }, border: { display: false }, ticks: { font: chartFont() } },
          y: { grid: { color: 'rgba(11,45,91,.06)' }, border: { display: false }, ticks: { font: chartFont(), callback: v => (v / 1000) + 'k' } },
        },
      },
    });
  }
}

/* ---------- Logo upload ---------- */
function resizeImage(file, max = 512) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const w = Math.round(img.width * scale);
      const h = Math.round(img.height * scale);
      const canvas = document.createElement('canvas');
      canvas.width = w; canvas.height = h;
      canvas.getContext('2d').drawImage(img, 0, 0, w, h);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL('image/png'));
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('invalid-image')); };
    img.src = url;
  });
}

function applyLogo() {
  const src = SETTINGS.logo || '';
  const DEFAULT_LOGO = 'icons/Icon-512.png';
  const setLogo = (el, isImgEl) => {
    if (!el) return;
    el.innerHTML = '';
    el.style.background = '#fff';
    el.style.boxShadow = 'none';
    const im = document.createElement('img');
    im.src = src || DEFAULT_LOGO;
    im.style.cssText = 'width:100%;height:100%;object-fit:contain;border-radius:inherit;';
    el.appendChild(im);
  };
  $$('.logo-mark').forEach(el => setLogo(el, false));
  setLogo($('.r-logo'), false);
  const fav = document.querySelector('link[rel="icon"]');
  if (fav) fav.href = src || fav.dataset.defaultHref || 'data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 64 64%27%3E%3Crect width=%2764%27 height=%2764%27 rx=%2716%27 fill=%27%230B2D5B%27/%3E%3Ctext x=%2732%27 y=%2744%27 font-size=%2736%27 font-weight=%27bold%27 fill=%27%23FF7A00%27 text-anchor=%27middle%27 font-family=%27Arial%27%3Eظˆ%3C/text%3E%3C/svg%3E';
}

function handleLogoFile(file) {
  if (!file || !file.type.startsWith('image/')) { toast('يرجى اختيار ملف صورة صالح', 'error'); return; }
  resizeImage(file).then(dataUrl => {
    SETTINGS.logo = dataUrl;
    DB.set('settings', SETTINGS);
    applyLogo();
    toast('تم تحديث الشعار بنجاح');
  }).catch(() => toast('تعذر قراءة الصورة', 'error'));
}

/* ---------- Modal / Toast ---------- */
const modal = $('#modal'), backdrop = $('#modal-backdrop');

function openModal(html) {
  modal.innerHTML = html;
  modal.classList.add('show');
  backdrop.classList.add('show');
}
function closeModal() {
  modal.classList.remove('show');
  backdrop.classList.remove('show');
}

function toast(msg, type = 'success') {
  const wrap = $('#toast-wrap');
  if (!wrap) return;
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  const icon = type === 'success' ? 'fa-circle-check' : type === 'error' ? 'fa-circle-xmark' : 'fa-circle-info';
  const i = document.createElement('i');
  i.className = `fa-solid ${icon}`;
  el.appendChild(i);
  el.appendChild(document.createTextNode(' ' + String(msg ?? '')));
  wrap.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateY(-12px)'; setTimeout(() => el.remove(), 300); }, 2600);
}

/* ---------- Navigation ---------- */
let routing = true;
function showView(id) {
  if (!canView(id)) {
    const landing = firstAllowedView();
    if (!landing) {
      $$('.view').forEach(v => v.classList.remove('active'));
      return;
    }
    if (id !== landing) {
      toast('لا تملك صلاحية الوصول لهذه الصفحة', 'error');
      try {
        if (location.protocol === 'file:') location.hash = '#/' + landing;
        else history.replaceState(null, '', '#/' + landing);
      } catch (e) {}
      showView(landing);
    }
    return;
  }
  $$('.view').forEach(v => v.classList.remove('active'));
  const target = $('#view-' + id);
  if (target) target.classList.add('active');
  $$('.nav-item[data-view]').forEach(n => n.classList.toggle('active', n.dataset.view === id));
  closeSidebar();
  if (id === 'new-repair') updateReceiptCodes();
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (routing) {
    const target = '#/' + id;
    if (location.protocol === 'file:') {
      if (location.hash !== target) location.hash = target;
    } else {
      history.replaceState(null, '', target);
    }
  }
}
window.addEventListener('hashchange', () => {
  const id = location.hash.replace('#/', '') || 'dashboard';
  routing = false; showView(id); routing = true;
});

function openSidebar() { $('#sidebar').classList.add('open'); $('#sidebar-overlay').classList.add('show'); }
function closeSidebar() { $('#sidebar').classList.remove('open'); $('#sidebar-overlay').classList.remove('show'); }

/* ---------- Modals content ---------- */
/* Cash actually received for a sale (everything except the «آجل» credit part). */
function saleCashPaid(sale) {
  return (Array.isArray(sale.payments) ? sale.payments : []).filter(p => p.method !== 'آجل').reduce((s, p) => s + (Number(p.amount) || 0), 0);
}

/* Payment ledger for a customer: real payments + debt movements (overpay deduction / credit added). */
function customerLedger(name) {
  const c = CUSTOMERS.find(x => x.name === name);
  const cSales = SALES.filter(s => s.customer === name);
  const ledger = [];
  cSales.forEach(s => {
    (Array.isArray(s.payments) ? s.payments : []).forEach(p => {
      if (p.method === 'آجل') {
        if (c && (Number(s.creditAdded) || 0) > 0) ledger.push({ date: s.date, ref: s.no, label: 'إضافة آجل إلى المديونية', amount: Number(s.creditAdded) || p.amount, neg: true });
        else if (!c) ledger.push({ date: s.date, ref: s.no, label: 'آجل (بيع نقدي)', amount: Number(p.amount) || 0, neg: true });
      } else {
        ledger.push({ date: s.date, ref: s.no, label: `دفعة ${p.method}`, amount: Number(p.amount) || 0, neg: false });
      }
    });
    if ((Number(s.debtDeducted) || 0) > 0) ledger.push({ date: s.date, ref: s.no, label: 'خصم فائض الدفع من المديونية', amount: Number(s.debtDeducted), neg: false, debt: true });
  });
  ledger.reverse();
  return { c, cSales, ledger, paid: cSales.reduce((s, x) => s + saleCashPaid(x), 0) };
}

function customerHistoryModal(name) {
  CURRENT_CUSTOMER_RECORD = name;
  const c = CUSTOMERS.find(x => x.name === name);
  const cReps = REPAIRS.filter(r => r.customer === name);
  const { cSales, ledger, paid } = customerLedger(name);
  const ledgerRows = ledger.map(l => `<div class="mt-row">
      <span>${esc(l.date || '')}</span><span>${esc(l.ref || '—')}</span>
      <span>${esc(l.label)}${l.debt ? ' <i class="fa-solid fa-hand-holding-dollar" style="color:var(--accent)"></i>' : ''}</span>
      <b class="${l.neg ? 'text-red' : 'text-green'}">${l.neg ? '+' : ''}${cur(l.amount)}</b>
    </div>`).join('');
  openModal(`
    <div class="modal-head"><h3>سجل العميل — ${esc(name)}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="grid-2" style="grid-template-columns:repeat(4,1fr);margin-bottom:14px">
        <div class="min-card"><i class="fa-solid fa-screwdriver-wrench ic-navy"></i><b>${cReps.length}</b><span>إصلاح سابق</span></div>
        <div class="min-card"><i class="fa-solid fa-file-invoice ic-navy"></i><b>${cSales.length}</b><span>فاتورة بيع</span></div>
        <div class="min-card"><i class="fa-solid fa-hand-holding-dollar ic-red"></i><b>${cur((c && c.debt) || 0)}</b><span>مديونية حالية</span></div>
        <div class="min-card"><i class="fa-solid fa-sack-dollar ic-green"></i><b>${cur(paid)}</b><span>إجمالي المدفوعات</span></div>
      </div>
      <h4 style="margin:0 0 8px;color:var(--primary-dark)"><i class="fa-solid fa-money-bill-wave"></i> سجل الدفعات</h4>
      <div class="modal-table" style="margin-bottom:16px">
        <div class="mt-head"><span>التاريخ</span><span>الفاتورة</span><span>البيان</span><span>المبلغ</span></div>
        ${ledgerRows || '<div class="empty-state">لا توجد دفعات مسجلة لهذا العميل</div>'}
      </div>
      <h4 style="margin:0 0 8px;color:var(--primary-dark)"><i class="fa-solid fa-file-invoice"></i> فواتير المبيعات</h4>
      <div class="modal-table" style="margin-bottom:16px">
        <div class="mt-head"><span>الفاتورة</span><span>التاريخ</span><span>الإجمالي</span><span>المحصل / آجل</span></div>
        ${cSales.slice(0, 8).map(s => `<div class="mt-row"><span>${esc(s.no)}</span><span>${esc(s.date || '')}</span><b>${cur(s.total)}</b><b><span class="text-green">${cur(saleCashPaid(s))}</span>${(Number(s.creditAdded) || 0) > 0 ? ` / <span class="text-red">${cur(Number(s.creditAdded))} آجل</span>` : ''}</b></div>`).join('') || '<div class="empty-state">لا توجد فواتير بيع لهذا العميل</div>'}
      </div>
      <h4 style="margin:0 0 8px;color:var(--primary-dark)"><i class="fa-solid fa-screwdriver-wrench"></i> سجل الإصلاحات</h4>
      <div class="modal-table">
        <div class="mt-head"><span>الإصلاح</span><span>الجهاز</span><span>الحالة</span><span>المبلغ</span></div>
        ${cReps.slice(0, 6).map(r => `<div class="mt-row"><span>${esc(r.id)}</span><span>${esc(r.device)}</span><span>${statusChip(r.status)}</span><b>${cur(r.amount)}</b></div>`).join('') || '<div class="empty-state">لا توجد إصلاحات لهذا العميل</div>'}
      </div>
    </div>
    <div class="modal-foot"><button class="btn btn-navy" data-action="close-modal">إغلاق</button><button class="btn btn-green" data-action="send-customer"><i class="fa-brands fa-whatsapp"></i> إرسال</button><button class="btn btn-accent" data-action="print-customer"><i class="fa-solid fa-print"></i> طباعة</button></div>
  `);
}

/* Printable HTML report of the customer record (reuses the invoice print styles). */
function buildCustomerRecordHTML(name) {
  const c = CUSTOMERS.find(x => x.name === name) || {};
  const cReps = REPAIRS.filter(r => r.customer === name);
  const { cSales, ledger, paid } = customerLedger(name);
  const invRows = cSales.slice(0, 10).map((s, i) => `
    <tr><td>${i + 1}</td><td class="inv-name">${esc(s.no)}</td><td>${esc(s.date || '')}</td><td>${cur(s.total)}</td><td>${cur(saleCashPaid(s))}</td><td>${cur(Math.max(0, (Number(s.total) || 0) - saleCashPaid(s)))}</td></tr>`).join('');
  const ledgerRows = ledger.slice(0, 12).map(l => `
    <tr><td>${esc(l.date || '')}</td><td class="inv-name">${esc(l.ref || '—')}</td><td>${esc(l.label)}</td><td>${cur(l.amount)}</td></tr>`).join('');
  const repRows = cReps.slice(0, 8).map((r, i) => `
    <tr><td>${i + 1}</td><td class="inv-name">${esc(r.id)}</td><td>${esc(r.device || '')}</td><td>${esc((STATUS[r.status] || {}).label || r.status || '')}</td><td>${cur(r.amount)}</td></tr>`).join('');
  const emptyRow = `<tr><td colspan="5" style="color:#888">لا توجد بيانات</td></tr>`;
  return `
    <div class="inv-wrap">
      <div class="inv-head">
        <div class="inv-logo">${safeLogo(SETTINGS.logo) ? `<img src="${safeLogo(SETTINGS.logo)}" alt="logo" style="width:100%;height:100%;object-fit:contain;border-radius:inherit;background:#fff">` : 'و'}</div>
        <div class="inv-brand">
          <h1>${esc(SETTINGS.company || '')}</h1>
          <p>نظام إدارة مراكز الصيانة — Senior Pro</p>
          <div class="inv-brand-meta">
            <span><i class="fa-solid fa-location-dot"></i> ${esc(SETTINGS.address || '')}</span>
            <span><i class="fa-solid fa-mobile-screen"></i> ${esc(SETTINGS.mobile || '')} ${SETTINGS.phone ? '· ' + esc(SETTINGS.phone) : ''}</span>
          </div>
        </div>
        <div class="inv-title">
          <h2>سجل العميل</h2>
          <b>${esc(name)}</b>
          <small>${new Date().toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' })}</small>
        </div>
      </div>
      <div class="inv-info">
        <div><span>اسم العميل</span><b>${esc(name)}</b></div>
        <div><span>رقم الجوال</span><b>${esc(c.phone || '—')}</b></div>
        <div><span>العنوان</span><b>${esc(c.address || '—')}</b></div>
        <div><span>النوع</span><b>${esc(c.type || '—')}</b></div>
        <div><span>عدد الفواتير</span><b>${cSales.length}</b></div>
        <div><span>عدد الإصلاحات</span><b>${cReps.length}</b></div>
      </div>
      <div class="inv-totals" style="width:100%;margin:0 0 12px">
        <div><span>مديونية العميل الحالية</span><b style="color:#d32f2f">${cur((Number(c.debt) || 0))}</b></div>
        <div><span>إجمالي المدفوعات المحصلة</span><b style="color:#1a7f37">${cur(paid)}</b></div>
      </div>
      <table class="inv-table">
        <thead><tr><th>#</th><th>رقم الفاتورة</th><th>التاريخ</th><th>الإجمالي</th><th>المحصل</th><th>الآجل</th></tr></thead>
        <tbody>${invRows || `<tr><td colspan="6" style="color:#888">لا توجد فواتير بيع</td></tr>`}</tbody>
      </table>
      <p style="font-size:12px;font-weight:800;color:#0B2D5B;margin:14px 0 4px">سجل الدفعات</p>
      <table class="inv-table">
        <thead><tr><th>التاريخ</th><th>الفاتورة</th><th>البيان</th><th>المبلغ</th></tr></thead>
        <tbody>${ledgerRows || emptyRow.replace('colspan="5"', 'colspan="4"')}</tbody>
      </table>
      <p style="font-size:12px;font-weight:800;color:#0B2D5B;margin:14px 0 4px">سجل الإصلاحات</p>
      <table class="inv-table">
        <thead><tr><th>#</th><th>رقم الإصلاح</th><th>الجهاز</th><th>الحالة</th><th>المبلغ</th></tr></thead>
        <tbody>${repRows || emptyRow}</tbody>
      </table>
      <div class="inv-foot">
        <p>هذا السجل صادر إلكترونياً من نظام ${esc(SETTINGS.company || 'Senior Pro')}</p>
        <small>${esc(SETTINGS.company || '')} · ${new Date().toLocaleString('ar-EG')}</small>
      </div>
    </div>`;
}

function printCustomerRecord() {
  const name = CURRENT_CUSTOMER_RECORD;
  if (!name) { toast('لا يوجد سجل عميل مفتوح', 'error'); return; }
  const area = $('#print-invoice');
  if (!area) return;
  area.innerHTML = buildCustomerRecordHTML(name);
  document.body.classList.add('printing');
  setTimeout(() => { window.print(); setTimeout(() => document.body.classList.remove('printing'), 800); }, 120);
}

/* WhatsApp number from the customer's own phone (Egypt default prefix like buildWaNumber). */
function customerWaNumber(c) {
  const digits = (c && c.phone ? String(c.phone) : '').replace(/\D/g, '');
  if (/^\d{10,}$/.test(digits)) return digits.startsWith('20') ? digits : '20' + digits.replace(/^0+/, '');
  return '';
}

function sendCustomerRecord() {
  const name = CURRENT_CUSTOMER_RECORD;
  if (!name) { toast('لا يوجد سجل عميل مفتوح', 'error'); return; }
  const c = CUSTOMERS.find(x => x.name === name);
  const cReps = REPAIRS.filter(r => r.customer === name);
  const { cSales, ledger, paid } = customerLedger(name);
  const lastInv = cSales.slice(0, 3).map(s => `- ${s.no}: ${cur(s.total)} (محصل ${cur(saleCashPaid(s))})`).join('\n');
  const lastPay = ledger.slice(0, 3).map(l => `- ${l.label}: ${cur(l.amount)}${l.ref ? ' — ' + l.ref : ''}`).join('\n');
  const msg = `${SETTINGS.company || 'Senior Pro'}\nسجل العميل — ${name}\nالجوال: ${c?.phone || '—'}\n\nالمديونية الحالية: ${cur((c && Number(c.debt)) || 0)}\nإجمالي المدفوعات: ${cur(paid)}\nعدد الفواتير: ${cSales.length} · الإصلاحات: ${cReps.length}\n${lastInv ? '\nأحدث الفواتير:\n' + lastInv + '\n' : ''}${lastPay ? '\nآخر الدفعات:\n' + lastPay + '\n' : ''}\nشكراً لتعاملكم معنا`;
  const wa = customerWaNumber(c);
  if (!wa) { toast('لا يوجد رقم جوال لهذا العميل لإرسال السجل', 'error'); return; }
  window.open(`https://wa.me/${wa}?text=${encodeURIComponent(msg)}`, '_blank');
  toast(`تم تجهيز إرسال سجل العميل عبر واتساب إلى ${c.phone}`);
}

function customerAddModal() {
  openModal(`
    <div class="modal-head"><h3>إضافة عميل جديد</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="r-grid-2">
        <div class="field"><label>اسم العميل <b class="req">*</b></label><i class="fa-solid fa-user"></i><input type="text" id="mc-name" placeholder="الاسم الكامل"></div>
        <div class="field"><label>رقم الجوال <b class="req">*</b></label><i class="fa-solid fa-mobile-screen"></i><input type="tel" id="mc-phone" placeholder="05XXXXXXXX"></div>
        <div class="field"><label>العنوان</label><i class="fa-solid fa-location-dot"></i><input type="text" id="mc-address" placeholder="المدينة - الحي"></div>
        <div class="field"><label>البريد الإلكتروني</label><i class="fa-solid fa-envelope"></i><input type="email" placeholder="name@email.com"></div>
        <div class="field span-2"><label>ديون سابقة <small style="font-weight:400;color:var(--text-3)">(رصيد افتتاحي)</small></label><i class="fa-solid fa-hand-holding-dollar"></i><input type="number" id="mc-debt" min="0" step="0.01" placeholder="0"></div>
        <div class="field span-2"><label>ملاحظات</label><i class="fa-solid fa-clipboard"></i><textarea rows="2" id="mc-notes" placeholder="أي ملاحظات إضافية عن العميل..."></textarea></div>
      </div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-customer"><i class="fa-solid fa-check"></i> حفظ العميل</button></div>
  `);
}

function productAddModal(product) {
  const p = (product && product.name) ? product : null;
  const isEdit = !!p;
  const v = p || { name: '', cat: '', barcode: '', buy: '', sell: '', minSell: '', qty: '', low: '' };
  openModal(`
    <div class="modal-head"><h3>${isEdit ? 'تعديل المنتج' : 'إضافة منتج جديد'}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="r-grid-2">
        <div class="field span-2"><label>اسم المنتج <b class="req">*</b></label><i class="fa-solid fa-box"></i><input type="text" id="mp-name" value="${esc(v.name)}" placeholder="اسم المنتج"></div>
        <div class="field"><label>الفئة</label><i class="fa-solid fa-layer-group"></i><input type="text" id="mp-cat" value="${esc(v.cat)}" list="mp-cat-list" placeholder="مثال: شاشات">
          <datalist id="mp-cat-list">${CATEGORIES.map(c => `<option value="${esc(c.name)}">`).join('')}</datalist></div>
        <div class="field"><label>الباركود</label><i class="fa-solid fa-barcode"></i><input type="text" id="mp-barcode" value="${esc(v.barcode)}" placeholder="امسح أو أدخل الباركود"></div>
        <div class="field"><label>سعر الشراء</label><i class="fa-solid fa-arrow-right-to-bracket"></i><input type="number" id="mp-buy" value="${esc(v.buy)}" placeholder="0"></div>
        <div class="field"><label>سعر البيع</label><i class="fa-solid fa-arrow-left-long"></i><input type="number" id="mp-sell" value="${esc(v.sell)}" placeholder="0"></div>
        <div class="field"><label>أقل سعر للبيع <small style="font-weight:400;color:var(--text-3)">(لا يمكن البيع أقل منه)</small></label><i class="fa-solid fa-arrow-down-long"></i><input type="number" id="mp-min-sell" min="0" step="0.01" value="${esc(v.minSell)}" placeholder="0"></div>
        <div class="field"><label>الكمية</label><i class="fa-solid fa-boxes-stacked"></i><input type="number" id="mp-qty" value="${esc(v.qty)}" placeholder="0"></div>
        <div class="field"><label>الحد الأدنى</label><i class="fa-solid fa-triangle-exclamation"></i><input type="number" id="mp-min" value="${esc(v.low)}" placeholder="0"></div>
      </div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-product" data-product="${esc(isEdit ? v.name : '')}"><i class="fa-solid fa-check"></i> ${isEdit ? 'حفظ التعديلات' : 'حفظ المنتج'}</button></div>
  `);
}

function scanBarcodeModal() {
  openModal(`
    <div class="modal-head"><h3>مسح الباركود</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="scanner-box">
        <div class="scanner-cam">
          <div class="scan-corner tl"></div><div class="scan-corner tr"></div><div class="scan-corner bl"></div><div class="scan-corner br"></div>
          <div class="scan-line"></div>
          <i class="fa-solid fa-barcode"></i>
        </div>
        <p class="scanner-hint">وجّه الكاميرا نحو الباركود أو أدخله يدوياً</p>
        <div class="scanner-input"><i class="fa-solid fa-barcode"></i><input type="text" id="sc-barcode" placeholder="6281001000017" autofocus><button class="btn btn-accent btn-sm" data-action="scan-find"><i class="fa-solid fa-magnifying-glass"></i> بحث</button></div>
        <div id="scan-result"></div>
      </div>
    </div>
  `);
  setTimeout(() => { const el = $('#sc-barcode'); if (el) { el.focus(); el.select(); } }, 80);
}

function supplierModal(supplier) {
  const isEdit = !!supplier;
  const v = supplier || { name: '', phone: '', address: '', cats: '', due: '' };
  openModal(`
    <div class="modal-head"><h3>${isEdit ? 'تعديل بيانات المورد' : 'إضافة مورد جديد'}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="r-grid-2">
        <div class="field span-2"><label>اسم المورد <b class="req">*</b></label><i class="fa-solid fa-truck"></i><input type="text" id="ms-name" value="${esc(v.name)}" placeholder="اسم المؤسسة أو الشركة"></div>
        <div class="field"><label>رقم الجوال</label><i class="fa-solid fa-mobile-screen"></i><input type="tel" id="ms-phone" value="${esc(v.phone)}" placeholder="05XXXXXXXX"></div>
        <div class="field"><label>العنوان</label><i class="fa-solid fa-location-dot"></i><input type="text" id="ms-address" value="${esc(v.address)}" placeholder="المدينة - الحي"></div>
        <div class="field"><label>التصنيفات</label><i class="fa-solid fa-layer-group"></i><input type="text" id="ms-cats" value="${esc(v.cats)}" placeholder="شاشات، بطاريات"></div>
        <div class="field"><label>الرصيد المستحق</label><i class="fa-solid fa-hourglass-half"></i><input type="number" id="ms-due" value="${esc(v.due)}" placeholder="0"></div>
      </div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-supplier" data-supplier="${esc(isEdit ? v.name : '')}"><i class="fa-solid fa-check"></i> ${isEdit ? 'حفظ التعديلات' : 'حفظ المورد'}</button></div>
  `);
}

function customerEditModal(customer) {
  if (!customer) return;
  openModal(`
    <div class="modal-head"><h3>تعديل بيانات العميل — ${esc(customer.name)}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="r-grid-2">
        <div class="field span-2"><label>اسم العميل <b class="req">*</b></label><i class="fa-solid fa-user"></i><input type="text" id="ec-name" value="${esc(customer.name)}"></div>
        <div class="field"><label>رقم الجوال <b class="req">*</b></label><i class="fa-solid fa-mobile-screen"></i><input type="tel" id="ec-phone" value="${esc(customer.phone)}"></div>
        <div class="field"><label>العنوان</label><i class="fa-solid fa-location-dot"></i><input type="text" id="ec-address" value="${esc(customer.address)}"></div>
        <div class="field span-2"><label>ديون سابقة</label><i class="fa-solid fa-hand-holding-dollar"></i><input type="number" id="ec-debt" min="0" step="0.01" value="${esc(customer.debt ?? 0)}"></div>
        <div class="field span-2"><label>ملاحظات</label><i class="fa-solid fa-clipboard"></i><textarea rows="2" id="ec-notes">${esc(customer.notes || '')}</textarea></div>
      </div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-customer-edit" data-customer="${esc(customer.name)}"><i class="fa-solid fa-check"></i> حفظ التعديلات</button></div>
  `);
}

function deviceEditModal(device) {
  if (!device) return;
  openModal(`
    <div class="modal-head"><h3>تعديل بيانات الجهاز — ${esc(device.device)}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="r-grid-2">
        <div class="field span-2"><label>الجهاز</label><i class="fa-solid fa-mobile-screen-button"></i><input type="text" id="ed-device" value="${esc(device.device)}"></div>
        <div class="field"><label>IMEI / الرقم التسلسلي</label><i class="fa-solid fa-qrcode"></i><input type="text" id="ed-imei" value="${esc(device.imei || device.serial || '')}"></div>
        <div class="field"><label>العميل</label><i class="fa-solid fa-user"></i><input type="text" id="ed-customer" value="${esc(device.customer)}"></div>
        <div class="field"><label>الفني المكلف</label><i class="fa-solid fa-user-gear"></i><input type="text" id="ed-tech" value="${esc(device.tech || '')}"></div>
        <div class="field"><label>الحالة</label><div class="select-wrap"><i class="fa-solid fa-chevron-down"></i><select id="ed-status">
          ${Object.keys(STATUS).map(k => `<option value="${k}" ${k === device.status ? 'selected' : ''}>${STATUS[k].label}</option>`).join('')}
        </select></div></div>
      </div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-device-edit" data-device="${esc(device.device)}"><i class="fa-solid fa-check"></i> حفظ التعديلات</button></div>
  `);
}

function userModal(user) {
  const isEdit = !!user;
  const v = user || { name: '', user: '', email: '', role: 'كاشير', status: 'نشط' };
  const roleOpts = ROLE_NAMES.map(r => `<option value="${esc(r)}" ${r === v.role ? 'selected' : ''}>${esc(r)}</option>`).join('');
  const isSelf = isEdit && user.user === SESSION.user;
  openModal(`
    <div class="modal-head"><h3>${isEdit ? 'تعديل مستخدم' : 'إضافة مستخدم جديد'}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="r-grid-2">
        <div class="field span-2"><label>اسم المستخدم الكامل <b class="req">*</b></label><i class="fa-solid fa-user"></i><input type="text" id="mu-name" value="${esc(v.name)}" placeholder="الاسم الظاهر في النظام"></div>
        <div class="field"><label>اسم الدخول <b class="req">*</b></label><i class="fa-solid fa-id-badge"></i><input type="text" id="mu-user" value="${esc(v.user)}" ${isEdit ? 'readonly' : ''} placeholder="username"></div>
        <div class="field"><label>البريد الإلكتروني</label><i class="fa-solid fa-envelope"></i><input type="email" id="mu-email" value="${esc(v.email || '')}" placeholder="name@email.com"></div>
        <div class="field"><label>الدور <b class="req">*</b></label><i class="fa-solid fa-shield-halved"></i>
          <div class="select-wrap"><select id="mu-role">${roleOpts}</select><i class="fa-solid fa-chevron-down"></i></div></div>
        <div class="field"><label>الحالة</label><i class="fa-solid fa-circle-check"></i>
          <div class="select-wrap"><select id="mu-status"><option ${v.status === 'نشط' ? 'selected' : ''}>نشط</option><option ${v.status === 'موقوف' ? 'selected' : ''}>موقوف</option></select><i class="fa-solid fa-chevron-down"></i></div></div>
        <div class="field span-2"><label>كلمة المرور ${isEdit ? '(اتركها فارغة لعدم التغيير)' : '<b class="req">*</b>'}</label><i class="fa-solid fa-lock"></i><input type="password" id="mu-pass" placeholder="••••••••"></div>
      </div>
      <div class="r-section" style="margin-top:14px">
        <legend><i class="fa-solid fa-shield-halved"></i> صلاحيات الوصول <small id="mu-perm-note" style="color:var(--text-2);font-weight:400"></small></legend>
        <div class="perm-grid" id="mu-perms">
          ${ALL_VIEWS.map(v => `<label class="perm-check"><input type="checkbox" value="${v}"><i class="fa-solid ${VIEW_ICONS[v]}"></i><span>${VIEW_LABELS[v]}</span></label>`).join('')}
        </div>
      </div>
      ${isSelf ? '<div class="perm-hint"><i class="fa-solid fa-circle-info"></i> لا يمكنك تعطيل حسابك الحالي أو تغيير دوره أثناء تسجيل الدخول.</div>' : ''}
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-user" data-user="${esc(isEdit ? v.user : '')}"><i class="fa-solid fa-check"></i> ${isEdit ? 'حفظ التعديلات' : 'إضافة المستخدم'}</button></div>
  `);
  const roleSel = $('#mu-role');
  applyPermChecks(v.role, v.perms);
  if (roleSel) roleSel.addEventListener('change', () => {
    const perms = (isEdit && roleSel.value === v.role) ? v.perms : null;
    applyPermChecks(roleSel.value, perms);
  });
}

function renderUsers() {
  const tb = $('#users-table');
  if (!tb) return;
  const users = getUsers();
  tb.innerHTML = users.map((u, i) => {
    const role = ROLES[u.role] || ROLES['مدير النظام'];
    const self = u.user === SESSION.user;
    const permCount = u.role === 'مدير النظام'
      ? ALL_VIEWS.length
      : (Array.isArray(u.perms) && u.perms.length ? u.perms.length : (role.views || []).length);
    return `
    <tr data-user="${esc(u.user)}">
      <td><div class="cell-user"><div class="avatar sm ${AVATARS[i % 6]}">${esc((u.name || '?')[0])}</div><div><b>${esc(u.name)}</b>${self ? '<small>أنت الآن</small>' : ''}</div></div></td>
      <td><b>${esc(u.user)}</b></td>
      <td><span class="chip chip-${role.chip}">${esc(u.role)}</span><small class="perm-count">${u.role === 'مدير النظام' ? 'كل الصلاحيات' : permCount + ' / ' + ALL_VIEWS.length + ' صلاحية'}</small></td>
      <td>${u.status === 'نشط' ? '<span class="chip chip-green">نشط</span>' : '<span class="chip chip-red">موقوف</span>'}</td>
      <td><div class="row-actions">
        <button class="icon-btn xs" data-action="edit-user" data-user="${esc(u.user)}" title="تعديل"><i class="fa-solid fa-pen"></i></button>
        <button class="icon-btn xs ${u.status === 'نشط' ? 'danger' : ''}" data-action="toggle-user" data-user="${esc(u.user)}" title="${u.status === 'نشط' ? 'إيقاف' : 'تفعيل'}"><i class="fa-solid ${u.status === 'نشط' ? 'fa-ban' : 'fa-circle-check'}"></i></button>
        ${!self && u.user !== 'admin' ? `<button class="icon-btn xs danger" data-action="del-user" data-user="${esc(u.user)}" title="حذف"><i class="fa-solid fa-trash"></i></button>` : ''}
      </div></td>
    </tr>`;
  }).join('');
}

/* ---------- Web license engine (desktop-style licensing for the web build) ----------
   Machine-bound offline keys: SP1-{PLAN}-{EXP}-{SIG}
   PLAN: Y = yearly, L = lifetime | EXP: YYYYMMDD or EVER | SIG: 8-hex signature
   NOTE: offline validation in JS is obfuscation-level protection. Keep license-generator.html private. */
const LIC_SECRET = 'SPRO-LIC-2026-v1::SeniorPro';
const LIC_TRIAL_DAYS = 7;
function licHash(str) {
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 0x01000193); }
  return ('0000000' + (h >>> 0).toString(16).toUpperCase()).slice(-8);
}
function licNormMachine(v) {
  const raw = String(v || '').trim().toUpperCase();
  const compact = raw.replace(/[^A-Z0-9]/g, '');
  if (/^[0-9A-F]{32}$/.test(compact)) return compact.match(/.{4}/g).join('-');
  const legacy = compact.match(/^SP([0-9A-F]{12})$/);
  if (legacy) return 'SP-' + legacy[1].match(/.{4}/g).join('-');
  return raw;
}
function licMachine() {
  try {
    // Hardware fingerprint computed by the local server (CPU/board/BIOS/disks).
    if (MACHINE_ID) {
      const doc = DB.get('machine', null);
      const stored = doc && (typeof doc === 'string' ? doc : doc.value);
      if (stored !== MACHINE_ID) DB.set('machine', { value: MACHINE_ID });
      return MACHINE_ID;
    }
    const doc = DB.get('machine', null);
    let m = doc && (typeof doc === 'string' ? doc : doc.value);
    if (!m) {
      const seed = (navigator.userAgent || '') + '|' + (navigator.platform || '') + '|' + (navigator.language || '') + '|' + Math.random().toString(36).slice(2) + Date.now();
      const h = licHash(seed) + licHash('2' + seed);
      m = 'SP-' + h.slice(0, 4) + '-' + h.slice(4, 8) + '-' + h.slice(8, 12);
      DB.set('machine', { value: m });
    }
    return m;
  } catch (e) { return 'SP-0000-0000-0000'; }
}
function licStore() {
  try {
    const doc = DB.get('license', {});
    return (doc && typeof doc === 'object' && !Array.isArray(doc)) ? doc : {};
  } catch (e) { return {}; }
}
function licSave(l) { try { DB.set('license', l || {}); } catch (e) {} }
function licKeyInfo(key) {
  const clean = String(key || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const m = clean.match(/^SP1([YL])(EVER|\d{8})([0-9A-F]{8})$/);
  if (!m) return { ok: false, message: 'صيغة الكود غير صحيحة' };
  const plan = m[1], exp = m[2], sig = m[3];
  if (licHash(LIC_SECRET + '|' + licMachine() + '|' + plan + '|' + exp) !== sig)
    return { ok: false, message: 'هذا الكود غير صالح لهذا الجهاز' };
  if (exp !== 'EVER') {
    const y = +exp.slice(0, 4), mo = +exp.slice(4, 6), d = +exp.slice(6, 8);
    const end = new Date(y, mo - 1, d, 23, 59, 59).getTime();
    if (!end || isNaN(end)) return { ok: false, message: 'تاريخ انتهاء الكود غير صالح' };
    if (end < Date.now()) return { ok: false, message: 'هذا الكود منتهي الصلاحية' };
    return { ok: true, plan, expiresAt: end };
  }
  return { ok: true, plan, expiresAt: null };
}
function licStatus() {
  const machine = licMachine();
  const L = licStore();
  const day = 24 * 3600 * 1000;
  // Hardware changed (disk/BIOS/board/move) → the old binding is void.
  if (L.plan && L.machine && licNormMachine(L.machine) !== licNormMachine(machine)) {
    return { state: 'expired', reason: 'hardware', machine, label: 'تغيّرت بصمة الجهاز', expiresAt: L.expiresAt || null, daysLeft: 0 };
  }
  // Legacy activations without a stored fingerprint: verify the key against this machine once.
  if (L.plan && !L.machine && L.key) {
    const info = licKeyInfo(L.key);
    if (!info.ok && /الجهاز/.test(info.message || '')) {
      return { state: 'expired', reason: 'hardware', machine, label: 'تغيّرت بصمة الجهاز', expiresAt: L.expiresAt || null, daysLeft: 0 };
    }
    if (info.ok) { L.machine = machine; licSave(L); }
  }
  if (L.plan && (L.expiresAt == null || L.expiresAt > Date.now())) {
    const life = L.expiresAt == null;
    return {
      state: 'active', machine, label: life ? 'مدى الحياة' : 'سنوي',
      expiresAt: L.expiresAt || null,
      daysLeft: life ? 0 : Math.ceil((L.expiresAt - Date.now()) / day),
    };
  }
  if (L.plan && L.expiresAt != null && L.expiresAt <= Date.now())
    return { state: 'expired', reason: 'annual', machine, label: 'سنوي (منتهي)', expiresAt: L.expiresAt, daysLeft: 0 };
  if (!L.trialStart) { L.trialStart = Date.now(); licSave(L); }
  const left = Math.ceil((L.trialStart + LIC_TRIAL_DAYS * day - Date.now()) / day);
  if (left > 0)
    return { state: 'trial-active', machine, label: 'فترة تجريبية', expiresAt: L.trialStart + LIC_TRIAL_DAYS * day, daysLeft: left };
  return { state: 'expired', reason: 'trial', machine, label: 'تجريبية (منتهية)', expiresAt: L.trialStart + LIC_TRIAL_DAYS * day, daysLeft: 0 };
}
if (!window.senior) {
  window.senior = {
    licenseStatus: () => Promise.resolve(licStatus()),
    activate: (key) => Promise.resolve().then(() => {
      const info = licKeyInfo(key);
      if (!info.ok) return { ok: false, message: info.message };
      const life = info.expiresAt == null;
      const L = licStore();
      L.plan = info.plan === 'L' ? 'lifetime' : 'yearly';
      L.expiresAt = info.expiresAt;
      L.activatedAt = Date.now();
      L.machine = licMachine();
      L.key = String(key).trim().toUpperCase();
      licSave(L);
      return { ok: true, message: life ? 'تم التفعيل — نسخة مدى الحياة' : 'تم التفعيل — اشتراك سنوي' };
    }),
    reload: () => location.reload(),
  };
}

const SAMPLE_CATEGORIES = [];
let CATEGORIES = DB.get('categories', SAMPLE_CATEGORIES);

function catCount(name) { return PRODUCTS.filter(p => (p.cat || '').trim() === name).length; }

function renderCategories() {
  const grid = $('#categories-grid');
  if (!grid) return;
  const maxCount = Math.max(1, ...CATEGORIES.map(c => catCount(c.name)));
  grid.innerHTML = CATEGORIES.map(c => {
    const count = catCount(c.name);
    const pct = Math.round((count / maxCount) * 100);
    return `
    <div class="card cat-card" data-cat="${esc(c.name)}">
      <div class="cat-ic ${safeCls(c.color, 'ic-navy')}"><i class="fa-solid ${safeIcon(c.icon)}"></i></div>
      <b>${esc(c.name)}</b>
      <span>${count} منتج</span>
      <div class="progress"><span class="bar" style="width:${pct}%"></span></div>
      <div class="cat-actions">
        <button class="icon-btn xs" data-action="view-category" data-cat="${esc(c.name)}" title="عرض المنتجات"><i class="fa-solid fa-eye"></i></button>
        <button class="icon-btn xs" data-action="edit-category" data-cat="${esc(c.name)}" title="تعديل"><i class="fa-solid fa-pen"></i></button>
        <button class="icon-btn xs danger" data-action="del-category" data-cat="${esc(c.name)}" title="حذف"><i class="fa-solid fa-trash"></i></button>
      </div>
    </div>`;
  }).join('');
  if (!CATEGORIES.length) grid.innerHTML = '<div class="empty-state" style="grid-column:1/-1">لا توجد تصنيفات بعد — أضف أول تصنيف</div>';
}

function categoryModal(category) {
  const isEdit = !!category;
  const v = category || { name: '', icon: 'fa-box', color: 'ic-navy' };
  const icons = ['fa-mobile-screen', 'fa-battery-full', 'fa-headphones', 'fa-plug', 'fa-cable-car', 'fa-microchip', 'fa-laptop', 'fa-tablet-screen-button', 'fa-tv', 'fa-print', 'fa-watch', 'fa-toolbox', 'fa-sim-card', 'fa-memory', 'fa-box'];
  const colors = ['ic-navy', 'ic-blue', 'ic-green', 'ic-orange', 'ic-purple', 'ic-red', 'ic-teal', 'ic-amber'];
  const iconOpts = icons.map(i => `<option value="${i}" ${i === v.icon ? 'selected' : ''}><i class="fa-solid ${i}"></i> ${i}</option>`).join('');
  const colorOpts = colors.map(cl => `<option value="${cl}" ${cl === v.color ? 'selected' : ''}>${cl.replace('ic-', '')}</option>`).join('');
  openModal(`
    <div class="modal-head"><h3>${isEdit ? `تعديل تصنيف — ${esc(v.name)}` : 'إضافة تصنيف جديد'}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="r-grid-2">
        <div class="field span-2"><label>اسم التصنيف <b class="req">*</b></label><i class="fa-solid fa-layer-group"></i><input type="text" id="cg-name" value="${esc(v.name)}" placeholder="مثال: شاشات الجوالات"></div>
        <div class="field"><label>الأيقونة</label><i class="fa-solid fa-icons"></i>
          <div class="select-wrap"><select id="cg-icon">${iconOpts}</select><i class="fa-solid fa-chevron-down"></i></div></div>
        <div class="field"><label>اللون</label><i class="fa-solid fa-palette"></i>
          <div class="select-wrap"><select id="cg-color">${colorOpts}</select><i class="fa-solid fa-chevron-down"></i></div></div>
      </div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-category" data-cat="${esc(isEdit ? v.name : '')}"><i class="fa-solid fa-check"></i> ${isEdit ? 'حفظ التعديلات' : 'إضافة التصنيف'}</button></div>
  `);
}

function returnModal() {
  openModal(`
    <div class="modal-head"><h3>استلام مرتجع</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="r-grid-2">
        <div class="field span-2"><label>المنتج <b class="req">*</b></label><i class="fa-solid fa-box"></i><input type="text" id="r-product" placeholder="ابحث عن المنتج..."></div>
        <div class="field"><label>الكمية</label><i class="fa-solid fa-sort"></i><input type="number" id="r-qty" value="1" min="1"></div>
        <div class="field"><label>النوع</label><i class="fa-solid fa-shuffle"></i>
          <div class="select-wrap"><select id="r-type"><option>من العميل</option><option>للمورد</option></select><i class="fa-solid fa-chevron-down"></i></div></div>
        <div class="field span-2"><label>سبب الإرجاع</label><i class="fa-solid fa-clipboard"></i><textarea id="r-reason" rows="2" placeholder="سبب الإرجاع..."></textarea></div>
      </div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-return"><i class="fa-solid fa-check"></i> تسجيل المرتجع</button></div>
  `);
}

function returnViewModal(r) {
  const lines = r.items && r.items.length
    ? r.items.map(i => `<tr><td>${esc(i.name)}</td><td>${i.qty}</td><td>${cur(i.price)}</td><td>${cur((Number(i.price) || 0) * i.qty)}</td></tr>`).join('')
    : `<tr><td>${esc(r.product || '—')}</td><td>${r.qty || 0}</td><td>${cur((r.amount || 0) / (r.qty || 1))}</td><td>${cur(r.amount || 0)}</td></tr>`;
  const ref = r.saleNo || r.ref || '—';
  const type = r.type || 'جزئي';
  const status = r.status || 'مرتجع';
  openModal(`
    <div class="modal-head"><h3><i class="fa-solid fa-rotate-left"></i> المرتجع ${esc(r.no || '')}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="r-grid-2">
        <div class="field"><label>رقم المرتجع</label><i class="fa-solid fa-hashtag"></i><input value="${esc(r.no || '—')}" readonly></div>
        <div class="field"><label>التاريخ</label><i class="fa-solid fa-calendar"></i><input value="${esc(r.date || '—')}" readonly></div>
        <div class="field"><label>النوع</label><i class="fa-solid fa-shuffle"></i><input value="${esc(type)}" readonly></div>
        <div class="field"><label>المرجع</label><i class="fa-solid fa-file-invoice"></i><input value="${esc(ref)}" readonly></div>
        <div class="field"><label>الحالة</label><i class="fa-solid fa-circle-check"></i><input value="${esc(status)}" readonly></div>
        <div class="field"><label>الإجمالي</label><i class="fa-solid fa-money-bill-wave"></i><input value="${cur(r.total != null ? r.total : (r.amount || 0))}" readonly></div>
      </div>
      <div class="r-section" style="margin-top:14px">
        <legend><i class="fa-solid fa-box"></i> الأصناف</legend>
        <div class="table-wrap"><table class="table"><thead><tr><th>الصنف</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead><tbody>${lines}</tbody></table></div>
      </div>
      ${r.reason ? `<div class="r-section" style="margin-top:14px"><legend><i class="fa-solid fa-clipboard"></i> سبب الإرجاع</legend><p style="color:var(--text);font-size:13.5px;line-height:1.7">${esc(r.reason)}</p></div>` : ''}
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إغلاق</button><button class="btn btn-accent" data-action="print-return-pos" data-return="${esc(r.no || '')}"><i class="fa-solid fa-print"></i> طباعة</button></div>
  `);
}

function employeeModal(emp) {
  const isEdit = !!emp;
  const v = emp || { name: '', role: 'فني جوالات', phone: '', join: '', salary: '', rating: '4.5', perf: 80 };
  openModal(`
    <div class="modal-head"><h3>${isEdit ? 'تعديل بيانات الموظف' : 'إضافة موظف جديد'}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="r-grid-2">
        <div class="field span-2"><label>اسم الموظف <b class="req">*</b></label><i class="fa-solid fa-user"></i><input type="text" id="me-name" value="${esc(v.name)}" placeholder="الاسم الكامل"></div>
        <div class="field"><label>الدور <b class="req">*</b></label><i class="fa-solid fa-briefcase"></i><input type="text" id="me-role" value="${esc(v.role)}" placeholder="مثال: فني جوالات"></div>
        <div class="field"><label>رقم الجوال</label><i class="fa-solid fa-mobile-screen"></i><input type="tel" id="me-phone" value="${esc(v.phone)}" placeholder="05XXXXXXXX"></div>
        <div class="field"><label>سنة الانضمام</label><i class="fa-solid fa-calendar"></i><input type="number" id="me-join" value="${esc(v.join)}" placeholder="2020"></div>
        <div class="field"><label>الراتب</label><i class="fa-solid fa-money-bill-wave"></i><input type="number" id="me-salary" value="${esc(v.salary)}" placeholder="0"></div>
        <div class="field"><label>التقييم</label><i class="fa-solid fa-star"></i><input type="number" step="0.1" id="me-rating" value="${esc(v.rating)}" placeholder="4.5"></div>
        <div class="field"><label>أداء الشهر %</label><i class="fa-solid fa-chart-line"></i><input type="number" id="me-perf" value="${esc(v.perf)}" placeholder="80"></div>
      </div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-employee" data-emp="${esc(isEdit ? v.name : '')}"><i class="fa-solid fa-check"></i> ${isEdit ? 'حفظ التعديلات' : 'إضافة الموظف'}</button></div>
  `);
}

/* ---------- Actions ---------- */
/* ---------- Point of Sale ---------- */
function prodIcon(cat) {
  const c = String(cat || '').trim();
  if (c.includes('شاش')) return 'fa-mobile-screen';
  if (c.includes('بطار')) return 'fa-battery-full';
  if (c.includes('شحن')) return 'fa-plug';
  if (c.includes('كابل')) return 'fa-cable-car';
  if (c.includes('سماع') || c.includes('إكسسوار')) return 'fa-headphones';
  if (c.includes('كامير')) return 'fa-camera';
  if (c.includes('لابتوب')) return 'fa-laptop';
  if (c.includes('خدم')) return 'fa-screwdriver-wrench';
  if (c.includes('لوحي')) return 'fa-tablet-screen-button';
  if (c.includes('زجاج')) return 'fa-glass-water';
  return 'fa-box';
}

function renderPOS() {
  const grid = $('#pos-grid');
  const menu = $('#pos-cat-menu');
  const label = $('#pos-cat-label');
  if (!grid) return;
  const cats = ['الكل', ...new Set(PRODUCTS.map(p => (p.cat || '').trim()).filter(Boolean))];
  if (menu) menu.innerHTML = cats.map(c => `<a class="${POS_FILTER.cat === c ? 'active' : ''}" data-action="pos-filter" data-poscat="${esc(c)}">${esc(c)}</a>`).join('');
  if (label) label.innerHTML = `${esc(POS_FILTER.cat)} <i class="fa-solid fa-chevron-down"></i>`;
  const q = (POS_FILTER.q || '').toLowerCase().trim();
  const list = PRODUCTS.filter(p => {
    const okCat = POS_FILTER.cat === 'الكل' || (p.cat || '') === POS_FILTER.cat;
    const hay = (p.name + ' ' + (p.barcode || '') + ' ' + (p.cat || '')).toLowerCase();
    return okCat && (!q || hay.includes(q));
  });
  grid.innerHTML = list.map(p => {
    const out = (Number(p.qty) || 0) <= 0;
    return `<button class="pos-item${out ? ' out' : ''}" data-action="pos-add" data-pos="${esc(p.name)}" title="${out ? 'نفد المخزون' : ''}">
      <span class="pi-ic"><i class="fa-solid ${prodIcon(p.cat)}"></i></span>
      <b>${esc(p.name)}</b>
      <span class="pi-cat">${esc(p.cat || '')}${out ? ' · نفد المخزون' : ' · متوفر ' + (Number(p.qty) || 0)}</span>
      <span class="pi-price">${cur(p.sell)}</span>
    </button>`;
  }).join('');
  if (!list.length) grid.innerHTML = '<div class="pos-empty">لا توجد منتجات مطابقة لبحثك</div>';
}

function populatePosCustomers() {
  const sel = $('#pos-customer');
  if (!sel) return;
  const cur = sel.value || 'عميل نقدي';
  sel.innerHTML = '<option value="عميل نقدي">عميل نقدي</option>' + CUSTOMERS.map(c => `<option value="${esc(c.name)}">${esc(c.name)}</option>`).join('');
  if (CUSTOMERS.some(c => c.name === cur) || cur === 'عميل نقدي') sel.value = cur;
  sel.onchange = () => { updateCustomerDebtUI(); updatePayUI(); };
  updateCustomerDebtUI();
}

/* The customer currently selected in the POS cart (null for "عميل نقدي"). */
function posCustomerObj() {
  const name = ($('#pos-customer')?.value || '').trim();
  if (!name || name === 'عميل نقدي') return null;
  return CUSTOMERS.find(c => c.name === name) || null;
}

/* Shows the selected customer's outstanding debt (مديونية) under the customer picker. */
function updateCustomerDebtUI() {
  const c = posCustomerObj();
  const row = $('#pos-debt-row');
  if (row) row.style.display = c ? '' : 'none';
  const el = $('#pos-cust-debt');
  if (el) el.textContent = cur(c ? (Number(c.debt) || 0) : 0);
}

function posAdd(name) {
  const p = PRODUCTS.find(x => x.name === name);
  if (!p) return;
  if ((Number(p.qty) || 0) <= 0) { toast('هذا المنتج غير متوفر حالياً', 'error'); return; }
  const inCart = POS_CART.find(c => c.name === name);
  const curQty = inCart ? inCart.qty : 0;
  if (curQty + 1 > (Number(p.qty) || 0)) { toast('الكمية المطلوبة أكبر من المتوفر في المخزون', 'error'); return; }
  if (inCart) inCart.qty++;
  else POS_CART.push({ name, price: Number(p.sell) || 0, qty: 1 });
  renderCart();
}

function posQty(name, d) {
  const item = POS_CART.find(c => c.name === name);
  if (!item) return;
  d = Number(d);
  if (!Number.isFinite(d) || d === 0) return;
  d = Math.trunc(d);
  item.qty = (Number(item.qty) || 0) + d;
  if (!Number.isFinite(item.qty) || item.qty <= 0) POS_CART = POS_CART.filter(c => c.name !== name);
  else {
    const p = PRODUCTS.find(x => x.name === name);
    if (p && item.qty > (Number(p.qty) || 0)) { item.qty = Number(p.qty) || 0; toast('وصلت للحد الأقصى المتوفر', 'info'); }
  }
  renderCart();
}

function posRemove(name) { POS_CART = POS_CART.filter(c => c.name !== name); renderCart(); }

// Quantity parser — rejects negative/zero/NaN (previously `-5` was accepted and corrupted totals/stock)
function parseQty(value, fallback = 1) {
  const n = parseInt(String(value ?? ''), 10);
  if (!Number.isFinite(n) || n < 1) return fallback;
  return Math.min(n, 99999);
}

function posTotals() {
  const sub = POS_CART.reduce((s, c) => s + (Number(c.price) || 0) * c.qty, 0);
  const rawDisc = parseFloat($('#pos-discount')?.value) || 0;
  const discType = ($('#pos-discount-type')?.value || 'amount');
  let disc = Math.min(Math.max(rawDisc, 0), sub);
  if (discType === 'percent') disc = sub * Math.min(Math.max(rawDisc, 0), 100) / 100;
  const taxEnabled = $('#pos-tax-toggle') ? $('#pos-tax-toggle').checked : true;
  const taxRate = taxEnabled ? (Number(SETTINGS.tax) || 0) : 0;
  const tax = (sub - disc) * taxRate / 100;
  const total = sub - disc + tax;
  return { sub, disc, tax, total, taxRate, discType, taxEnabled };
}

/* Minimum sale price: a product may declare a floor price no sale can go below. */
function productMinSell(name) {
  const p = PRODUCTS.find(x => x.name === name);
  const m = p ? Number(p.minSell) : 0;
  return Number.isFinite(m) && m > 0 ? m : 0;
}

/* Returns the first line whose effective unit price (after the invoice discount) is under its floor. */
function firstBelowMinSale(lines, disc, sub) {
  if (!Array.isArray(lines) || !lines.length) return null;
  const factor = sub > 0 ? Math.max(0, 1 - (Number(disc) || 0) / sub) : 1;
  for (const c of lines) {
    const min = productMinSell(c.name);
    if (!min) continue;
    const unit = (Number(c.price) || 0) * factor;
    if (unit + 1e-9 < min) return { name: c.name, unit, min };
  }
  return null;
}

/* Returns the first cart line whose effective unit price (after the invoice discount) is under its floor. */
function belowMinSaleLine() {
  if (!POS_CART.length) return null;
  const t = posTotals();
  return firstBelowMinSale(POS_CART, t.disc, t.sub);
}

/* Blocks checkout with a clear Arabic message when any line falls under its minimum sale price. */
function checkMinSalePrices() {
  const bad = belowMinSaleLine();
  if (!bad) return true;
  toast(`لا يمكن بيع «${bad.name}» بأقل من ${cur(bad.min)} — السعر الحالي ${cur(bad.unit)}`, 'error');
  return false;
}

function currentPaid() {
  let s = 0;
  // المبالغ النقدية فقط — المبلغ المكتوب في خانة «آجل» ليس دفعة محصلة
  document.querySelectorAll('.pay-amt:not(:disabled)').forEach(inp => {
    if (inp.dataset.pay === 'آجل') return;
    s += parseFloat(inp.value) || 0;
  });
  return s;
}

function updatePayUI() {
  const t = posTotals();
  const paid = currentPaid();
  const due = Math.max(0, t.total - paid);
  const over = Math.max(0, paid - t.total);
  const el = $('#ps-due');
  if (el) {
    el.textContent = due > 0 ? `المتبقي ${cur(due)}` : 'مكتمل الدفع ✓';
    el.classList.toggle('text-green', due <= 0);
    el.classList.toggle('text-red', due > 0);
  }
  // فائض الدفع (العميل دفع أكثر من قيمة الفاتورة) + مربع الخصم من المديونية
  const c = posCustomerObj();
  const overRow = $('#pos-over-row');
  if (overRow) overRow.style.display = over > 0 ? '' : 'none';
  const overEl = $('#ps-over');
  if (overEl) overEl.textContent = cur(over);
  const deduct = $('#pos-deduct-debt');
  if (deduct && !deduct.disabled) {
    const span = deduct.parentElement.querySelector('span');
    if (span) span.textContent = c ? `خصم الفائض من مديونية العميل (${c.name})` : 'خصم الفائض من مديونية العميل';
  }
  // تنبيه: المتبقي على البيع الآجل يُضاف لمديونية العميل المسجل
  const note = $('#pos-debt-note');
  if (note) {
    const show = due > 0 && c;
    note.style.display = show ? '' : 'none';
    if (show) note.textContent = `تنبيه: المتبقي ${cur(due)} سيُضاف إلى مديونية العميل تلقائياً`;
  }
  return due;
}

function getPosPayments(total) {
  const res = [];
  let paid = 0;
  document.querySelectorAll('.pay-amt:not(:disabled)').forEach(inp => {
    const v = parseFloat(inp.value) || 0;
    if (v <= 0) return;
    res.push({ method: inp.dataset.pay, amount: v });
    paid += v;
  });
  const due = Math.max(0, total - paid);
  if (due > 0) {
    const idx = res.findIndex(x => x.method === 'آجل');
    if (idx > -1) res[idx].amount += due;
    else res.push({ method: 'آجل', amount: due });
  }
  if (!res.length) {
    const active = $('.pay-method.active');
    res.push({ method: active ? active.dataset.pay : 'نقداً', amount: total });
  }
  return res;
}

function paymentsText(p) {
  if (!Array.isArray(p) || !p.length) return 'نقداً';
  return p.map(x => `${x.method} (${cur(x.amount)})`).join(' + ');
}

function paymentsRows(p) {
  if (!Array.isArray(p) || !p.length) return `<div><span>طريقة الدفع</span><b>نقداً</b></div>`;
  return p.map(x => `<div><span>${esc(x.method)}</span><b>${cur(x.amount)}</b></div>`).join('');
}

function salePayRows(sale) {
  if (Array.isArray(sale.payments) && sale.payments.length) return paymentsRows(sale.payments);
  return `<div><span>طريقة الدفع</span><b>${esc(sale.pay || 'نقداً')}</b></div>`;
}

function taxRow(sale, label) {
  if (sale.taxEnabled === false) return '';
  return `<div><span>${label || 'الضريبة'} (${sale.taxRate}%)</span><b>${cur(sale.tax)}</b></div>`;
}

function printDocument(html) {
  const area = $('#print-invoice');
  if (!area) return;
  area.innerHTML = html;
  area.querySelectorAll('[data-barcode]').forEach(el => genBarcode(el, el.dataset.barcode));
  area.querySelectorAll('[data-qr]').forEach(el => {
    el.innerHTML = '';
    if (typeof QRCode !== 'undefined') new QRCode(el, { text: el.dataset.qr, width: 78, height: 78 });
    else el.appendChild(makeQR(el.dataset.qr));
  });
  document.body.classList.add('printing');
  setTimeout(() => { window.print(); setTimeout(() => { area.innerHTML = ''; document.body.classList.remove('printing'); }, 800); }, 120);
}

function customersOptions() {
  return CUSTOMERS.map(c => `<option value="${esc(c.name)}">${esc(c.name)}</option>`).join('');
}

function nextNum(prefix, arr) {
  // Persistent per-prefix counter: never reuses a number deleted from the array
  const fromArr = Math.max(0, ...((arr || []).map(x => parseInt(String(x.no || '').replace(/\D/g, '')) || 0)));
  const key = 'counter_' + (prefix || 'GEN');
  const nxt = Math.max(Number(SETTINGS[key]) || 0, fromArr) + 1;
  SETTINGS[key] = nxt;
  try { DB.set('settings', SETTINGS); } catch (e) {}
  return (prefix || '') + nxt;
}

function invoiceHead(title, no, date) {
  return `
    <div class="inv-head">
      <div class="inv-logo">${safeLogo(SETTINGS.logo) ? `<img src="${safeLogo(SETTINGS.logo)}" alt="logo" style="width:100%;height:100%;object-fit:contain;border-radius:inherit;background:#fff">` : 'ظˆ'}</div>
      <div class="inv-brand">
        <h1>${esc(SETTINGS.company || '')}</h1>
        <p>نظام إدارة مراكز الصيانة — Senior Pro</p>
        <div class="inv-brand-meta">
          <span><i class="fa-solid fa-location-dot"></i> ${esc(SETTINGS.address || '')}</span>
          <span><i class="fa-solid fa-mobile-screen"></i> ${esc(SETTINGS.mobile || '')} ${SETTINGS.phone ? '· ' + esc(SETTINGS.phone) : ''}</span>
        </div>
      </div>
      <div class="inv-title">
        <h2>${esc(title)}</h2>
        <b>${esc(no)}</b>
        <small>${esc(date)}</small>
      </div>
    </div>`;
}

function invTableRows(lines) {
  return lines.map((i, idx) => `
    <tr>
      <td>${idx + 1}</td>
      <td class="inv-name">${esc(i.name)}</td>
      <td>${i.qty}</td>
      <td>${cur(i.price)}</td>
      <td>${cur((Number(i.price) || 0) * i.qty)}</td>
    </tr>`).join('');
}

function buildPOHTML(p) {
  const lines = Array.isArray(p.lines) && p.lines.length ? p.lines : [];
  const total = p.total != null ? p.total : lines.reduce((s, l) => s + (Number(l.price) || 0) * l.qty, 0);
  return `
    <div class="inv-wrap">
      ${invoiceHead('أمر شراء', p.no, p.date || '')}
      <div class="inv-info">
        <div><span>المورد</span><b>${esc(p.supplier || '—')}</b></div>
        <div><span>عدد الأصناف</span><b>${lines.length ? lines.length + ' صنف' : (p.items || 0) + ' صنف'}</b></div>
        <div><span>الحالة</span><b>${p.status === 'مستلم' ? 'مستلم' : 'قيد التوريد'}</b></div>
      </div>
      ${lines.length ? `<table class="inv-table">
        <thead><tr><th>#</th><th>الصنف</th><th>الكمية</th><th>سعر الشراء</th><th>الإجمالي</th></tr></thead>
        <tbody>${invTableRows(lines)}</tbody>
      </table>` : ''}
      <div class="inv-totals"><div class="inv-grand"><span>إجمالي الأمر</span><b>${cur(total)}</b></div></div>
      <div class="inv-foot"><p>${esc(SETTINGS.company || '')} — أمر شراء ${esc(p.no)}</p><small>${esc(p.date || '')}</small></div>
    </div>`;
}

function supplierProducts(s) {
  const cats = String(s.cats || '').split(/[،,]/).map(c => c.trim()).filter(Boolean);
  if (!cats.length) return PRODUCTS;
  return PRODUCTS.filter(p => cats.includes(p.cat));
}

function buildSupplierHTML(s) {
  const today = new Date().toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' });
  const prods = supplierProducts(s);
  return `
    <div class="inv-wrap">
      ${invoiceHead('بطاقة مورد', s.name, today)}
      <table class="inv-details">
        <tr><td>اسم المورد</td><td>${esc(s.name || '—')}</td></tr>
        <tr><td>رقم الجوال</td><td>${esc(s.phone || '—')}</td></tr>
        <tr><td>العنوان</td><td>${esc(s.address || '—')}</td></tr>
        <tr><td>التصنيفات</td><td>${esc(s.cats || '—')}</td></tr>
        <tr><td>الأرصدة المستحقة</td><td>${cur(s.due || 0)}</td></tr>
      </table>
      ${prods.length ? `<table class="inv-table">
        <thead><tr><th>#</th><th>المنتج</th><th>سعر البيع</th><th>سعر الشراء</th><th>الكمية</th></tr></thead>
        <tbody>${prods.map((p, i) => `<tr><td>${i + 1}</td><td class="inv-name">${esc(p.name)}</td><td>${cur(p.sell)}</td><td>${cur(p.buy)}</td><td>${Number(p.qty) || 0}</td></tr>`).join('')}</tbody>
      </table>` : ''}
      <div class="inv-foot"><p>${esc(SETTINGS.company || '')} — بيانات المورد</p><small>تاريخ الطباعة: ${today}</small></div>
    </div>`;
}

/* ---------- Price quotes ---------- */
function renderQuoteLines() {
  const box = $('#q-lines-list');
  if (!box) return;
  const empty = $('#q-lines-empty');
  if (empty) empty.style.display = QUOTE_LINES.length ? 'none' : '';
  box.innerHTML = QUOTE_LINES.map(l => `
    <div class="part-row">
      <span class="part-name">${esc(l.name)}</span>
      <span class="part-qty">× ${l.qty}</span>
      <span class="part-price">${cur((Number(l.price) || 0) * l.qty)}</span>
      <button class="icon-btn xs danger" data-action="remove-quote-line" data-line="${esc(l.name)}" title="إزالة"><i class="fa-solid fa-xmark"></i></button>
    </div>`).join('');
  const totalEl = $('#q-lines-total');
  if (totalEl) totalEl.textContent = cur(QUOTE_LINES.reduce((s, l) => s + (Number(l.price) || 0) * l.qty, 0));
}

function openQuoteModal() {
  QUOTE_LINES = [];
  const opts = PRODUCTS.map(p => `<option value="${esc(p.name)}">${esc(p.name)} — ${cur(p.sell)}</option>`).join('');
  openModal(`
    <div class="modal-head"><h3><i class="fa-solid fa-file-lines"></i> عرض سعر جديد</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="field"><label>العميل</label><i class="fa-solid fa-user"></i><select id="q-customer"><option value="عميل نقدي">عميل نقدي</option>${customersOptions()}</select></div>
      <div class="parts-add">
        <div class="field grow"><label>المنتج</label><i class="fa-solid fa-box"></i><select id="q-product">${opts || '<option value="">لا توجد منتجات</option>'}</select></div>
        <div class="field"><label>الكمية</label><i class="fa-solid fa-hashtag"></i><input type="number" id="q-qty" value="1" min="1"></div>
        <div class="field"><label>السعر</label><i class="fa-solid fa-tag"></i><input type="number" id="q-price" min="0" value="0"></div>
        <button class="btn btn-accent" data-action="add-quote-line"><i class="fa-solid fa-plus"></i> إضافة</button>
      </div>
      <div class="parts-list" id="q-lines-list"></div>
      <div class="parts-empty" id="q-lines-empty">أضف أصنافاً لعرض السعر</div>
      <div class="cs-totals" style="margin-top:12px"><div><span>إجمالي عرض السعر</span><b id="q-lines-total">${cur(0)}</b></div></div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-quote"><i class="fa-solid fa-floppy-disk"></i> حفظ عرض السعر</button></div>
  `);
  const sel = $('#q-product');
  if (sel) sel.addEventListener('change', () => {
    const p = PRODUCTS.find(x => x.name === sel.value);
    const pe = $('#q-price'); if (p && pe) pe.value = Number(p.sell) || 0;
  });
  renderQuoteLines();
}

function renderQuotes() {
  const tbody = $('#quotes-table');
  if (!tbody) return;
  if (!QUOTES.length) { tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#94A3B8;padding:22px">لا توجد عروض أسعار بعد</td></tr>'; return; }
  tbody.innerHTML = QUOTES.map(q => `
    <tr>
      <td><b>${esc(q.no)}</b><small class="bc-num">${esc(q.date)}</small></td>
      <td>${esc(q.customer || 'عميل نقدي')}</td>
      <td>${q.lines.reduce((a, l) => a + (Number(l.qty) || 0), 0)}</td>
      <td>${cur(q.total)}</td>
      <td>${esc(q.date)}</td>
      <td><span class="chip chip-green">${esc(q.status || 'ساري')}</span></td>
      <td><div class="row-actions">
        <button class="icon-btn xs" data-action="print-quote" data-quote="${esc(q.no)}" title="طباعة"><i class="fa-solid fa-print"></i></button>
        <button class="icon-btn xs" data-action="quote-to-sale" data-quote="${esc(q.no)}" title="تحويل لفاتورة"><i class="fa-solid fa-cart-shopping"></i></button>
        <button class="icon-btn xs danger" data-action="delete-quote" data-quote="${esc(q.no)}" title="حذف"><i class="fa-solid fa-trash"></i></button>
      </div></td>
    </tr>`).join('');
}

function buildQuoteHTML(q) {
  const t = q.taxRate;
  return `
    <div class="inv-wrap">
      ${invoiceHead('عرض سعر', q.no, q.date)}
      <div class="inv-info">
        <div><span>رقم العرض</span><b>${esc(q.no)}</b></div>
        <div><span>التاريخ</span><b>${esc(q.date)}</b></div>
        <div><span>العميل</span><b>${esc(q.customer || 'عميل نقدي')}</b></div>
        <div><span>الحالة</span><b>${esc(q.status || 'ساري')}</b></div>
      </div>
      <table class="inv-table">
        <thead><tr><th>#</th><th>الصنف</th><th>الكمية</th><th>سعر الوحدة</th><th>الإجمالي</th></tr></thead>
        <tbody>${invTableRows(q.lines)}</tbody>
      </table>
      <div class="inv-totals">
        <div><span>الإجمالي الفرعي</span><b>${cur(q.sub)}</b></div>
        <div><span>ضريبة القيمة المضافة (${t}%)</span><b>${cur(q.tax)}</b></div>
        <div class="inv-grand"><span>الإجمالي</span><b>${cur(q.total)}</b></div>
      </div>
      <div class="inv-reg">
        <span>سجل تجاري: ${esc(SETTINGS.cr || '—')}</span>
        <span>الرقم الضريبي: ${esc(SETTINGS.taxno || '—')}</span>
      </div>
      <div class="inv-foot"><p>هذا العرض ساري لمدة 14 يوماً — نرحب باستفساراتكم</p><small>${esc(SETTINGS.company || '')} · ${esc(q.no)} · ${esc(q.date)}</small></div>
    </div>`;
}

/* ---------- Sales orders ---------- */
function renderOrderLines() {
  const box = $('#o-lines-list');
  if (!box) return;
  const empty = $('#o-lines-empty');
  if (empty) empty.style.display = ORDER_LINES.length ? 'none' : '';
  box.innerHTML = ORDER_LINES.map(l => `
    <div class="part-row">
      <span class="part-name">${esc(l.name)}</span>
      <span class="part-qty">× ${l.qty}</span>
      <span class="part-price">${cur((Number(l.price) || 0) * l.qty)}</span>
      <button class="icon-btn xs danger" data-action="remove-order-line" data-line="${esc(l.name)}" title="إزالة"><i class="fa-solid fa-xmark"></i></button>
    </div>`).join('');
  const totalEl = $('#o-lines-total');
  if (totalEl) totalEl.textContent = cur(ORDER_LINES.reduce((s, l) => s + (Number(l.price) || 0) * l.qty, 0));
}

function openOrderModal() {
  ORDER_LINES = [];
  const opts = PRODUCTS.map(p => `<option value="${esc(p.name)}">${esc(p.name)} — ${cur(p.sell)}</option>`).join('');
  openModal(`
    <div class="modal-head"><h3><i class="fa-solid fa-clipboard-list"></i> طلب بيع جديد</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="field"><label>العميل</label><i class="fa-solid fa-user"></i><select id="o-customer"><option value="عميل نقدي">عميل نقدي</option>${customersOptions()}</select></div>
      <div class="parts-add">
        <div class="field grow"><label>المنتج</label><i class="fa-solid fa-box"></i><select id="o-product">${opts || '<option value="">لا توجد منتجات</option>'}</select></div>
        <div class="field"><label>الكمية</label><i class="fa-solid fa-hashtag"></i><input type="number" id="o-qty" value="1" min="1"></div>
        <div class="field"><label>السعر</label><i class="fa-solid fa-tag"></i><input type="number" id="o-price" min="0" value="0"></div>
        <button class="btn btn-accent" data-action="add-order-line"><i class="fa-solid fa-plus"></i> إضافة</button>
      </div>
      <div class="parts-list" id="o-lines-list"></div>
      <div class="parts-empty" id="o-lines-empty">أضف أصنافاً للطلب</div>
      <div class="cs-totals" style="margin-top:12px">
        <div><span>إجمالي الطلب</span><b id="o-lines-total">${cur(0)}</b></div>
        <div><span>المدفوع الآن</span><input type="number" id="o-paid" value="0" min="0" style="width:120px"></div>
      </div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-order"><i class="fa-solid fa-floppy-disk"></i> حفظ الطلب</button></div>
  `);
  const sel = $('#o-product');
  if (sel) sel.addEventListener('change', () => {
    const p = PRODUCTS.find(x => x.name === sel.value);
    const pe = $('#o-price'); if (p && pe) pe.value = Number(p.sell) || 0;
  });
  renderOrderLines();
}

function orderStatus(o) {
  const paid = Number(o.paid) || 0;
  const total = Number(o.total) || 0;
  if (o.status === 'ملغي') return { label: 'ملغي', cls: 'red' };
  if (o.status === 'مكتمل') return { label: 'مكتمل', cls: 'green' };
  if (paid >= total && total > 0) return { label: 'مدفوع', cls: 'green' };
  if (paid > 0) return { label: 'آجل', cls: 'orange' };
  return { label: 'مفتوح', cls: 'blue' };
}

function renderOrders() {
  const tbody = $('#orders-table');
  if (!tbody) return;
  if (!ORDERS.length) { tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#94A3B8;padding:22px">لا توجد طلبات بيع بعد</td></tr>'; return; }
  tbody.innerHTML = ORDERS.map(o => {
    const st = orderStatus(o);
    return `<tr>
      <td><b>${esc(o.no)}</b><small class="bc-num">${esc(o.date)}</small></td>
      <td>${esc(o.customer || 'عميل نقدي')}</td>
      <td>${o.lines.reduce((a, l) => a + l.qty, 0)}</td>
      <td>${cur(o.total)}</td>
      <td>${cur(o.paid || 0)}</td>
      <td><span class="chip chip-${st.cls}">${st.label}</span></td>
      <td>${esc(o.date)}</td>
      <td><div class="row-actions">
        <button class="icon-btn xs" data-action="order-to-sale" data-order="${esc(o.no)}" title="تحويل لفاتورة"><i class="fa-solid fa-cart-shopping"></i></button>
        <button class="icon-btn xs" data-action="order-pay" data-order="${esc(o.no)}" title="تسجيل دفعة"><i class="fa-solid fa-hand-holding-dollar"></i></button>
        <button class="icon-btn xs danger" data-action="order-cancel" data-order="${esc(o.no)}" title="إلغاء الطلب"><i class="fa-solid fa-ban"></i></button>
      </div></td>
    </tr>`;
  }).join('');
}

/* ---------- POS returns ---------- */
function renderPosReturns() {
  const tbody = $('#pos-returns-table');
  if (!tbody) return;
  if (!RETURNS.length) { tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#94A3B8;padding:22px">لا توجد فواتير مرتجع بعد</td></tr>'; return; }
  tbody.innerHTML = RETURNS.map(r => {
    const ref = r.saleNo || r.ref || '—';
    const prod = r.items ? r.items.map(i => i.name).join('، ') : (r.product || '—');
    const qty = r.items ? r.items.reduce((a, i) => a + i.qty, 0) : (r.qty || 0);
    const amt = r.total != null ? r.total : (r.amount || 0);
    const type = r.type || 'جزئي';
    return `<tr>
      <td><b>${esc(r.no || '—')}</b><small class="bc-num">${esc(r.date || '')}</small></td>
      <td>${esc(prod)}</td>
      <td>${qty}</td>
      <td>${esc(ref)}</td>
      <td><span class="chip chip-${type === 'كامل' ? 'orange' : 'blue'}">${esc(type)}</span></td>
      <td>${cur(amt)}</td>
      <td><span class="chip chip-green">${esc(r.status || 'مرتجع')}</span></td>
      <td><div class="row-actions">
        <button class="icon-btn xs" data-action="view-return" data-return="${esc(r.no || '')}" title="عرض"><i class="fa-solid fa-eye"></i></button>
        <button class="icon-btn xs" data-action="print-return-pos" data-return="${esc(r.no || '')}" title="طباعة"><i class="fa-solid fa-print"></i></button>
        <button class="icon-btn xs danger" data-action="delete-return" data-return="${esc(r.no || '')}" title="حذف"><i class="fa-solid fa-trash"></i></button>
      </div></td>
    </tr>`;
  }).join('');
}

function openPosReturnModal() {
  const salesOpts = SALES.map(s => `<option value="${esc(s.no)}">${esc(s.no)} — ${esc(s.customer || 'عميل نقدي')} — ${cur(s.total)}</option>`).join('');
  const prodOpts = PRODUCTS.map(p => `<option value="${esc(p.name)}">${esc(p.name)} — ${cur(p.sell)}</option>`).join('');
  openModal(`
    <div class="modal-head"><h3><i class="fa-solid fa-rotate-left"></i> فاتورة مرتجع</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="field"><label>الفاتورة الأصلية</label><i class="fa-solid fa-file-invoice"></i><select id="pr-sale">${salesOpts || '<option value="">لا توجد فواتير</option>'}</select></div>
      <div class="parts-add">
        <div class="field grow"><label>المنتج</label><i class="fa-solid fa-box"></i><select id="pr-product">${prodOpts || '<option value="">لا توجد منتجات</option>'}</select></div>
        <div class="field"><label>الكمية</label><i class="fa-solid fa-hashtag"></i><input type="number" id="pr-qty" value="1" min="1"></div>
        <div class="field"><label>السعر</label><i class="fa-solid fa-tag"></i><input type="number" id="pr-price" min="0" value="0"></div>
        <button class="btn btn-accent" data-action="add-pos-return-line"><i class="fa-solid fa-plus"></i> إضافة</button>
      </div>
      <div class="parts-list" id="pr-lines-list"></div>
      <div class="parts-empty" id="pr-lines-empty">اختر أصنافاً لإرجاعها</div>
      <div class="cs-totals" style="margin-top:12px">
        <div><span>إجمالي المرتجع</span><b id="pr-lines-total">${cur(0)}</b></div>
        <div><span>نوع المرتجع</span><select id="pr-type" style="width:150px"><option value="جزئي">جزئي</option><option value="كامل">كامل</option></select></div>
      </div>
      <div class="field" style="margin-top:12px"><label>سبب الإرجاع</label><i class="fa-solid fa-clipboard"></i><textarea id="pr-reason" rows="2" placeholder="سبب الإرجاع..."></textarea></div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-pos-return"><i class="fa-solid fa-floppy-disk"></i> حفظ المرتجع</button></div>
  `);
  const sel = $('#pr-product');
  if (sel) sel.addEventListener('change', () => {
    const p = PRODUCTS.find(x => x.name === sel.value);
    const pe = $('#pr-price'); if (p && pe) pe.value = Number(p.sell) || 0;
  });
  renderPosReturnLines();
}

function renderPosReturnLines() {
  const box = $('#pr-lines-list');
  if (!box) return;
  const empty = $('#pr-lines-empty');
  if (empty) empty.style.display = POS_RETURN_LINES.length ? 'none' : '';
  box.innerHTML = POS_RETURN_LINES.map(l => `
    <div class="part-row">
      <span class="part-name">${esc(l.name)}</span>
      <span class="part-qty">× ${l.qty}</span>
      <span class="part-price">${cur((Number(l.price) || 0) * l.qty)}</span>
      <button class="icon-btn xs danger" data-action="remove-pos-return-line" data-line="${esc(l.name)}" title="إزالة"><i class="fa-solid fa-xmark"></i></button>
    </div>`).join('');
  const totalEl = $('#pr-lines-total');
  if (totalEl) totalEl.textContent = cur(POS_RETURN_LINES.reduce((s, l) => s + (Number(l.price) || 0) * l.qty, 0));
}

function buildReturnHTML(r) {
  const lines = r.items || [{ name: r.product || '—', qty: r.qty || 0, price: (r.amount || 0) / (r.qty || 1) }];
  return `
    <div class="inv-wrap">
      ${invoiceHead('فاتورة مرتجع', r.no, r.date)}
      <div class="inv-info">
        <div><span>رقم المرتجع</span><b>${esc(r.no)}</b></div>
        <div><span>المرجع</span><b>${esc(r.saleNo || r.ref || '—')}</b></div>
        <div><span>النوع</span><b>${esc(r.type || 'جزئي')}</b></div>
        <div><span>الحالة</span><b>${esc(r.status || 'مرتجع')}</b></div>
      </div>
      <table class="inv-table">
        <thead><tr><th>#</th><th>الصنف</th><th>الكمية</th><th>سعر الوحدة</th><th>الإجمالي</th></tr></thead>
        <tbody>${invTableRows(lines)}</tbody>
      </table>
      <div class="inv-totals">
        <div><span>إجمالي المرتجع</span><b>${cur(r.total || r.amount || 0)}</b></div>
        <div class="inv-grand"><span>المسترد للعميل</span><b>${cur(r.total || r.amount || 0)}</b></div>
      </div>
      ${r.reason ? `<div class="inv-reg"><span>سبب الإرجاع: ${esc(r.reason)}</span></div>` : ''}
      <div class="inv-foot"><p>شكراً لتعاملكم معنا — تم إرجاع الأصناف للمخزون</p><small>${esc(SETTINGS.company || '')} · ${esc(r.no)} · ${r.date}</small></div>
    </div>`;
}

function buildWaNumber() {
  const digits = (SETTINGS.mobile || '').replace(/\D/g, '');
  if (/^2\d{9,}$/.test(digits)) return digits;
  return '20' + digits.replace(/^0+/, '');
}

function sendInvoice(medium, sale) {
  const line = s => s.items.map(i => `- ${i.name} × ${i.qty} = ${cur((Number(i.price) || 0) * i.qty)}`).join('\n');
  const payL = paymentsText(sale.payments);
  const msg = `${SETTINGS.company || 'Senior Pro'}\nفاتورة ${sale.no} — ${sale.date}\nالعميل: ${sale.customer || 'عميل نقدي'}\n${line(sale)}\nالإجمالي الفرعي: ${cur(sale.sub)}\n${sale.disc ? 'الخصم: −' + cur(sale.disc) + '\n' : ''}${sale.taxEnabled === false ? 'الضريبة: بدون\n' : 'الضريبة (' + sale.taxRate + '%): ' + cur(sale.tax) + '\n'}الإجمالي: ${cur(sale.total)}\nالدفع: ${payL}\nشكراً لتعاملكم معنا`;
  if (medium === 'whatsapp') {
    const url = `https://wa.me/${buildWaNumber()}?text=${encodeURIComponent(msg)}`;
    window.open(url, '_blank');
  } else {
    const subject = encodeURIComponent(`فاتورة ${sale.no} — ${SETTINGS.company || ''}`);
    const body = encodeURIComponent(msg);
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  }
  toast(`تم تجهيز إرسال الفاتورة عبر ${medium === 'whatsapp' ? 'واتساب' : 'البريد الإلكتروني'}`);
}

function buildInvoiceImage(sale) {
  return new Promise((resolve, reject) => {
    try {
      const W = 720, pad = 34;
      const f = '"Segoe UI", Arial, sans-serif';
      const itemH = 52, headH = 168, metaH = 92, thH = 46;
      const totalsN = 1 + (sale.disc ? 1 : 0) + (sale.taxEnabled === false ? 1 : 1) + 1 + 1;
      const H = headH + metaH + thH + sale.items.length * itemH + totalsN * 34 + 150;
      const canvas = document.createElement('canvas');
      canvas.width = W; canvas.height = H;
      const ctx = canvas.getContext('2d');
      ctx.direction = 'rtl';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, W, H);
      let y = pad;

      ctx.fillStyle = '#0B2D5B';
      ctx.fillRect(0, 0, W, headH);
      ctx.textAlign = 'center';
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 36px ' + f;
      ctx.fillText(SETTINGS.company || 'Senior Pro', W / 2, 62);
      ctx.font = '22px ' + f;
      ctx.fillText('فاتورة بيع — ' + sale.no, W / 2, 104);
      ctx.fillStyle = '#ffd1a8';
      ctx.font = '18px ' + f;
      ctx.fillText((sale.date || '') + (sale.time ? '  —  ' + sale.time : ''), W / 2, 138);
      y = headH;

      ctx.textAlign = 'right';
      ctx.font = '600 21px ' + f;
      ctx.fillStyle = '#1e293b';
      ctx.fillText('العميل: ' + (sale.customer || 'عميل نقدي'), W - pad, y + 24);
      ctx.textAlign = 'left';
      ctx.fillText('الهاتف: ' + (SETTINGS.mobile || ''), pad, y + 24);
      ctx.textAlign = 'right';
      ctx.font = '17px ' + f;
      ctx.fillStyle = '#64748b';
      ctx.fillText(SETTINGS.address || '', W - pad, y + 60);
      y += metaH;

      ctx.fillStyle = '#f1f5f9';
      ctx.fillRect(pad, y, W - pad * 2, thH);
      ctx.fillStyle = '#0B2D5B';
      ctx.font = '700 19px ' + f;
      ctx.textAlign = 'right'; ctx.fillText('الصنف', W - pad, y + thH / 2);
      ctx.textAlign = 'center'; ctx.fillText('الكمية', W * 0.58, y + thH / 2);
      ctx.textAlign = 'center'; ctx.fillText('السعر', W * 0.40, y + thH / 2);
      ctx.textAlign = 'left'; ctx.fillText('الإجمالي', pad, y + thH / 2);
      y += thH;

      sale.items.forEach(it => {
        ctx.font = '19px ' + f;
        ctx.fillStyle = '#334155';
        ctx.textAlign = 'right'; ctx.fillText(it.name, W - pad, y + itemH / 2);
        ctx.textAlign = 'center'; ctx.fillText(String(it.qty), W * 0.58, y + itemH / 2);
        ctx.textAlign = 'center'; ctx.fillText(cur(it.price), W * 0.40, y + itemH / 2);
        ctx.textAlign = 'left'; ctx.fillStyle = '#0B2D5B'; ctx.font = '700 19px ' + f;
        ctx.fillText(cur((Number(it.price) || 0) * it.qty), pad, y + itemH / 2);
        y += itemH;
      });

      y += 8;
      const tr = [
        ['الإجمالي الفرعي', cur(sale.sub)],
        ...(sale.disc ? [['الخصم', '− ' + cur(sale.disc)]] : []),
        ...(sale.taxEnabled === false ? [['الضريبة', 'بدون']] : [['الضريبة (' + sale.taxRate + '%)', cur(sale.tax)]]),
        ['الإجمالي', cur(sale.total)],
        ['الدفع', Array.isArray(sale.payments) ? sale.payments.map(p => p.method + ': ' + cur(p.amount)).join('  ') : (sale.pay || 'نقداً')]
      ];
      tr.forEach(r => {
        ctx.textAlign = 'right';
        ctx.fillStyle = '#64748b';
        ctx.font = '18px ' + f;
        ctx.fillText(r[0], W - pad, y + 13);
        ctx.textAlign = 'left';
        ctx.fillStyle = r[0] === 'الإجمالي' ? '#0B2D5B' : '#1e293b';
        ctx.font = (r[0] === 'الإجمالي' ? '800 21px ' : '700 18px ') + f;
        ctx.fillText(r[1], pad, y + 13);
        y += 30;
      });

      y += 26;
      ctx.textAlign = 'center';
      ctx.fillStyle = '#64748b';
      ctx.font = '17px ' + f;
      ctx.fillText('شكراً لتعاملكم معنا', W / 2, y);
      y += 28;
      ctx.fillStyle = '#94a3b8';
      ctx.font = '14px ' + f;
      ctx.fillText((SETTINGS.company || '') + '  ·  ' + sale.no + '  ·  ' + (SETTINGS.mobile || ''), W / 2, y);

      canvas.toBlob(b => b ? resolve(b) : reject(new Error('canvas')), 'image/png');
    } catch (e) { reject(e); }
  });
}

function sendInvoiceImage(sale) {
  buildInvoiceImage(sale).then(blob => {
    const fileName = 'فاتورة_' + (sale.no || '').replace(/[^\w-]/g, '') + '.png';
    const file = new File([blob], fileName, { type: 'image/png' });
    if (navigator.canShare && navigator.canShare({ files: [file] })) {
      navigator.share({ files: [file], title: 'فاتورة ' + sale.no, text: 'فاتورة ' + sale.no + ' — ' + cur(sale.total) });
    } else {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = fileName;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 4000);
      window.open('https://wa.me/' + buildWaNumber() + '?text=' + encodeURIComponent('فاتورة ' + sale.no + ' — ' + cur(sale.total)), '_blank');
      toast('تم تنزيل صورة الفاتورة — أرفقها في محادثة واتساب', 'info');
    }
  }).catch(() => toast('تعذر توليد صورة الفاتورة', 'error'));
}

function renderCart() {
  const wrap = $('#cart-items');
  const empty = $('#cart-empty');
  const count = $('#cart-count');
  const btn = $('#checkout-btn');
  if (!wrap) return;
  if (empty) empty.style.display = POS_CART.length ? 'none' : '';
  wrap.innerHTML = POS_CART.map(c => `
    <div class="pc-item">
      <div class="pc-info"><b>${esc(c.name)}</b><span>${cur(c.price)} أ— ${c.qty}</span></div>
      <div class="pc-qty">
        <button class="qty-btn" data-action="pos-qty" data-pos="${esc(c.name)}" data-d="-1"><i class="fa-solid fa-minus"></i></button>
        <span>${c.qty}</span>
        <button class="qty-btn" data-action="pos-qty" data-pos="${esc(c.name)}" data-d="1"><i class="fa-solid fa-plus"></i></button>
      </div>
      <b class="pc-total">${cur((Number(c.price) || 0) * c.qty)}</b>
      <button class="pc-del" data-action="pos-remove" data-pos="${esc(c.name)}"><i class="fa-solid fa-xmark"></i></button>
    </div>`).join('');
  const t = posTotals();
  if (count) count.textContent = POS_CART.length ? `${POS_CART.length} ${POS_CART.length === 1 ? 'صنف' : 'أصناف'}` : 'السلة فارغة';
  const rateEl = $('#ps-tax-rate'); if (rateEl) rateEl.textContent = t.taxRate;
  const set = (id, txt) => { const el = document.getElementById(id); if (el) el.textContent = txt; };
  set('ps-subtotal', cur(t.sub));
  set('ps-tax', cur(t.tax));
  set('ps-total', cur(t.total));
  if (btn) btn.innerHTML = `<i class="fa-solid fa-check-circle"></i> إتمام البيع — ${cur(t.total)}`;
  const minWarn = $('#pos-min-warn');
  if (minWarn) {
    const bad = POS_CART.length ? belowMinSaleLine() : null;
    minWarn.classList.toggle('show', !!bad);
    const txt = minWarn.querySelector('span');
    if (txt) txt.textContent = bad ? `سعر «${bad.name}» بعد الخصم ${cur(bad.unit)} أقل من الحد الأدنى ${cur(bad.min)}` : '';
  }
  const discEl = $('#pos-discount');
  if (discEl && (parseFloat(discEl.value) || 0) > t.sub) discEl.value = t.sub || 0;
  const dtEl = $('#pos-discount-type');
  if (dtEl && dtEl.value === 'percent') {
    const dv = parseFloat($('#pos-discount')?.value) || 0;
    if (dv > 100) $('#pos-discount').value = 100;
  }
  updatePayUI();
}

function buildSale() {
  const t = posTotals();
  const payments = getPosPayments(t.total);
  const last = Math.max(0, ...SALES.map(s => parseInt((s.no || '').replace(/\D/g, '') || '0', 10)));
  const no = (SETTINGS.invPrefix || 'INV-') + (last + 1);
  const customer = ($('#pos-customer')?.value || '').trim() || 'عميل نقدي';
  const pay = payments.length > 1 ? 'مختلط' : (payments.length ? payments[0].method : 'نقداً');
  return {
    no,
    date: new Date().toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' }),
    time: new Date().toLocaleTimeString('ar-SA-u-ca-gregory', { hour: 'numeric', minute: '2-digit' }),
    items: POS_CART.map(c => {
      const p = PRODUCTS.find(x => x.name === c.name);
      return { name: c.name, price: c.price, qty: c.qty, cost: p ? (Number(p.buy) || 0) : 0 };
    }),
    sub: t.sub, disc: t.disc, tax: t.tax, taxRate: t.taxRate, total: t.total,
    discType: t.discType, taxEnabled: t.taxEnabled, payments, pay, cashier: SESSION ? (SESSION.name || 'مدير النظام') : 'مدير النظام',
    customer
  };
}

function commitSale(sale) {
  // Re-validate stock at commit time — stock may have changed since items were added to cart
  for (const c of POS_CART) {
    const p = PRODUCTS.find(x => x.name === c.name);
    const need = Number(c.qty) || 0;
    const have = p ? (Number(p.qty) || 0) : 0;
    if (!p || need <= 0 || need > have) {
      toast(`المخزون غير كافٍ للصنف «${c.name}» (المتاح: ${have})`, 'error');
      return;
    }
  }
  SALES.unshift(sale);
  DB.set('sales', SALES);
  POS_CART.forEach(c => {
    const p = PRODUCTS.find(x => x.name === c.name);
    if (p) p.qty = Math.max(0, (Number(p.qty) || 0) - (Number(c.qty) || 0));
  });
  DB.set('products', PRODUCTS);
  renderProducts(); renderPOS();
  // تحديث مديونية العميل: خصم فائض الدفع من المديونية + إضافة المتبقي الآجل
  let debtMsg = '';
  const cust = posCustomerObj();
  if (cust) {
    const cashPaid = (Array.isArray(sale.payments) ? sale.payments : [])
      .filter(p => p.method !== 'آجل').reduce((s, p) => s + (Number(p.amount) || 0), 0);
    const total = Number(sale.total) || 0;
    const over = Math.max(0, cashPaid - total);      // دفع العميل أكثر من قيمة الفاتورة
    const credit = Math.max(0, total - cashPaid);    // باقي الفاتورة آجل
    const before = Number(cust.debt) || 0;
    let debt = before;
    if (over > 0 && $('#pos-deduct-debt')?.checked) {
      debt = Math.max(0, debt - over);
      debtMsg = before > 0 ? ` — خُصم ${cur(Math.min(before, over))} من مديونية العميل (المتبقي عليه ${cur(debt)})` : ` — فائض للعميل ${cur(over)}`;
    }
    if (credit > 0) {
      debt += credit;
      debtMsg += ` — أُضيف المتبقي ${cur(credit)} إلى مديونية العميل (الإجمالي ${cur(debt)})`;
    }
    cust.debt = Math.max(0, debt);
    // حفظ بيانات حركة المديونية على الفاتورة لتظهر في سجل العميل
    sale.debtDeducted = over > 0 && $('#pos-deduct-debt')?.checked ? Math.min(before, over) : 0;
    sale.creditAdded = credit;
    DB.set('customers', CUSTOMERS);
    DB.set('sales', SALES);
    updateCustomerDebtUI();
    renderCustomers();
  }
  renderFinancialStats(); renderDashboardStats();
  POS_CART = [];
  const discEl = $('#pos-discount'); if (discEl) discEl.value = 0;
  $$('.pay-method').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.pay-amt').forEach(inp => { inp.value = ''; inp.disabled = true; });
  const ded = $('#pos-deduct-debt'); if (ded) ded.checked = true;
  // إعادة تعيين العميل إلى «عميل نقدي» بعد حفظ الفاتورة
  const custSel = $('#pos-customer'); if (custSel) custSel.value = 'عميل نقدي';
  updateCustomerDebtUI();
  renderCart();
  receiptModal(sale);
  toast(`تم حفظ الفاتورة ${sale.no} بنجاح` + debtMsg);
}

function posCheckout() {
  if (!POS_CART.length) { toast('السلة فارغة — أضف منتجات أولاً', 'error'); return; }
  // Stock check covers direct sales and quote/order-to-sale transfers that bypass posAdd
  for (const c of POS_CART) {
    const p = PRODUCTS.find(x => x.name === c.name);
    const need = Number(c.qty) || 0;
    const have = p ? (Number(p.qty) || 0) : 0;
    if (!p || need <= 0 || need > have) {
      toast(`المخزون غير كافٍ للصنف «${c.name}» (المتاح: ${have})`, 'error');
      return;
    }
  }
  if (!checkMinSalePrices()) return;
  const sale = buildSale();
  const itemsHtml = sale.items.map(c => `<tr><td>${esc(c.name)}</td><td>${c.qty}</td><td>${cur(c.price)}</td><td>${cur((Number(c.price) || 0) * c.qty)}</td></tr>`).join('');
  // معلومات المديونية في نافذة التأكيد
  const cust = posCustomerObj();
  const cashPaid = (Array.isArray(sale.payments) ? sale.payments : [])
    .filter(p => p.method !== 'آجل').reduce((s, p) => s + (Number(p.amount) || 0), 0);
  const over = Math.max(0, cashPaid - (Number(sale.total) || 0));
  const credit = Math.max(0, (Number(sale.total) || 0) - cashPaid);
  const debtRows = cust ? `
    <div><span>مديونية العميل حالياً</span><b class="text-red">${cur(Number(cust.debt) || 0)}</b></div>
    ${over > 0 ? `<div><span>فائض الدفع</span><b class="text-green">${cur(over)}</b></div>
      <div><span>${$('#pos-deduct-debt')?.checked ? 'سيُخصم الفائض من مديونية العميل' : 'الفائض (بدون خصم من المديونية)'}</span><b>${$('#pos-deduct-debt')?.checked ? cur(Math.max(0, (Number(cust.debt) || 0) - over)) : '—'}</b></div>` : ''}
    ${credit > 0 ? `<div><span>سيُضاف المتبقي (آجل) إلى المديونية</span><b class="text-red">+ ${cur(credit)}</b></div>` : ''}` : '';
  openModal(`
    <div class="modal-head"><h3><i class="fa-solid fa-cart-shopping"></i> تأكيد البيع</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="confirm-sale">
        <div class="cs-meta"><span><i class="fa-solid fa-user"></i> ${esc(sale.customer)}</span><span><i class="fa-solid fa-wallet"></i> ${esc(sale.pay)}</span></div>
        <div class="table-wrap"><table class="table">
          <thead><tr><th>الصنف</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead>
          <tbody>${itemsHtml}</tbody>
        </table></div>
        <div class="cs-totals">
          <div><span>الإجمالي الفرعي</span><b>${cur(sale.sub)}</b></div>
          ${sale.disc ? `<div><span>الخصم</span><b class="text-green">− ${cur(sale.disc)}</b></div>` : ''}
          ${taxRow(sale)}
          ${paymentsRows(sale.payments)}
          <div class="cs-total"><span>الإجمالي</span><b>${cur(sale.total)}</b></div>
          ${debtRows}
        </div>
      </div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="confirm-checkout"><i class="fa-solid fa-floppy-disk"></i> حفظ الفاتورة — ${cur(sale.total)}</button></div>
  `);
}

function receiptModal(sale) {
  CURRENT_RECEIPT = sale;
  const items = sale.items.map(i => `<tr><td>${esc(i.name)}</td><td>${i.qty}</td><td>${cur(i.price)}</td><td>${cur((Number(i.price) || 0) * i.qty)}</td></tr>`).join('');
  openModal(`
    <div class="modal-head"><h3><i class="fa-solid fa-receipt"></i> الفاتورة ${esc(sale.no)}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="receipt">
        <div class="r-head"><h2>${esc(SETTINGS.company || '')}</h2><p>${esc(sale.no)}</p><small>${sale.date} — ${sale.time || ''}</small></div>
        <div class="r-meta-lines">
          <span><i class="fa-solid fa-location-dot"></i> ${esc(SETTINGS.address || '')}</span>
          <span><i class="fa-solid fa-mobile-screen"></i> ${esc(SETTINGS.mobile || '')}</span>
        </div>
        <table class="receipt-table"><thead><tr><th>الصنف</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead><tbody>${items}</tbody></table>
        <div class="r-summary">
          <div><span>العميل</span><b>${esc(sale.customer || 'عميل نقدي')}</b></div>
          <div><span>الإجمالي الفرعي</span><b>${cur(sale.sub)}</b></div>
          ${sale.disc ? `<div><span>الخصم</span><b class="text-green">− ${cur(sale.disc)}</b></div>` : ''}
          ${taxRow(sale)}
          <div class="r-total"><span>الإجمالي</span><b>${cur(sale.total)}</b></div>
          ${salePayRows(sale)}
          <div><span>الكاشير</span><b>${esc(sale.cashier || '')}</b></div>
        </div>
        ${SETTINGS.taxno ? `<p class="r-reg">الرقم الضريبي: ${esc(SETTINGS.taxno)}</p>` : ''}
        <p class="r-thanks">شكراً لتعاملكم معنا</p>
      </div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إغلاق</button><button class="btn btn-green" data-action="send-whatsapp" data-sale="${esc(sale.no)}"><i class="fa-brands fa-whatsapp"></i> واتساب</button><button class="btn btn-navy" data-action="send-email" data-sale="${esc(sale.no)}"><i class="fa-solid fa-envelope"></i> بريد</button><button class="btn btn-navy" data-action="save-receipt"><i class="fa-solid fa-floppy-disk"></i> حفظ الفاتورة</button><button class="btn btn-accent" data-action="print-receipt-pos"><i class="fa-solid fa-print"></i> طباعة الفاتورة</button></div>
  `);
}

function buildInvoiceHTML(sale) {
  const rows = sale.items.map((i, idx) => `
    <tr>
      <td>${idx + 1}</td>
      <td class="inv-name">${esc(i.name)}</td>
      <td>${i.qty}</td>
      <td>${cur(i.price)}</td>
      <td>${cur((Number(i.price) || 0) * i.qty)}</td>
    </tr>`).join('');
  return `
    <div class="inv-wrap">
      <div class="inv-head">
        <div class="inv-logo">${safeLogo(SETTINGS.logo) ? `<img src="${safeLogo(SETTINGS.logo)}" alt="logo" style="width:100%;height:100%;object-fit:contain;border-radius:inherit;background:#fff">` : 'ظˆ'}</div>
        <div class="inv-brand">
          <h1>${esc(SETTINGS.company || '')}</h1>
          <p>نظام إدارة مراكز الصيانة — Senior Pro</p>
          <div class="inv-brand-meta">
            <span><i class="fa-solid fa-location-dot"></i> ${esc(SETTINGS.address || '')}</span>
            <span><i class="fa-solid fa-mobile-screen"></i> ${esc(SETTINGS.mobile || '')} ${SETTINGS.phone ? 'آ· ' + esc(SETTINGS.phone) : ''}</span>
          </div>
        </div>
        <div class="inv-title">
          <h2>فاتورة بيع</h2>
          <b>${esc(sale.no)}</b>
          <small>${sale.date} — ${sale.time || ''}</small>
        </div>
      </div>
      <div class="inv-info">
        <div><span>رقم الفاتورة</span><b>${esc(sale.no)}</b></div>
        <div><span>التاريخ</span><b>${sale.date} — ${sale.time || ''}</b></div>
        <div><span>العميل</span><b>${esc(sale.customer || 'عميل نقدي')}</b></div>
        ${salePayRows(sale)}
        <div><span>الكاشير</span><b>${esc(sale.cashier || '')}</b></div>
      </div>
      <table class="inv-table">
        <thead><tr><th>#</th><th>الصنف</th><th>الكمية</th><th>سعر الوحدة</th><th>الإجمالي</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="inv-totals">
        <div><span>الإجمالي الفرعي</span><b>${cur(sale.sub)}</b></div>
        ${sale.disc ? `<div><span>الخصم</span><b>− ${cur(sale.disc)}</b></div>` : ''}
        ${taxRow(sale, 'ضريبة القيمة المضافة')}
        <div class="inv-grand"><span>الإجمالي المستحق</span><b>${cur(sale.total)}</b></div>
      </div>
      <div class="inv-reg">
        <span>سجل تجاري: ${esc(SETTINGS.cr || '—')}</span>
        <span>الرقم الضريبي: ${esc(SETTINGS.taxno || '—')}</span>
      </div>
      ${socialLinksHTML()}
      <div class="inv-foot">
        <p>شكراً لتعاملكم معنا — نتشرف بخدمتكم دائماً</p>
        <small>${esc(SETTINGS.company || '')} آ· ${esc(sale.no)} آ· ${sale.date}</small>
      </div>
    </div>`;
}

function buildRepairReceiptHTML(rep) {
  rep = rep || CURRENT_RECEIPT_REPAIR || null;
  const name = rep ? rep.customer : (($('#f-customer-name')?.value || '').trim() || 'عميل غير محدد');
  const phone = rep ? (CUSTOMERS.find(c => c.name === rep.customer)?.phone || '—') : (($('#f-customer-phone')?.value || '').trim() || '—');
  const dtype = rep ? '' : (($('#f-device-type')?.value || '').trim());
  const device = rep ? rep.device : ([dtype, ($('#f-device-brand')?.value || '').trim(), ($('#f-device-model')?.value || '').trim()].filter(Boolean).join(' ') || 'جهاز غير محدد');
  const imei = (($('#f-imei')?.value || '').trim() || '—');
  const issue = (($('#f-main-problem')?.value || '').trim() || 'بدون وصف');
  const num = rep ? parseInt((rep.id || '').replace(/\D/g, '') || 2000, 10) : (Math.max(2000, ...REPAIRS.map(r => parseInt((r.id || '').replace(/\D/g, '') || 0, 10))) + 1);
  const id = rep ? rep.id : (SETTINGS.repPrefix + num);
  const barcode = rep ? rep.barcode : ('628000000' + String(num).padStart(4, '0'));
  const qrText = 'https://warsha.pro/' + id;
  const date = rep ? rep.date : new Date().toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' });
  const time = new Date().toLocaleTimeString('ar-SA-u-ca-gregory', { hour: 'numeric', minute: '2-digit' });
  const parts = rep ? (Array.isArray(rep.parts) ? rep.parts : []) : REPAIR_PARTS;
  const partsTotal = parts.reduce((s, p) => s + (Number(p.price) || 0) * (Number(p.qty) || 0), 0);
  const total = rep ? (Number(rep.amount) || 0) : LAST_TOTAL;
  const paid = rep ? (Number(rep.paid) || 0) : (Math.min(parseFloat($('#paid-amount')?.value) || 0, total));
  const left = Math.max(total - paid, 0);
  const partsRows = parts.length ? parts.map((p, idx) => `
    <tr>
      <td>${idx + 1}</td>
      <td class="inv-name">${esc(p.name)}</td>
      <td>${p.qty}</td>
      <td>${cur(p.price)}</td>
      <td>${cur((Number(p.price) || 0) * (Number(p.qty) || 0))}</td>
    </tr>`).join('') : '';
  CURRENT_RECEIPT_REPAIR = null;
  return `
    <div class="inv-wrap">
      <div class="inv-head inv-head-rep">
        <div class="inv-logo">${safeLogo(SETTINGS.logo) ? `<img src="${safeLogo(SETTINGS.logo)}" alt="logo" style="width:100%;height:100%;object-fit:contain;border-radius:inherit;background:#fff">` : 'و'}</div>
        <div class="inv-brand">
          <h1>${esc(SETTINGS.company || '')}</h1>
          <div class="inv-brand-meta">
            <span><i class="fa-solid fa-location-dot"></i> ${esc(SETTINGS.address || '')}</span>
            <span><i class="fa-solid fa-mobile-screen"></i> ${esc(SETTINGS.mobile || '')} ${SETTINGS.phone ? '· ' + esc(SETTINGS.phone) : ''}</span>
          </div>
          <div class="inv-reg-hdr">
            <span>سجل تجاري: ${esc(SETTINGS.cr || '—')}</span>
            <span>الرقم الضريبي: ${esc(SETTINGS.taxno || '—')}</span>
          </div>
        </div>
        <div class="inv-title">
          <h2>إيصال استلام جهاز</h2>
          <b>${esc(id)}</b>
          <small>${date}</small>
        </div>
        <div class="inv-hdr-bc">
          <div class="barcode-lg inv-barcode" data-barcode="${barcode}"></div>
          <span class="rcode-num">${barcode}</span>
        </div>
        <div class="inv-hdr-qr">
          <div data-qr="${esc(qrText)}"></div>
          <span class="rcode-num">امسح للتتبع</span>
        </div>
      </div>
      <table class="inv-details">
        <tr><td class="id-l">رقم الإصلاح</td><td>${esc(id)}</td><td class="id-l">التاريخ / الوقت</td><td>${date} — ${time}</td></tr>
        <tr><td class="id-l">العميل</td><td>${esc(name)}</td><td class="id-l">رقم الجوال</td><td>${esc(phone)}</td></tr>
        <tr><td class="id-l">الجهاز</td><td>${esc(device)}</td><td class="id-l">IMEI</td><td>${esc(imei)}</td></tr>
        <tr><td class="id-l">العطل</td><td>${esc(issue)}</td><td class="id-l">الحالة</td><td>تم الاستلام — قيد الإصلاح</td></tr>
      </table>
      ${parts.length ? `<table class="inv-table">
        <thead><tr><th>#</th><th>القطعة</th><th>الكمية</th><th>سعر الوحدة</th><th>الإجمالي</th></tr></thead>
        <tbody>${partsRows}</tbody>
      </table>` : ''}
      <div class="inv-totals">
        <div><span>رسوم الفحص</span><b>${cur(50)}</b></div>
        ${parts.length ? `<div><span>قطع الغيار</span><b>${cur(partsTotal)}</b></div>` : ''}
        <div class="inv-grand"><span>إجمالي الفاتورة</span><b>${cur(total)}</b></div>
        <div><span>المدفوع الآن</span><b class="text-green">${cur(paid)}</b></div>
        <div><span>المتبقي (يُستلم عند التسليم)</span><b class="text-orange">${cur(left)}</b></div>
      </div>
      <fieldset class="r-section r-signatures">
        <legend><i class="fa-solid fa-signature"></i> التوقيعات</legend>
        <div class="sign-grid">
          <div class="sign-box">
            <div class="sign-head"><i class="fa-solid fa-user"></i><span>توقيع العميل</span></div>
            <div class="sign-area"></div>
            <div class="sign-foot" id="sign-customer">${esc(name)}</div>
          </div>
          <div class="sign-box">
            <div class="sign-head"><i class="fa-solid fa-headset"></i><span>توقيع المستلم</span></div>
            <div class="sign-area"></div>
            <div class="sign-foot" id="sign-receiver">${esc((SESSION && SESSION.name) || '')}</div>
          </div>
          <div class="sign-box">
            <div class="sign-head"><i class="fa-solid fa-user-gear"></i><span>توقيع الفني</span></div>
            <div class="sign-area"></div>
            <div class="sign-foot" id="sign-tech">${esc((SESSION && SESSION.name) || '')}</div>
          </div>
        </div>
      </fieldset>
      ${socialLinksHTML()}
      <div class="receipt-footer">
        ${SETTINGS.printTerms !== false && Array.isArray(SETTINGS.terms) && SETTINGS.terms.filter(t => t && t.trim()).length ? `<div class="rf-terms">
          <h4><i class="fa-solid fa-file-shield"></i> الشروط والأحكام</h4>
          <ol>${SETTINGS.terms.filter(t => t && t.trim()).map(t => `<li>${esc(t)}</li>`).join('')}</ol>
        </div>` : ''}
        <div class="rf-stamp">
          <div class="stamp"><i class="fa-solid fa-check-double"></i> معتمد · ${esc(SETTINGS.company || '')}</div>
          <p class="rf-thanks">شكراً لثقتكم بنا — نعتني بجهازكم كأنه جهازنا</p>
          <p class="rf-note">${esc(SETTINGS.receiptFooter || 'احتفظ بهذا الإيصال لاستلام جهازكم')}</p>
        </div>
      </div>
    </div>`;
}

function showSalesHistory() {
  if (!SALES.length) { toast('لا توجد مبيعات مسجلة بعد — أتمم أول بيع من السلة', 'info'); return; }
  const rows = SALES.map(s => `
    <tr>
      <td><b>${esc(s.no)}</b>${s.kind === 'repair' ? '<span class="chip chip-blue">إصلاح</span>' : ''}<small class="bc-num">${s.date}</small></td>
      <td>${esc(s.customer || 'عميل نقدي')}</td>
      <td>${s.items.reduce((a, i) => a + i.qty, 0)}</td>
      <td>${cur(s.total)}</td>
      <td><span class="chip chip-${s.pay === 'آجل' ? 'red' : s.pay === 'بطاقة' ? 'blue' : s.pay === 'تحويل' ? 'orange' : 'green'}">${esc(s.pay)}</span></td>
      <td>${esc(s.cashier || '')}</td>
      <td><div class="row-actions"><button class="icon-btn xs" data-action="view-sale" data-sale="${esc(s.no)}" title="عرض الفاتورة"><i class="fa-solid fa-eye"></i></button><button class="icon-btn xs" data-action="edit-sale" data-sale="${esc(s.no)}" title="تعديل الأصناف"><i class="fa-solid fa-pen"></i></button></div></td>
    </tr>`).join('');
  openModal(`
    <div class="modal-head"><h3>سجل المبيعات (${SALES.length})</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="table-wrap"><table class="table">
        <thead><tr><th>الفاتورة</th><th>العميل</th><th>الكمية</th><th>الإجمالي</th><th>الدفع</th><th>الكاشير</th><th></th></tr></thead>
        <tbody>${rows}</tbody>
      </table></div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إغلاق</button></div>
  `);
}

/* ---------- Products: export / import / barcode printing ---------- */
function productsToCSV(list) {
  const rows = [['الاسم', 'الباركود', 'الفئة', 'سعر البيع', 'سعر الشراء', 'الكمية', 'الحد الأدنى', 'أقل سعر للبيع']];
  list.forEach(p => rows.push([p.name, p.barcode, p.cat, p.sell, p.buy, p.qty, p.low, p.minSell ?? '']));
  return '\ufeff' + rows.map(r => r.map(cell => {
    const s = String(cell ?? '').replace(/"/g, '""');
    return /[",\n]/.test(s) ? '"' + s + '"' : s;
  }).join(',')).join('\r\n');
}

function exportProducts() {
  const csv = productsToCSV(PRODUCTS);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'products-' + new Date().toISOString().slice(0, 10) + '.csv';
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 500);
  toast(`تم تصدير ${PRODUCTS.length} صنف إلى Excel`);
}

function parseCSV(text) {
  const lines = text.replace(/\r/g, '').split('\n').filter(l => l.trim());
  return lines.map(line => {
    const cells = [];
    let cur = '', inQ = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (inQ) { if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; } else if (ch === '"') inQ = false; else cur += ch; }
      else if (ch === '"') inQ = true;
      else if (ch === ',') { cells.push(cur); cur = ''; }
      else cur += ch;
    }
    cells.push(cur);
    return cells.map(c => c.trim());
  });
}

function handleProductsImport(file) {
  if (!file) return;
  if (!/\.(csv|txt)$/i.test(file.name)) { toast('يُرجى اختيار ملف CSV', 'error'); return; }
  const reader = new FileReader();
  reader.onload = (e) => {
    const rows = parseCSV(String(e.target.result));
    if (rows.length < 2) { toast('الملف فارغ أو غير صالح', 'error'); return; }
    let added = 0, updated = 0, skipped = 0;
    rows.slice(1).forEach(r => {
      const name = (r[0] || '').trim();
      if (!name) { skipped++; return; }
      const barcode = (r[1] || '').trim() || '6280' + String(Date.now() + added).slice(-8);
      const data = {
        name,
        barcode,
        cat: (r[2] || '').trim() || 'عام',
        sell: parseFloat(r[3]) || 0,
        buy: parseFloat(r[4]) || 0,
        qty: parseInt(r[5], 10) || 0,
        low: parseInt(r[6], 10) || 5,
        minSell: Math.max(0, parseFloat(r[7]) || 0),
      };
      const idx = PRODUCTS.findIndex(p => p.name === name);
      if (idx > -1) { PRODUCTS[idx] = { ...PRODUCTS[idx], ...data }; updated++; }
      else { PRODUCTS.unshift(data); added++; }
    });
    DB.set('products', PRODUCTS);
    renderProducts();
    toast(`تم الاستيراد: ${added} جديد، ${updated} محدّث، ${skipped} متجاهل`);
  };
  reader.onerror = () => toast('تعذر قراءة الملف', 'error');
  reader.readAsText(file, 'utf-8');
}

/* ---------- Item label designer ---------- */
const LABEL_DESIGN_DEFAULT = {
  showCompany: true, showName: true, showCat: true, showBarcode: true,
  showNumbers: true, showPrice: true, barcodeBottom: true, cutLine: false,
  width: 38, height: 25, barHeight: 7, gap: 0.15, align: 'center', qrRot: 0,
  fsCompany: 11, fsName: 11, fsNum: 7, fsPrice: 9
};
function labelNum(v, min, max, def) {
  const n = parseFloat(v);
  if (!isFinite(n)) return def;
  return Math.min(max, Math.max(min, n));
}
function loadLabelDesign() {
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem('sp_label_design') || '{}') || {}; } catch (e) { saved = {}; }
  const d = Object.assign({}, LABEL_DESIGN_DEFAULT, saved);
  d.width = labelNum(d.width, 20, 100, 38);
  d.height = labelNum(d.height, 10, 100, 25);
  d.barHeight = labelNum(d.barHeight, 3, 30, 7);
  d.gap = labelNum(d.gap, 0, 1.5, 0.15);
  d.fsCompany = labelNum(d.fsCompany, 5, 24, 11);
  d.fsName = labelNum(d.fsName, 5, 24, 11);
  d.fsNum = labelNum(d.fsNum, 4, 20, 7);
  d.fsPrice = labelNum(d.fsPrice, 4, 24, 9);
  d.align = ['center', 'right', 'left'].includes(d.align) ? d.align : 'center';
  d.qrRot = [0, 90, 180, 270].includes(Number(d.qrRot)) ? Number(d.qrRot) : 0;
  return d;
}
let LABEL_DESIGN = loadLabelDesign();
function saveLabelDesign() {
  try { localStorage.setItem('sp_label_design', JSON.stringify(LABEL_DESIGN)); } catch (e) {}
}
function syncLabelDesignForm() {
  const checks = {
    'bl-company': 'showCompany', 'bl-name': 'showName', 'bl-cat': 'showCat',
    'bl-barcode': 'showBarcode', 'bl-numbers': 'showNumbers', 'bl-price': 'showPrice',
    'bl-bottom': 'barcodeBottom', 'bl-cut': 'cutLine'
  };
  Object.keys(checks).forEach(id => { const el = $('#' + id); if (el) el.checked = !!LABEL_DESIGN[checks[id]]; });
  const nums = {
    'bl-width': 'width', 'bl-height': 'height', 'bl-bar-height': 'barHeight',
    'bl-fs-company': 'fsCompany', 'bl-fs-name': 'fsName', 'bl-fs-num': 'fsNum', 'bl-fs-price': 'fsPrice',
    'bl-gap': 'gap'
  };
  Object.keys(nums).forEach(id => { const el = $('#' + id); if (el) el.value = LABEL_DESIGN[nums[id]]; });
  const al = $('#bl-align'); if (al) al.value = LABEL_DESIGN.align;
  const qr = $('#bl-qr-rot'); if (qr) qr.value = String(LABEL_DESIGN.qrRot);
}
function readLabelDesignForm() {
  const ck = (id) => { const el = $('#' + id); return el ? !!el.checked : false; };
  LABEL_DESIGN.showCompany = ck('bl-company');
  LABEL_DESIGN.showName = ck('bl-name');
  LABEL_DESIGN.showCat = ck('bl-cat');
  LABEL_DESIGN.showBarcode = ck('bl-barcode');
  LABEL_DESIGN.showNumbers = ck('bl-numbers');
  LABEL_DESIGN.showPrice = ck('bl-price');
  LABEL_DESIGN.barcodeBottom = ck('bl-bottom');
  LABEL_DESIGN.cutLine = ck('bl-cut');
  LABEL_DESIGN.width = labelNum($('#bl-width')?.value, 20, 100, LABEL_DESIGN.width);
  LABEL_DESIGN.height = labelNum($('#bl-height')?.value, 10, 100, LABEL_DESIGN.height);
  LABEL_DESIGN.barHeight = labelNum($('#bl-bar-height')?.value, 3, 30, LABEL_DESIGN.barHeight);
  LABEL_DESIGN.gap = labelNum($('#bl-gap')?.value, 0, 1.5, LABEL_DESIGN.gap);
  LABEL_DESIGN.fsCompany = labelNum($('#bl-fs-company')?.value, 5, 24, LABEL_DESIGN.fsCompany);
  LABEL_DESIGN.fsName = labelNum($('#bl-fs-name')?.value, 5, 24, LABEL_DESIGN.fsName);
  LABEL_DESIGN.fsNum = labelNum($('#bl-fs-num')?.value, 4, 20, LABEL_DESIGN.fsNum);
  LABEL_DESIGN.fsPrice = labelNum($('#bl-fs-price')?.value, 4, 24, LABEL_DESIGN.fsPrice);
  const al = $('#bl-align');
  if (al) LABEL_DESIGN.align = ['center', 'right', 'left'].includes(al.value) ? al.value : 'center';
  const qr = $('#bl-qr-rot');
  if (qr) LABEL_DESIGN.qrRot = [0, 90, 180, 270].includes(Number(qr.value)) ? Number(qr.value) : 90;
}
function labelCurrency(n) {
  return CURRENCY + ' ' + (Number(n) || 0).toLocaleString('en-US');
}
function labelPreviewProduct() {
  const sel = $('#bl-product');
  const barcode = sel ? sel.value : '';
  const found = PRODUCTS.find(p => String(p.barcode) === String(barcode));
  if (found) return found;
  return PRODUCTS[0] || { name: 'شاشة 21 inch', barcode: '6221001452368', cat: 'إلكترونيات', sell: 750 };
}
function labelAlignValues(align) {
  if (align === 'right') return { flex: 'flex-start', text: 'right' };
  if (align === 'left') return { flex: 'flex-end', text: 'left' };
  return { flex: 'center', text: 'center' };
}
/* Builds one label. `scale` enlarges every dimension/font for the on-screen preview. */
function buildLabelHTML(p, d, scale, opts) {
  opts = opts || {};
  const s = scale || 1;
  const w = labelNum(d.width, 20, 100, 38);
  const h = labelNum(d.height, 10, 100, 25);
  const barH = labelNum(d.barHeight, 3, 30, 7);
  const pad = Math.max(0.3, Math.min(1.2, w * 0.012));
  const gap = labelNum(d.gap, 0, 1.5, 0.15);
  const av = labelAlignValues(d.align);
  const innerW = Math.max(1, w - pad * 2);
  /* QR labels use a side layout: vertical text columns around a single upright QR. */
  if (opts.type === 'qr') {
    const colMm = pt => pt * 0.3528 * 1.15 + 0.2;
    const colW = pt => colMm(pt) * s;
    const vcol = (pt, text, dir, extra) =>
      '<div class="bl-vcol" style="width:' + colW(pt).toFixed(2) + 'mm"><span style="font-size:' + (pt * s) + 'pt;direction:' + (dir || 'ltr') + ';' + (extra || '') + '">' + text + '</span></div>';
    const leftDefs = [];
    if (d.showCompany) leftDefs.push([d.fsCompany, esc(SETTINGS.company || 'SENIOR PRO'), 'ltr', 'font-weight:800;text-transform:uppercase;letter-spacing:.2px']);
    if (d.showName) leftDefs.push([d.fsName, esc(p.name || ''), 'rtl', 'font-weight:800']);
    if (d.showCat && p.cat) leftDefs.push([Math.min(d.fsNum, 8), esc(p.cat), 'rtl', 'font-weight:600;color:#333']);
    const rightDefs = [];
    if (d.showNumbers) rightDefs.push([d.fsNum, esc(p.barcode || ''), 'ltr', "font-weight:800;color:#111;font-family:Consolas,'Courier New',monospace;letter-spacing:.4px"]);
    if (d.showPrice) rightDefs.push([d.fsPrice, esc(labelCurrency(p.sell)), 'ltr', 'font-weight:800']);
    const allDefs = leftDefs.concat(rightDefs);
    const sideW = allDefs.reduce((sum, x) => sum + colMm(x[0]), 0)
      + 0.4 * (Math.max(0, leftDefs.length - 1) + Math.max(0, rightDefs.length - 1));
    // QR grows to fill the free width (max 17 mm) so the side columns never squeeze it out.
    const qrSize = Math.max(6, Math.min(17, innerW - sideW - 0.3));
    let qhtml = '<div class="bc-label bc-qr-label' + (d.cutLine ? ' bc-cut' : '') + '" style="width:' + (w * s) + 'mm;height:' + (h * s) + 'mm;padding:' + (pad * s) + 'mm;gap:' + (gap * s) + 'mm">';
    qhtml += '<div class="bl-qr-side" style="gap:' + (0.4 * s) + 'mm">' + leftDefs.map(x => vcol(x[0], x[1], x[2], x[3])).join('') + '</div>';
    if (d.showBarcode) qhtml += '<div class="bl-barcode bc-label-qr" data-qr="' + esc(p.barcode || '') + '" data-qrw="' + (qrSize * s) + '" data-qrrot="' + ([0, 90, 180, 270].includes(Number(d.qrRot)) ? Number(d.qrRot) : 0) + '"></div>';
    qhtml += '<div class="bl-qr-side" style="gap:' + (0.4 * s) + 'mm">' + rightDefs.map(x => vcol(x[0], x[1], x[2], x[3])).join('') + '</div>';
    qhtml += '</div>';
    return qhtml;
  }
  let html = '<div class="bc-label' + (d.cutLine ? ' bc-cut' : '') + '" style="width:' + (w * s) + 'mm;height:' + (h * s) + 'mm;padding:' + (pad * s) + 'mm;gap:' + (gap * s) + 'mm;align-items:' + av.flex + ';text-align:' + av.text + '">';
  html += '<div class="bl-texts" style="flex:' + (d.barcodeBottom ? '1 1 auto' : '0 0 auto') + ';gap:' + (gap * s) + 'mm">';
  if (d.showCompany) html += '<div class="bl-line bl-company" style="font-size:' + (d.fsCompany * s) + 'pt;line-height:1.02;font-weight:800">' + esc(SETTINGS.company || 'SENIOR PRO') + '</div>';
  if (d.showName) html += '<div class="bl-line bl-name" style="font-size:' + (d.fsName * s) + 'pt;line-height:1.02;font-weight:800">' + esc(p.name || '') + '</div>';
  if (d.showCat && p.cat) html += '<div class="bl-line bl-cat" style="font-size:' + (Math.min(d.fsNum, 8) * s) + 'pt;line-height:1;font-weight:600;color:#333">' + esc(p.cat) + '</div>';
  html += '</div>';
  if (d.showBarcode) html += '<div class="bl-barcode" data-barcode="' + esc(p.barcode || '') + '" data-bw="' + (innerW * s) + '" data-bh="' + (barH * s) + '"></div>';
  if (d.showNumbers) html += '<div class="bl-num" style="font-size:' + (d.fsNum * s) + 'pt;line-height:1.02;font-weight:800;color:#111">' + esc(p.barcode || '') + '</div>';
  if (d.showPrice) html += '<div class="bl-price" style="font-size:' + (d.fsPrice * s) + 'pt;line-height:1.02;font-weight:800">' + esc(labelCurrency(p.sell)) + '</div>';
  html += '</div>';
  return html;
}
/* Draws the EAN-13 as a crisp canvas so printed bars have no seams. */
function makeBarcodeCanvas(code, widthMm, heightMm) {
  const ean = ean13Code(code);
  const runs = ean13Runs(ean);
  const modules = runs.reduce((a, r) => a + r.w, 0) || 95;
  const ppm = 14; // canvas pixels per millimetre (~356 dpi)
  const W = Math.max(80, Math.round(widthMm * ppm));
  const H = Math.max(24, Math.round(heightMm * ppm));
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  canvas.style.width = widthMm + 'mm';
  canvas.style.height = heightMm + 'mm';
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = '#000';
  const quiet = Math.max(2, Math.round(0.7 * ppm));
  const mod = (W - quiet * 2) / modules;
  let x = quiet;
  runs.forEach(r => {
    const wpx = r.w * mod;
    if (r.on) {
      const x0 = Math.round(x);
      const x1 = Math.round(x + wpx);
      ctx.fillRect(x0, 0, Math.max(1, x1 - x0), H);
    }
    x += wpx;
  });
  return canvas;
}
function paintLabelBarcodes(root) {
  if (!root) return;
  root.querySelectorAll('.bl-barcode[data-barcode]').forEach(host => {
    const bw = parseFloat(host.dataset.bw) || 34;
    const bh = parseFloat(host.dataset.bh) || 7;
    host.innerHTML = '';
    host.appendChild(makeBarcodeCanvas(host.dataset.barcode, bw, bh));
  });
  root.querySelectorAll('.bc-label-qr[data-qr]').forEach(box => {
    box.innerHTML = '';
    const sizeMm = labelNum(box.dataset.qrw, 5, 30, 12);
    if (typeof QRCode !== 'undefined') {
      new QRCode(box, { text: String(box.dataset.qr || ''), width: Math.round(sizeMm * 12), height: Math.round(sizeMm * 12), colorDark: '#000000', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.M });
      // qrcodejs adds a hidden <img> copy next to the canvas; printing forces both
      // visible, which showed more than one QR. Keep a single square canvas.
      const cvs = box.querySelector('canvas');
      if (cvs) {
        box.querySelectorAll('img').forEach(n => n.remove());
        let out = cvs;
        const rot = [0, 90, 180, 270].includes(Number(box.dataset.qrrot)) ? Number(box.dataset.qrrot) : 0;
        if (rot) {
          out = document.createElement('canvas');
          out.width = cvs.width;
          out.height = cvs.height;
          const g = out.getContext('2d');
          g.translate(out.width / 2, out.height / 2);
          g.rotate(rot * Math.PI / 180);
          g.drawImage(cvs, -cvs.width / 2, -cvs.height / 2);
          cvs.replaceWith(out);
        }
        out.style.width = '100%';
        out.style.height = '100%';
        out.style.display = 'block';
      }
      box.style.width = sizeMm + 'mm';
      box.style.height = sizeMm + 'mm';
    } else {
      box.innerHTML = '<div class="qr-unavailable"><i class="fa-solid fa-qrcode"></i><span>QR غير متاح</span></div>';
    }
  });
}
function renderLabelPreview() {
  const stage = $('#bl-preview-stage');
  if (!stage) return;
  const d = LABEL_DESIGN;
  const pxPerMm = 96 / 25.4;
  const stageW = stage.clientWidth || 300;
  const scale = Math.max(1, Math.min(2.6, (stageW - 10) / (d.width * pxPerMm)));
  stage.innerHTML = buildLabelHTML(labelPreviewProduct(), d, scale);
  paintLabelBarcodes(stage);
  const sz = $('#bl-preview-size');
  if (sz) sz.textContent = d.width + ' × ' + d.height + ' ملم';
}
function populateLabelProductSelect() {
  const sel = $('#bl-product');
  if (!sel) return;
  const prev = sel.value;
  sel.innerHTML = '<option value="">— اختر صنفاً —</option>' + PRODUCTS.map(p =>
    '<option value="' + esc(p.barcode) + '">' + esc(p.name) + ' — ' + esc(p.barcode) + '</option>'
  ).join('');
  if (prev && PRODUCTS.some(p => String(p.barcode) === String(prev))) sel.value = prev;
  else if (PRODUCTS[0]) sel.value = PRODUCTS[0].barcode;
}
function initLabelDesigner() {
  const stage = $('#bl-preview-stage');
  if (!stage) return;
  syncLabelDesignForm();
  const sel = $('#bl-product');
  if (sel) {
    populateLabelProductSelect();
    sel.addEventListener('change', renderLabelPreview);
  }
  ['bl-company', 'bl-name', 'bl-cat', 'bl-barcode', 'bl-numbers', 'bl-price', 'bl-bottom', 'bl-cut'].forEach(id => {
    const el = $('#' + id);
    if (el) el.addEventListener('change', () => { readLabelDesignForm(); saveLabelDesign(); renderLabelPreview(); });
  });
  ['bl-width', 'bl-height', 'bl-bar-height', 'bl-fs-company', 'bl-fs-name', 'bl-fs-num', 'bl-fs-price', 'bl-gap'].forEach(id => {
    const el = $('#' + id);
    if (!el) return;
    el.addEventListener('input', () => { readLabelDesignForm(); saveLabelDesign(); renderLabelPreview(); });
    el.addEventListener('blur', () => syncLabelDesignForm());
  });
  const al = $('#bl-align');
  if (al) al.addEventListener('change', () => { readLabelDesignForm(); saveLabelDesign(); renderLabelPreview(); });
  const qr = $('#bl-qr-rot');
  if (qr) qr.addEventListener('change', () => { readLabelDesignForm(); saveLabelDesign(); renderLabelPreview(); });
  renderLabelPreview();
}
/* Shared print routine used by the designer, the modal and the single-label button. */
function printLabels(list, copies, paper, opts) {
  opts = opts || {};
  if (!list || !list.length) { toast('لا توجد أصناف للطباعة', 'error'); return; }
  const d = LABEL_DESIGN;
  const n = Math.max(1, Math.min(99, parseInt(copies, 10) || 1));
  const paperMode = ['label', '80mm', 'A5', 'A4'].includes(paper) ? paper : 'label';
  let html = '';
  for (let c = 0; c < n; c++) list.forEach(p => { html += buildLabelHTML(p, d, 1, opts); });
  const area = $('#print-invoice');
  if (!area) return;
  area.innerHTML = '<div class="bc-sheet" data-paper="' + paperMode + '">' + html + '</div>';
  paintLabelBarcodes(area);
  const sheet = area.querySelector('.bc-sheet');
  if (paperMode === 'label' && sheet) sheet.style.width = d.width + 'mm';
  document.body.classList.add('printing', 'printing-barcodes');
  let pageStyle = document.getElementById('barcode-print-page-style');
  if (!pageStyle) {
    pageStyle = document.createElement('style');
    pageStyle.id = 'barcode-print-page-style';
    document.head.appendChild(pageStyle);
  }
  const pageSize = paperMode === 'label' ? d.width + 'mm ' + d.height + 'mm'
    : paperMode === 'A4' ? 'A4' : paperMode === 'A5' ? 'A5' : '80mm 297mm';
  const margin = (paperMode === 'label' || paperMode === '80mm') ? '0' : '6mm';
  pageStyle.textContent = '@media print { @page { size: ' + pageSize + '; margin: ' + margin + '; } }';
  closeModal();
  setTimeout(() => {
    window.print();
    setTimeout(() => {
      area.innerHTML = '';
      document.body.classList.remove('printing', 'printing-barcodes');
      if (pageStyle) pageStyle.textContent = '';
    }, 900);
  }, 150);
}

function barcodePrintModal() {
  const checkboxes = PRODUCTS.map((p, i) => `
    <label class="bp-row">
      <input type="checkbox" class="bp-check" data-idx="${i}" ${i < 6 ? 'checked' : ''}>
      <span class="barcode barcode-sm" data-bc="${esc(p.barcode)}"></span>
      <b>${esc(p.name)}</b>
      <small>${esc(p.barcode)}</small>
    </label>`).join('');
  openModal(`
    <div class="modal-head"><h3><i class="fa-solid fa-print"></i> طباعة ملصقات الباركود</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">
      <div class="bp-tools">
        <div class="bp-tool"><label>عدد النسخ لكل صنف</label><div class="field-sm"><i class="fa-solid fa-copy"></i><input type="number" id="bp-copies" value="1" min="1" max="99"></div></div>
        <div class="bp-tool"><label>ورق الطباعة</label>
          <div class="select-wrap sm"><select id="bp-size"><option value="label" selected>ملصق ${esc(LABEL_DESIGN.width)}×${esc(LABEL_DESIGN.height)} ملم (رول)</option><option value="80mm">رول حراري 80 ملم</option><option value="A5">A5 (ورق)</option><option value="A4">A4 (ورق)</option></select><i class="fa-solid fa-chevron-down"></i></div></div>
        <button class="btn btn-navy bp-select-all" data-action="bp-select-all"><i class="fa-solid fa-check-double"></i> تحديد الكل</button>
      </div>
      <p class="bp-note"><i class="fa-solid fa-circle-info"></i> المقاس وارتفاع الباركود والخطوط تُؤخذ من «تصميم ملصق الصنف» في الإعدادات.</p>
      <div class="bp-list">${checkboxes || '<p class="bp-empty">لا توجد منتجات</p>'}</div>
    </div>
    <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="do-print-barcodes"><i class="fa-solid fa-print"></i> طباعة الملصقات</button></div>
  `);
  $$('#modal .barcode[data-bc]').forEach(b => genBarcode(b, b.dataset.bc));
}

function doPrintBarcodes() {
  const selected = $$('#modal .bp-check:checked')
    .map(c => PRODUCTS[parseInt(c.dataset.idx, 10)])
    .filter(Boolean);
  if (!selected.length) { toast('اختر صنفاً واحداً على الأقل للطباعة', 'error'); return; }
  const copies = Math.min(99, parseQty($('#bp-copies')?.value, 0) || 1);
  const paper = $('#bp-size')?.value || 'label';
  printLabels(selected, copies, paper);
}

/* ---------- Barcode settings: generator / reader ---------- */
const BG_STATE = { value: '', type: 'ean13', size: 'small' };

// تحميل المنتجات في قائمة اختيار الباركود
function populateBarcodeProductSelect() {
  const sel = $('#bc-product-select');
  if (!sel) return;
  sel.innerHTML = '<option value="">— اختر منتجاً —</option>' + PRODUCTS.map(p =>
    `<option value="${esc(p.barcode)}">${esc(p.name)} — ${esc(p.barcode)}</option>`
  ).join('');
  sel.addEventListener('change', () => {
    const val = sel.value;
    const inp = $('#bg-value');
    if (val) {
      inp.value = val;
      BG_STATE.value = val;
      renderBarcodeGen();
    }
  });
}

// تحديث معاينة الباركود تلقائياً عند تغيير أي حقل
function setupBarcodeLivePreview() {
  const fields = ['bg-value', 'bg-type', 'bg-size'];
  fields.forEach(id => {
    const el = $(id);
    if (el) el.addEventListener('input', () => {
      BG_STATE.value = $('#bg-value')?.value || '';
      BG_STATE.type = $('#bg-type')?.value || 'ean13';
      BG_STATE.size = $('#bg-size')?.value || 'small';
      renderBarcodeGen();
    });
  });
}

/* Barcode reader auto-focus enhancement */
const bcReadInp = $('#bc-read-input');
if (bcReadInp) {
  bcReadInp.addEventListener('focus', () => {
    bcReadInp.select();
  });
}
const BG_HEIGHTS = { small: 60, med: 90, large: 130 };
const BG_MODULES = { small: 2, med: 3, large: 4 };

function drawEan13Canvas(code13, hPx, modPx, withText) {
  const runs = ean13Runs(code13);
  const modules = runs.reduce((a, r) => a + r.w, 0);
  const quiet = 10;
  const W = (modules + quiet * 2) * modPx;
  const textH = withText ? Math.round(hPx * 0.3) : 0;
  const canvas = document.createElement('canvas');
  canvas.width = W; canvas.height = hPx + textH;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, W, hPx + textH);
  ctx.fillStyle = '#000';
  let x = quiet * modPx;
  runs.forEach(r => { if (r.on) ctx.fillRect(x, 0, r.w * modPx, hPx); x += r.w * modPx; });
  if (withText) {
    ctx.fillStyle = '#000';
    ctx.font = Math.round(textH * 0.7) + 'px Consolas, monospace';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(code13, W / 2, hPx + textH / 2);
  }
  return canvas;
}

function renderBarcodeGen() {
  const box = $('#bg-preview');
  const num = $('#bg-preview-num');
  if (!box) return;
  const val = BG_STATE.value || '0';
  const h = BG_HEIGHTS[BG_STATE.size];
  box.innerHTML = '';
  box.classList.remove('wide');
  if (BG_STATE.type === 'qr') {
    const wrap = document.createElement('div');
    wrap.style.background = '#fff';
    wrap.style.padding = '6px';
    wrap.style.borderRadius = '6px';
    if (typeof QRCode !== 'undefined') new QRCode(wrap, { text: val, width: h + 40, height: h + 40, colorDark: '#0B2D5B', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.M });
    else wrap.appendChild(makeQR(val));
    box.appendChild(wrap);
  } else {
    // Real scannable EAN-13 — identical encoding to printed labels (genBarcode)
    const digits = String(val).replace(/\D/g, '');
    if (!digits) {
      box.innerHTML = '<span class="empty-state">أدخل أرقاماً لتوليد الباركود</span>';
    } else {
      box.appendChild(drawEan13Canvas(ean13Code(digits), h, BG_MODULES[BG_STATE.size] || 2, false));
    }
  }
  if (num) num.textContent = val;
}

function printOneBarcodeLabel() {
  const val = (BG_STATE.value || '').trim() || '0';
  const found = PRODUCTS.find(p => String(p.barcode) === val);
  const product = found || { name: SETTINGS.company || 'SENIOR PRO', barcode: val, cat: '', sell: 0 };
  printLabels([product], 1, 'label', { type: BG_STATE.type });
}

function barcodeHitHTML(p) {
  const qty = Number(p.qty) || 0;
  const low = Number(p.low) || 0;
  const isLow = qty <= low;
  return `
      <div class="scan-hit">
        <div class="prod-ic">📦</div>
        <div><b>${esc(p.name)}</b><span>${esc(p.cat)} — الباركود ${esc(p.barcode)}</span></div>
        <div class="scan-side"><div class="scan-price">${cur(p.sell)}</div><span class="chip ${isLow ? 'chip-red' : 'chip-green'}">${isLow ? 'مخزون منخفض · ' : ''}متوفر ${qty}</span></div>
      </div>`;
}

function bcReadResult(val) {
  const box = $('#bc-read-result');
  if (!box) return;
  const q = (val || '').trim();
  if (!q) { box.innerHTML = ''; return; }
  // Exact barcode match only — never auto-pick a partial name (showed wrong products)
  const p = PRODUCTS.find(x => x.barcode === q);
  if (p) {
    box.innerHTML = barcodeHitHTML(p);
    toast(`تمت قراءة «${p.name}»`, 'success');
    return;
  }
  const hits = q.length >= 2 ? PRODUCTS.filter(x => String(x.name || '').includes(q)).slice(0, 5) : [];
  box.innerHTML = (hits.length ? `<div class="scan-list">${hits.map(barcodeHitHTML).join('')}</div>` : '')
    + `<div class="scan-miss"><i class="fa-solid fa-circle-xmark"></i> لا يوجد صنف بالباركود «${esc(q)}»${hits.length ? ' — أقرب الأصناف بالاسم أعلاه' : ''}</div>`;
  if (!hits.length) toast('الصنف غير موجود', 'error');
}

/* ============================================================
   Auto-update UI (إعدادات → تحديث البرنامج)
   ============================================================ */
let UPD_POLL = null;

function fmtBytes(n) {
  n = Number(n) || 0;
  if (n >= 1048576) return (n / 1048576).toFixed(1) + ' MB';
  if (n >= 1024) return (n / 1024).toFixed(0) + ' KB';
  return n + ' B';
}

function setUpdMsg(msg, kind = 'info') {
  const el = $('#upd-msg');
  if (!el) return;
  el.style.display = msg ? '' : 'none';
  el.className = 'upd-msg ' + (kind === 'error' ? 'upd-err' : kind === 'success' ? 'upd-ok' : 'upd-info');
  el.innerHTML = msg;
}

function updPhaseLabel(st) {
  switch (st.phase) {
    case 'available': return '<span class="chip chip-orange">تحديث متاح</span>';
    case 'up-to-date': return '<span class="chip chip-green">محدَّث لآخر إصدار</span>';
    case 'checking': return '<span class="chip chip-blue">جارٍ التحقق...</span>';
    case 'downloading': return '<span class="chip chip-blue">جارٍ التحميل ' + (st.download.percent || 0) + '٪</span>';
    case 'downloaded': return '<span class="chip chip-green">الحزمة جاهزة للتثبيت</span>';
    case 'installing': return '<span class="chip chip-blue">جارٍ التثبيت...</span>';
    case 'error': return '<span class="chip chip-red">خطأ</span>';
    default: return '<span class="chip">جاهز</span>';
  }
}

function updFeedLabel(st) {
  /* Feed URL is baked into the app code — never shown to the client,
     only the connection status. */
  if (!st.feedUrl) return '<span class="text-red">لم يتم ضبط مصدر التحديثات</span>';
  if (st.feedReachable === true) return '<span class="text-green">متصل</span>';
  if (st.feedReachable === false) return '<span class="text-red">تعذر الوصول</span>';
  return '<span class="text-muted">لم يتم التحقق بعد</span>';
}

function renderUpdatePanel(st) {
  const box = $('#update-panel-content');
  if (!box) return;
  if (!st) { apiFetch('/update/status').then(r => r.json()).then(renderUpdatePanel).catch(() => {
    box.innerHTML = '<div class="license-loading">تعذر الاتصال بخادم التحديث</div>';
  }); return; }

  const isAdmin = SESSION && SESSION.role === 'مدير النظام';
  const lastDate = st.lastInstalled ? new Date(st.lastInstalled.date).toLocaleDateString('ar-EG') : '—';
  const notes = (st.latest && st.latest.notes || []);
  const notesHtml = notes.length
    ? '<ul class="upd-notes">' + notes.map(n => '<li>' + esc(n) + '</li>').join('') + '</ul>'
    : '';
  const downloading = st.phase === 'downloading';
  const canInstall = st.phase === 'downloaded';
  const available = st.phase === 'available' || st.phase === 'downloaded';

  box.innerHTML = `
    <div class="upd-grid">
      <div class="upd-row"><span>الإصدار الحالي</span><b class="chip chip-blue">v${esc(st.current)}</b></div>
      <div class="upd-row"><span>تاريخ آخر تحديث</span><b>${esc(lastDate)}</b></div>
      <div class="upd-row"><span>حالة الاتصال بسيرفر التحديثات</span><div>${updFeedLabel(st)}</div></div>
      <div class="upd-row"><span>حالة التحديث</span>${updPhaseLabel(st)}</div>
      ${st.lastCheckError ? `<div class="upd-row"><span>آخر خطأ</span><b class="text-red">${esc(st.lastCheckError)}</b></div>` : ''}
      ${st.migratedFrom ? `<div class="upd-row"><span>قاعدة البيانات</span><b class="text-green">تم ترحيلها بنجاح من مجلد البرنامج</b></div>` : ''}
    </div>

    <div id="upd-msg" class="upd-msg" style="display:none"></div>

    ${downloading ? `
      <div class="upd-progress-wrap">
        <div class="upd-progress-head"><span>تحميل التحديث ${st.latest ? 'v' + esc(st.latest.version) : ''}</span><b id="upd-percent">${st.download.percent || 0}٪</b></div>
        <div class="upd-progress"><div id="upd-bar" class="upd-bar" style="width:${st.download.percent || 0}%"></div></div>
        <div class="upd-progress-meta"><span id="upd-bytes">${fmtBytes(st.download.received)} / ${fmtBytes(st.download.total)}</span><span id="upd-speed">${fmtBytes(st.download.speed)}/ث</span></div>
      </div>` : ''}

    ${available && notesHtml ? `<div class="upd-whatsnew"><div class="upd-whatsnew-head"><i class="fa-solid fa-wand-magic-sparkles"></i> ما الجديد في الإصدار v${esc(st.latest.version)}</div>${notesHtml}</div>` : ''}

    <div class="upd-actions">
      <button class="btn btn-navy btn-sm" id="upd-check" data-action="update-check"><i class="fa-solid fa-arrows-rotate"></i> التحقق من وجود تحديثات</button>
      ${st.phase === 'available' ? `<button class="btn btn-accent btn-sm" data-action="update-download"><i class="fa-solid fa-download"></i> تحميل التحديث${st.latest && st.latest.size ? ' (' + fmtBytes(st.latest.size) + ')' : ''}</button>` : ''}
      ${canInstall ? `<button class="btn btn-green btn-sm" id="upd-install" data-action="update-install"><i class="fa-solid fa-gears"></i> تثبيت التحديث وإعادة التشغيل</button>` : ''}
      ${st.phase === 'available' && st.latest ? `<button class="btn btn-ghost btn-sm" data-action="update-skip"><i class="fa-solid fa-clock"></i> تأجيل هذا الإصدار</button>` : ''}
    </div>

    ${st.phase === 'up-to-date' ? '<div class="upd-ok-line"><i class="fa-solid fa-circle-check"></i> لا توجد تحديثات جديدة — أنت تستخدم أحدث إصدار</div>' : ''}
    ${st.phase === 'downloaded' ? '<div class="upd-info-line"><i class="fa-solid fa-shield-halved"></i> تم التحقق من سلامة الحزمة (SHA256 + توقيع رقمي). قبل التثبيت تُؤخذ نسخة احتياطية كاملة من قاعدة البيانات تلقائياً.</div>' : ''}
    ${st.skippedVersion ? `<div class="upd-info-line"><i class="fa-solid fa-clock"></i> الإصدار ${esc(st.skippedVersion)} مؤجَّل — التحقق اليدوي يتجاهل التأجيل.</div>` : ''}
    ${isAdmin && !st.feedUrl ? '<div class="upd-info-line upd-err"><i class="fa-solid fa-triangle-exclamation"></i> لم يُضبط رابط مصدر التحديثات بعد. أدخل رابط ملف update-manifest.json الذي تحصل عليه من مدير النظام عند الإصدار.</div>' : ''}
  `;
}

async function pollDownload() {
  if (UPD_POLL) clearInterval(UPD_POLL);
  UPD_POLL = setInterval(async () => {
    try {
      const r = await apiFetch('/update/status');
      const st = await r.json();
      const bar = $('#upd-bar');
      if (bar) bar.style.width = (st.download.percent || 0) + '%';
      const pct = $('#upd-percent'); if (pct) pct.textContent = (st.download.percent || 0) + '٪';
      const by = $('#upd-bytes'); if (by) by.textContent = fmtBytes(st.download.received) + ' / ' + fmtBytes(st.download.total);
      const sp = $('#upd-speed'); if (sp) sp.textContent = fmtBytes(st.download.speed) + '/ث';
      if (st.phase !== 'downloading') {
        clearInterval(UPD_POLL); UPD_POLL = null;
        renderUpdatePanel(st);
        if (st.phase === 'downloaded') toast('تم تحميل التوفيث والتحقق منه — جاهز للتثبيت', 'success');
        if (st.phase === 'error') setUpdMsg(st.error || 'فشل التحميل', 'error');
      }
    } catch (e) {}
  }, 900);
}

async function initUpdatePanel() {
  try {
    const r = await apiFetch('/update/status');
    const st = await r.json();
    renderUpdatePanel(st);
    const about = $('#about-version');
    if (about) about.textContent = 'V' + st.current;
    // Notify once when an update is available (respects postpone).
    if (st.phase === 'available') toast(`يتوفر تحديث جديد للبرنامج: الإصدار ${st.latest.version} — من الإعدادات → تحديث البرنامج`, 'info');
  } catch (e) {
    const box = $('#update-panel-content');
    if (box) box.innerHTML = '<div class="license-loading">تعذر تحميل حالة التحديث</div>';
  }
}

const ACTIONS = {
  'toggle-sidebar': () => {
    const s = $('#sidebar');
    if (window.matchMedia('(max-width: 860px)').matches) {
      /* Mobile/narrow: drawer open/close over the overlay. */
      s.classList.contains('open') ? closeSidebar() : openSidebar();
    } else {
      /* Desktop: collapse/expand the sidebar (the close button is hidden there). */
      document.body.classList.toggle('sidebar-collapsed');
      localStorage.setItem('senior-sidebar-collapsed', document.body.classList.contains('sidebar-collapsed') ? '1' : '0');
    }
  },
  'toggle-notif': () => { const p = $('#notif-panel'); const was = p.classList.contains('open'); $$('.notif-panel').forEach(x => x.classList.remove('open')); if (!was) p.classList.add('open'); },
  'mark-read': () => { $$('#notif-panel .np-item.unread').forEach(i => i.classList.remove('unread')); const c = $('#notif-panel .np-count'); if (c) c.textContent = '0'; const btn = $('.icon-btn.has-dot'); if (btn) btn.classList.remove('has-dot'); },
  'fab': () => { const w = $('.fab-wrap'); w.classList.toggle('open'); $('#fab').classList.toggle('open', w.classList.contains('open')); },
  'help': () => toast('الدليل متاح من مركز المساعدة', 'info'),
  'close-modal': closeModal,
  'toggle-dash-privacy': () => { DASH_PRIVACY = !DASH_PRIVACY; applyDashPrivacy(); },
  'save-customer': () => {
    const name = ($('#mc-name')?.value || '').trim();
    const phone = ($('#mc-phone')?.value || '').trim();
    if (!name || !phone) { toast('يرجى إدخال الاسم ورقم الجوال', 'error'); return; }
    const addr = ($('#mc-address')?.value || '').trim();
    const notes = ($('#mc-notes')?.value || '').trim();
    const debt = Math.max(0, parseFloat($('#mc-debt')?.value) || 0);
    CUSTOMERS.unshift({ name, phone, address: addr, notes, debt, repairs: 0, payments: 0, type: 'عميل جديد' });
    DB.set('customers', CUSTOMERS);
    closeModal(); renderCustomers();
    toast(`تم إضافة العميل «${name}» بنجاح`);
  },
  'save-product': (e) => {
    const name = ($('#mp-name')?.value || '').trim();
    if (!name) { toast('يرجى إدخال اسم المنتج', 'error'); return; }
    const cat = ($('#mp-cat')?.value || 'عام').trim();
    const bc = ean13Code(($('#mp-barcode')?.value || '6280' + String(Date.now()).slice(-8)).trim());
    const sell = parseFloat($('#mp-sell')?.value) || 0;
    const minSell = Math.max(0, parseFloat($('#mp-min-sell')?.value) || 0);
    if (minSell > 0 && sell > 0 && minSell > sell) { toast('أقل سعر للبيع لا يمكن أن يكون أكبر من سعر البيع', 'error'); return; }
    const data = { name, barcode: bc, cat, sell, minSell, buy: parseFloat($('#mp-buy')?.value) || 0, qty: parseInt($('#mp-qty')?.value || '0', 10), low: parseInt($('#mp-min')?.value || '5', 10) };
    const orig = e.target.closest('[data-product]')?.dataset.product || '';
    const idx = orig ? PRODUCTS.findIndex(p => p.name === orig) : -1;
    if (idx > -1) {
      PRODUCTS[idx] = { ...PRODUCTS[idx], ...data };
      DB.set('products', PRODUCTS); closeModal(); renderProducts();
      toast(`تم تحديث المنتج «${name}»`);
    } else {
      PRODUCTS.unshift(data);
      DB.set('products', PRODUCTS); closeModal(); renderProducts();
      toast(`تم إضافة المنتج «${name}»`);
    }
  },
  'save-return': () => {
    const product = ($('#r-product')?.value || '').trim();
    if (!product) { toast('أدخل اسم المنتج أولاً', 'error'); return; }
    const qty = Math.max(1, parseInt($('#r-qty')?.value || '1', 10) || 1);
    const type = ($('#r-type')?.value || 'من العميل');
    const reason = ($('#r-reason')?.value || '').trim();
    const p = PRODUCTS.find(x => x.name === product);
    const price = p ? (Number(p.sell) || 0) : 0;
    const r = {
      no: nextNum('RT-', RETURNS),
      product, qty, ref: reason || '—',
      type, amount: price * qty,
      date: new Date().toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' }),
      status: type === 'للمورد' ? 'قيد المعالجة' : 'مكتمل'
    };
    if (p) {
      if (type === 'للمورد') p.qty = Math.max(0, (Number(p.qty) || 0) - qty);
      else p.qty = (Number(p.qty) || 0) + qty;
    }
    RETURNS.unshift(r);
    DB.set('returns', RETURNS);
    DB.set('products', PRODUCTS);
    closeModal();
    renderReturns(); renderPosReturns(); renderProducts();
    toast(`تم تسجيل المرتجع ${r.no} — ${type}`);
  },
  'send-whatsapp': (e) => {
    const el = e.target.closest('[data-sale]');
    const s = CURRENT_RECEIPT && CURRENT_RECEIPT.no === el?.dataset.sale ? CURRENT_RECEIPT : SALES.find(x => x.no === el?.dataset.sale);
    if (s) sendInvoiceImage(s);
  },
  'send-email': (e) => {
    const el = e.target.closest('[data-sale]');
    const s = CURRENT_RECEIPT && CURRENT_RECEIPT.no === el?.dataset.sale ? CURRENT_RECEIPT : SALES.find(x => x.no === el?.dataset.sale);
    if (s) sendInvoice('email', s);
  },
  'add-quote': openQuoteModal,
  'add-quote-line': () => {
    const sel = $('#q-product');
    if (!sel || !sel.value) { toast('اختر منتجاً أولاً', 'error'); return; }
    const qty = parseQty($('#q-qty')?.value, 0);
    if (!qty) { toast('أدخل كمية صحيحة (1 أو أكثر)', 'error'); return; }
    const price = parseFloat($('#q-price')?.value);
    if (isNaN(price) || price <= 0) { toast('أدخل سعراً صحيحاً', 'error'); return; }
    const qMin = productMinSell(sel.value);
    if (qMin && price < qMin) { toast(`لا يمكن بيع «${sel.value}» بأقل من ${cur(qMin)}`, 'error'); return; }
    const idx = QUOTE_LINES.findIndex(x => x.name === sel.value);
    if (idx > -1) QUOTE_LINES[idx].qty += qty;
    else QUOTE_LINES.push({ name: sel.value, qty, price });
    toast(`أُضيف «${sel.value}» × ${qty}`);
    renderQuoteLines();
  },
  'remove-quote-line': (e) => {
    const btn = e.target.closest('[data-line]');
    if (!btn) return;
    QUOTE_LINES = QUOTE_LINES.filter(x => x.name !== btn.dataset.line);
    renderQuoteLines();
  },
  'save-quote': () => {
    const customer = ($('#q-customer')?.value || '').trim() || 'عميل نقدي';
    if (!QUOTE_LINES.length) { toast('أضف أصنافاً لعرض السعر أولاً', 'error'); return; }
    const sub = QUOTE_LINES.reduce((s, l) => s + (Number(l.price) || 0) * l.qty, 0);
    const taxRate = Number(SETTINGS.tax) || 0;
    const tax = sub * taxRate / 100;
    const q = {
      no: nextNum('Q-', QUOTES),
      customer,
      date: new Date().toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' }),
      lines: QUOTE_LINES.map(l => ({ name: l.name, qty: l.qty, price: l.price })),
      sub, tax, taxRate, total: sub + tax,
      status: 'ساري'
    };
    QUOTES.unshift(q);
    DB.set('quotes', QUOTES);
    QUOTE_LINES = [];
    closeModal();
    renderQuotes();
    toast(`تم حفظ عرض السعر ${q.no}`);
  },
  'print-quote': (e) => {
    const el = e.target.closest('[data-quote]');
    const q = QUOTES.find(x => x.no === el?.dataset.quote);
    if (q) printDocument(buildQuoteHTML(q));
  },
  'quote-to-sale': (e) => {
    const el = e.target.closest('[data-quote]');
    const q = QUOTES.find(x => x.no === el?.dataset.quote);
    if (!q) return;
    POS_CART = q.lines.map(l => ({ name: l.name, price: l.price, qty: l.qty }));
    closeModal();
    showView('sales');
    const tab = document.querySelector('.tab[data-tab="pos"]'); if (tab) tab.click();
    renderCart();
    toast(`تم نقل أصناف «${q.no}» إلى السلة — أكمل البيع`);
  },
  'delete-quote': (e) => {
    const el = e.target.closest('[data-quote]');
    if (!el) return;
    if (!confirm('هل تريد حذف هذا العرض؟')) return;
    QUOTES = QUOTES.filter(x => x.no !== el.dataset.quote);
    DB.set('quotes', QUOTES);
    renderQuotes();
    toast('تم حذف العرض');
  },
  'add-order': openOrderModal,
  'add-order-line': () => {
    const sel = $('#o-product');
    if (!sel || !sel.value) { toast('اختر منتجاً أولاً', 'error'); return; }
    const qty = parseQty($('#o-qty')?.value, 0);
    if (!qty) { toast('أدخل كمية صحيحة (1 أو أكثر)', 'error'); return; }
    const price = parseFloat($('#o-price')?.value);
    if (isNaN(price) || price <= 0) { toast('أدخل سعراً صحيحاً', 'error'); return; }
    const oMin = productMinSell(sel.value);
    if (oMin && price < oMin) { toast(`لا يمكن بيع «${sel.value}» بأقل من ${cur(oMin)}`, 'error'); return; }
    const idx = ORDER_LINES.findIndex(x => x.name === sel.value);
    if (idx > -1) ORDER_LINES[idx].qty += qty;
    else ORDER_LINES.push({ name: sel.value, qty, price });
    toast(`أُضيف «${sel.value}» × ${qty}`);
    renderOrderLines();
  },
  'remove-order-line': (e) => {
    const btn = e.target.closest('[data-line]');
    if (!btn) return;
    ORDER_LINES = ORDER_LINES.filter(x => x.name !== btn.dataset.line);
    renderOrderLines();
  },
  'save-order': () => {
    const customer = ($('#o-customer')?.value || '').trim() || 'عميل نقدي';
    if (!ORDER_LINES.length) { toast('أضف أصنافاً للطلب أولاً', 'error'); return; }
    const sub = ORDER_LINES.reduce((s, l) => s + (Number(l.price) || 0) * l.qty, 0);
    const taxRate = Number(SETTINGS.tax) || 0;
    const tax = sub * taxRate / 100;
    const paid = parseFloat($('#o-paid')?.value) || 0;
    const o = {
      no: nextNum('SO-', ORDERS),
      customer,
      date: new Date().toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' }),
      lines: ORDER_LINES.map(l => ({ name: l.name, qty: l.qty, price: l.price })),
      sub, tax, taxRate, total: sub + tax,
      paid: Math.min(Math.max(paid, 0), sub + tax),
      status: 'مفتوح'
    };
    ORDERS.unshift(o);
    DB.set('orders', ORDERS);
    ORDER_LINES = [];
    closeModal();
    renderOrders();
    toast(`تم حفظ طلب البيع ${o.no}`);
  },
  'order-to-sale': (e) => {
    const el = e.target.closest('[data-order]');
    const o = ORDERS.find(x => x.no === el?.dataset.order);
    if (!o) return;
    POS_CART = o.lines.map(l => ({ name: l.name, price: l.price, qty: l.qty }));
    closeModal();
    showView('sales');
    const tab = document.querySelector('.tab[data-tab="pos"]'); if (tab) tab.click();
    renderCart();
    toast(`تم نقل أصناف «${o.no}» إلى السلة — أكمل البيع`);
  },
  'order-pay': (e) => {
    const el = e.target.closest('[data-order]');
    const o = ORDERS.find(x => x.no === el?.dataset.order);
    if (!o || o.status === 'ملغي') return;
    openModal(`
      <div class="modal-head"><h3><i class="fa-solid fa-hand-holding-dollar"></i> تسجيل دفعة — ${esc(o.no)}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
      <div class="modal-body">
        <div class="r-grid-2">
          <div class="field"><label>إجمالي الطلب</label><i class="fa-solid fa-file-invoice-dollar"></i><input type="text" value="${cur(o.total)}" disabled></div>
          <div class="field"><label>المدفوع حالياً</label><i class="fa-solid fa-money-bill-wave"></i><input type="text" value="${cur(o.paid || 0)}" disabled></div>
          <div class="field span-2"><label>قيمة الدفعة</label><i class="fa-solid fa-coins"></i><input type="number" id="op-amount" value="${Math.max(0, (Number(o.total) || 0) - (Number(o.paid) || 0))}" min="0"></div>
        </div>
      </div>
      <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-order-pay" data-order="${esc(o.no)}"><i class="fa-solid fa-check"></i> تسجيل الدفعة</button></div>
    `);
  },
  'save-order-pay': (e) => {
    const el = e.target.closest('[data-order]');
    const o = ORDERS.find(x => x.no === el?.dataset.order);
    if (!o) return;
    const amt = parseFloat($('#op-amount')?.value) || 0;
    if (amt <= 0) { toast('أدخل قيمة الدفعة', 'error'); return; }
    o.paid = Math.min((Number(o.paid) || 0) + amt, Number(o.total) || 0);
    o.status = (Number(o.paid) >= Number(o.total)) ? 'مدفوع' : 'آجل';
    DB.set('orders', ORDERS);
    closeModal();
    renderOrders();
    toast(`تم تسجيل دفعة ${cur(amt)} على الطلب ${o.no}`);
  },
  'order-cancel': (e) => {
    const el = e.target.closest('[data-order]');
    if (!el) return;
    if (!confirm('هل تريد إلغاء هذا الطلب؟')) return;
    const o = ORDERS.find(x => x.no === el.dataset.order);
    if (!o) return;
    o.status = 'ملغي';
    DB.set('orders', ORDERS);
    renderOrders();
    toast('تم إلغاء الطلب');
  },
  'add-pos-return': openPosReturnModal,
  'add-pos-return-line': () => {
    const sel = $('#pr-product');
    if (!sel || !sel.value) { toast('اختر منتجاً أولاً', 'error'); return; }
    const qty = parseQty($('#pr-qty')?.value, 0);
    if (!qty) { toast('أدخل كمية صحيحة (1 أو أكثر)', 'error'); return; }
    const price = parseFloat($('#pr-price')?.value);
    if (isNaN(price) || price <= 0) { toast('أدخل سعراً صحيحاً', 'error'); return; }
    const idx = POS_RETURN_LINES.findIndex(x => x.name === sel.value);
    if (idx > -1) POS_RETURN_LINES[idx].qty += qty;
    else POS_RETURN_LINES.push({ name: sel.value, qty, price });
    toast(`أُضيف «${sel.value}» × ${qty}`);
    renderPosReturnLines();
  },
  'remove-pos-return-line': (e) => {
    const btn = e.target.closest('[data-line]');
    if (!btn) return;
    POS_RETURN_LINES = POS_RETURN_LINES.filter(x => x.name !== btn.dataset.line);
    renderPosReturnLines();
  },
  'save-pos-return': () => {
    const saleNo = ($('#pr-sale')?.value || '').trim();
    if (!saleNo) { toast('اختر الفاتورة الأصلية', 'error'); return; }
    if (!POS_RETURN_LINES.length) { toast('أضف أصنافاً للإرجاع أولاً', 'error'); return; }
    const type = ($('#pr-type')?.value || 'جزئي');
    const reason = ($('#pr-reason')?.value || '').trim();
    const total = POS_RETURN_LINES.reduce((s, l) => s + (Number(l.price) || 0) * l.qty, 0);
    const r = {
      no: nextNum('RT-', RETURNS),
      saleNo,
      date: new Date().toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' }),
      items: POS_RETURN_LINES.map(l => ({ name: l.name, qty: l.qty, price: l.price })),
      total, type, reason,
      status: 'مرتجع'
    };
    POS_RETURN_LINES.forEach(l => {
      const p = PRODUCTS.find(x => x.name === l.name);
      if (p) p.qty = (Number(p.qty) || 0) + l.qty;
    });
    DB.set('products', PRODUCTS);
    RETURNS.unshift(r);
    DB.set('returns', RETURNS);
    POS_RETURN_LINES = [];
    closeModal();
    renderProducts(); renderPOS(); renderPosReturns();
    toast(`تم تسجيل المرتجع ${r.no} وإرجاع الأصناف للمخزون`);
  },
  'print-return-pos': (e) => {
    const el = e.target.closest('[data-return]');
    const r = RETURNS.find(x => x.no === el?.dataset.return);
    if (r) printDocument(buildReturnHTML(r));
  },
  'delete-return': (e) => {
    const el = e.target.closest('[data-return]');
    if (!el) return;
    if (!confirm('هل تريد حذف هذا المرتجع؟')) return;
    RETURNS = RETURNS.filter(x => x.no !== el.dataset.return);
    DB.set('returns', RETURNS);
    renderReturns(); renderPosReturns();
    toast('تم حذف المرتجع');
  },
  'save-repair': () => {
    const name = ($('#f-customer-name')?.value || '').trim() || 'عميل غير محدد';
    const phone = ($('#f-customer-phone')?.value || '').trim();
    const device = [($('#f-device-brand')?.value || '').trim(), ($('#f-device-model')?.value || '').trim()].filter(Boolean).join(' ') || 'جهاز غير محدد';
    const issue = ($('#f-main-problem')?.value || '').trim() || 'بدون وصف';
    if (!CUSTOMERS.some(c => c.phone === phone && phone)) {
      CUSTOMERS.unshift({ name, phone, address: '', notes: issue, repairs: 1, payments: 0, type: 'عميل جديد' });
      DB.set('customers', CUSTOMERS); renderCustomers();
    }
    const num = Math.max(2000, ...REPAIRS.map(r => parseInt((r.id || '').replace(/\D/g, '') || 0, 10))) + 1;
    const id = SETTINGS.repPrefix + num;
    const parts = REPAIR_PARTS.map(p => ({ ...p }));
    // Re-validate stock at save time (may have changed since parts were added)
    for (const pr of parts) {
      const p = PRODUCTS.find(x => x.name === pr.name);
      const need = Number(pr.qty) || 0;
      const have = p ? (Number(p.qty) || 0) : 0;
      if (!p || need <= 0 || need > have) {
        toast(`المخزون غير كافٍ للقطعة «${pr.name}» (المتاح: ${have})`, 'error');
        return;
      }
    }
    const paid = Math.max(0, Math.min(parseFloat($('#paid-amount')?.value) || 0, LAST_TOTAL));
    const left = Math.max(LAST_TOTAL - paid, 0);
    const repair = { id, barcode: ean13Code('628000000' + String(num).padStart(4, '0')), customer: name, device, status: 'received', amount: LAST_TOTAL, paid, left, payment: 'نقداً', parts, date: new Date().toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' }) };
    REPAIRS.unshift(repair);
    if (paid > 0) { const pn = recordRepairPayment(repair, paid, 'paid'); if (pn) repair.paidNo = pn; }
    DB.set('repairs', REPAIRS);
    parts.forEach(pr => {
      const p = PRODUCTS.find(x => x.name === pr.name);
      if (p) p.qty = Math.max(0, (Number(p.qty) || 0) - (Number(pr.qty) || 0));
    });
    if (parts.length) { DB.set('products', PRODUCTS); renderProducts(); }
    REPAIR_PARTS = [];
    renderRepairParts(); renderRepairs(); updateTrackCard(repair);
    renderFinancialStats(); renderDashboardStats(); renderCustomersStats();
    CURRENT_RECEIPT_REPAIR = repair;
    toast(`تم استلام الجهاز — رقم الإصلاح ${id}` + (paid > 0 ? ` — دفعة ${cur(paid)}` : '') + (left > 0 ? `، باقي ${cur(left)} يُستلم عند التسليم` : '') + (parts.length ? ` — خصم ${parts.length} قطعة من المخزون` : ''));
    updateReceiptCodes();
  },
  'quick-customer': customerAddModal,
  'add-repair-part': () => {
    const sel = $('#rp-part-select');
    if (!sel || !sel.value) return;
    const p = PRODUCTS.find(x => x.name === sel.value);
    if (!p) return;
    const qty = parseQty($('#rp-part-qty')?.value, 0);
    if (!qty) { toast('أدخل كمية صحيحة (1 أو أكثر)', 'error'); return; }
    const avail = Number(p.qty) || 0;
    const used = (REPAIR_PARTS.find(x => x.name === p.name)?.qty) || 0;
    if (used + qty > avail) { toast(`الكمية المطلوبة (${used + qty}) أكبر من المتوفر (${avail}) في المخزون`, 'error'); return; }
    const idx = REPAIR_PARTS.findIndex(x => x.name === p.name);
    if (idx > -1) REPAIR_PARTS[idx].qty += qty;
    else REPAIR_PARTS.push({ name: p.name, qty, price: Number(p.sell) || 0 });
    renderRepairParts();
    calcPricing();
    toast(`أُضيفت «${p.name}» × ${qty}`);
  },
  'remove-repair-part': (e) => {
    const btn = e.target.closest('[data-part]');
    if (!btn) return;
    REPAIR_PARTS = REPAIR_PARTS.filter(x => x.name !== btn.dataset.part);
    renderRepairParts();
    calcPricing();
  },
  'add-product': () => productAddModal(),
  'add-damage': openDamageModal,
  'dm-add-line': () => damageAddLine(false),
  'dm-remove-line': (e) => {
    const btn = e.target.closest('[data-line]');
    if (!btn) return;
    DM_LINES = DM_LINES.filter(l => l.name !== btn.dataset.line);
    renderDMLines();
  },
  'save-damage': () => saveDamage(false),
  'save-damage-print': () => saveDamage(true),
  'view-damage': (e) => {
    const el = e.target.closest('[data-damage]');
    const d = DAMAGES.find(x => x.no === el?.dataset.damage);
    if (d) damageDetailsModal(d);
  },
  'print-damage': (e) => {
    const el = e.target.closest('[data-damage]');
    const d = DAMAGES.find(x => x.no === el?.dataset.damage);
    if (d) printDocument(buildDamageHTML(d));
  },
  'del-damage': (e) => {
    const el = e.target.closest('[data-damage]');
    const d = DAMAGES.find(x => x.no === el?.dataset.damage);
    if (!d) return;
    if (!confirm(`حذف فاتورة الهالك ${d.no}؟ سيتم إرجاع الكميات إلى المخزون.`)) return;
    (Array.isArray(d.lines) ? d.lines : []).forEach(l => {
      const p = PRODUCTS.find(x => x.name === l.name);
      if (p) p.qty = (Number(p.qty) || 0) + (Number(l.qty) || 0);
    });
    DAMAGES = DAMAGES.filter(x => x.no !== d.no);
    DB.set('damages', DAMAGES);
    DB.set('products', PRODUCTS);
    renderDamages(); renderProducts(); renderStock(); renderPOS();
    toast(`تم حذف فاتورة الهالك ${d.no} وإرجاع الكميات`);
  },
  'filter-damages': () => {
    DM_FILTER.all = !!$('#dm-all')?.checked;
    DM_FILTER.from = ($('#dm-from')?.value || '').trim();
    DM_FILTER.to = ($('#dm-to')?.value || '').trim();
    renderDamages();
  },
  'add-return': returnModal,
  'view-return': (e) => {
    const el = e.target.closest('[data-return]');
    const r = RETURNS.find(x => x.no === el?.dataset.return);
    if (r) returnViewModal(r);
  },
  'scan-barcode': scanBarcodeModal,
  'scan-find': () => {
    const q = ($('#sc-barcode')?.value || '').trim();
    const box = $('#scan-result');
    if (!q) { if (box) box.innerHTML = ''; return; }
    const p = PRODUCTS.find(x => x.barcode === q);
    if (p) {
      box.innerHTML = barcodeHitHTML(p);
      toast(`تم العثور على «${p.name}»`, 'success');
    } else {
      const hits = q.length >= 2 ? PRODUCTS.filter(x => String(x.name || '').includes(q)).slice(0, 5) : [];
      box.innerHTML = (hits.length ? `<div class="scan-list">${hits.map(barcodeHitHTML).join('')}</div>` : '')
        + `<div class="scan-miss"><i class="fa-solid fa-circle-xmark"></i> لم يتم العثور على منتج بالباركود «${esc(q)}»</div>`;
      if (!hits.length) toast('المنتج غير موجود', 'error');
    }
  },
  'add-category': () => categoryModal(null),
  'edit-category': (e) => {
    const btn = e.target.closest('[data-cat]');
    const c = CATEGORIES.find(x => x.name === btn?.dataset.cat);
    categoryModal(c || null);
  },
  'save-category': (e) => {
    const orig = e.target.closest('[data-cat]')?.dataset.cat || '';
    const name = ($('#cg-name')?.value || '').trim();
    if (!name) { toast('يرجى إدخال اسم التصنيف', 'error'); return; }
    const icon = $('#cg-icon')?.value || 'fa-box';
    const color = $('#cg-color')?.value || 'ic-navy';
    const idx = orig ? CATEGORIES.findIndex(c => c.name === orig) : -1;
    if (idx > -1) {
      if (name !== orig) { PRODUCTS.forEach(p => { if (p.cat === orig) p.cat = name; }); DB.set('products', PRODUCTS); }
      CATEGORIES[idx] = { ...CATEGORIES[idx], name, icon, color };
    } else {
      if (CATEGORIES.some(c => c.name === name)) { toast('هذا التصنيف موجود بالفعل', 'error'); return; }
      CATEGORIES.unshift({ name, icon, color });
    }
    DB.set('categories', CATEGORIES);
    renderCategories(); renderProducts();
    closeModal();
    toast(idx > -1 ? `تم تحديث التصنيف «${name}»` : `تمت إضافة التصنيف «${name}»`);
  },
  'del-category': (e) => {
    const btn = e.target.closest('[data-cat]');
    const name = btn?.dataset.cat;
    if (!name) return;
    CATEGORIES = CATEGORIES.filter(c => c.name !== name);
    DB.set('categories', CATEGORIES);
    renderCategories(); renderProducts();
    toast(`تم حذف التصنيف «${name}»`, 'error');
  },
  'add-supplier': () => supplierModal(null),
  'edit-supplier': (e) => {
    const btn = e.target.closest('[data-supplier]');
    const s = SUPPLIERS.find(x => x.name === btn?.dataset.supplier);
    supplierModal(s || null);
  },
  'del-supplier': (e) => {
    const btn = e.target.closest('[data-supplier]');
    const name = btn?.dataset.supplier;
    if (!name) return;
    SUPPLIERS = SUPPLIERS.filter(s => s.name !== name);
    DB.set('suppliers', SUPPLIERS);
    renderSuppliers();
    toast(`تم حذف المورد «${name}»`, 'error');
  },
  'save-supplier': (e) => {
    const orig = e.target.closest('[data-supplier]')?.dataset.supplier || '';
    const name = ($('#ms-name')?.value || '').trim();
    if (!name) { toast('يرجى إدخال اسم المورد', 'error'); return; }
    const idx = orig ? SUPPLIERS.findIndex(x => x.name === orig) : -1;
    const data = {
      name,
      phone: ($('#ms-phone')?.value || '').trim(),
      address: ($('#ms-address')?.value || '').trim(),
      cats: ($('#ms-cats')?.value || '').trim(),
      due: parseFloat($('#ms-due')?.value) || 0,
    };
    if (idx > -1) SUPPLIERS[idx] = { ...SUPPLIERS[idx], ...data };
    else SUPPLIERS.unshift(data);
    DB.set('suppliers', SUPPLIERS);
    renderSuppliers();
    closeModal();
    toast(idx > -1 ? `تم تحديث بيانات المورد «${name}»` : `تمت إضافة المورد «${name}»`);
  },
  'premium': () => { showView('settings'); setTimeout(() => { const b = document.querySelector('[data-snav="license"]'); if (b) b.click(); }, 50); },
  'update-check': async () => {
    const btn = $('#upd-check');
    if (btn) btn.disabled = true;
    setUpdMsg('جارٍ التحقق من وجود تحديثات...', 'info');
    try {
      const res = await apiFetch('/update/check', { method: 'POST' });
      const j = await res.json();
      renderUpdatePanel(j);
      if (j.available) toast(`يتوفر تحديث جديد: الإصدار ${j.version}`, 'info');
      else if (j.ok && !j.skipped) toast('البرنامج محدَّث لآخر إصدار');
      else if (j.skipped) toast(`الإصدار ${j.version} مؤجَّل — يمكنك تثبيته في أي وقت من هنا`);
    } catch (e) {
      setUpdMsg('تعذر الاتصال بمصدر التحديثات — تحقق من الإنترنت ورابط التحديثات', 'error');
    } finally { if (btn) btn.disabled = false; }
  },
  'update-download': async () => {
    try {
      const res = await apiFetch('/update/download', { method: 'POST' });
      const j = await res.json();
      if (!j.ok) { toast(j.reason || 'تعذر بدء التحميل', 'error'); return; }
      setUpdMsg('بدأ تحميل التحديث...', 'info');
      pollDownload();
    } catch (e) { toast('تعذر بدء التحميل', 'error'); }
  },
  'update-install': async () => {
    const btn = $('#upd-install');
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> جارٍ التثبيت...'; }
    try {
      const res = await apiFetch('/update/install', { method: 'POST' });
      const j = await res.json();
      if (j.ok) {
        setUpdMsg('جارٍ تثبيت التحديث وإعادة تشغيل البرنامج — لا تغلق النافذة...', 'info');
        toast('جارٍ تثبيت التحديث — سيعاد تشغيل البرنامج تلقائياً', 'info');
        setTimeout(() => location.replace('login.html'), 6000);
      } else toast(j.error || 'تعذر تثبيت التحديث', 'error');
    } catch (e) { toast('تعذر تثبيت التحديث', 'error'); if (btn) btn.disabled = false; }
  },
  'update-skip': async () => {
    try {
      const res = await apiFetch('/update/skip', { method: 'POST' });
      const j = await res.json();
      if (j.ok) { toast(`تم تأجيل الإصدار ${j.skipped} — لن يزعجك إشعاره تلقائياً`, 'info'); renderUpdatePanel(j); }
    } catch (e) { toast('تعذر تنفيذ التأجيل', 'error'); }
  },
  'update-save-feed': async () => {
    const inp = $('#upd-feed');
    if (!inp) return;
    try {
      const res = await apiFetch('/update/settings', { method: 'PUT', body: JSON.stringify({ feedUrl: inp.value.trim() }) });
      const j = await res.json();
      if (j.ok) toast('تم حفظ رابط مصدر التحديثات');
      else toast(j.error || 'تعذر الحفظ', 'error');
      renderUpdatePanel();
    } catch (e) { toast('تعذر الحفظ', 'error'); }
  },
  'actlock-copy': () => {
    const v = $('#actlock-machine')?.value || '';
    if (!v) return;
    if (navigator.clipboard) navigator.clipboard.writeText(v).then(() => toast('تم نسخ بصمة الجهاز')).catch(() => toast('تعذر النسخ', 'error'));
    else toast('تعذر النسخ', 'error');
  },
  'actlock-go': () => {
    const key = ($('#actlock-key')?.value || '').trim();
    if (!key) { actlockMsg('أدخل كود التفعيل أولاً'); return; }
    actlockMsg('جارٍ التحقق من الكود...');
    window.senior.activate(key).then(res => {
      if (res && res.ok) { actlockMsg(res.message + ' — جارٍ فتح البرنامج...', true); setTimeout(() => location.reload(), 1200); }
      else actlockMsg((res && res.message) || 'كود غير صحيح');
    });
  },
'bg-download': () => {
    const val = BG_STATE.value || '0';
    const download = (url) => {
      const a = document.createElement('a');
      a.href = url;
      a.download = 'barcode-' + val + '.png';
      document.body.appendChild(a); a.click(); a.remove();
      toast('تم تحميل ملف PNG');
    };
    if (BG_STATE.type === 'qr') {
      const temp = document.createElement('div');
      temp.style.cssText = 'position:fixed;left:-9999px;top:0;';
      document.body.appendChild(temp);
      new QRCode(temp, { text: val, width: 280, height: 280, colorDark: '#0B2D5B', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.M });
      const img = temp.querySelector('img');
      const canvas = temp.querySelector('canvas');
      const url = img ? img.src : (canvas ? canvas.toDataURL('image/png') : null);
      document.body.removeChild(temp);
      if (url) download(url); else toast('تعذر توليد رمز QR', 'error');
    } else {
      // Real scannable EAN-13 PNG (same encoding as on-screen labels)
      const digits = String(val).replace(/\D/g, '');
      if (!digits) { toast('أدخل أرقاماً لتوليد الباركود', 'error'); return; }
      download(drawEan13Canvas(ean13Code(digits), BG_HEIGHTS[BG_STATE.size], BG_MODULES[BG_STATE.size] || 2, true).toDataURL('image/png'));
    }
  },
  'bg-print': printOneBarcodeLabel,
  'bc-read-search': () => { const inp = $('#bc-read-input'); if (inp) bcReadResult(inp.value); },
  'bc-print-all': () => { barcodePrintModal(); const checks = $$('#modal .bp-check'); checks.forEach(c => { c.checked = true; }); const btn = $('[data-action="do-print-barcodes"]'); if (btn) toast('تم تحديد جميع الأصناف — اضغط طباعة', 'info'); },
  'export-products': exportProducts,
  'import-products': () => { const f = $('#import-products-file'); if (f) f.click(); },
  'print-barcodes': barcodePrintModal,
  'bp-select-all': () => {
    const checks = $$('#modal .bp-check');
    const all = checks.every(c => c.checked);
    checks.forEach(c => { c.checked = !all; });
  },
  'do-print-barcodes': doPrintBarcodes,
  'add-user': () => {
    if (!isAdmin()) { toast('إدارة المستخدمين لمدير النظام فقط', 'error'); return; }
    userModal(null);
  },
  'edit-user': (e) => {
    if (!isAdmin()) { toast('إدارة المستخدمين لمدير النظام فقط', 'error'); return; }
    const btn = e.target.closest('[data-user]');
    const u = getUsers().find(x => x.user === btn?.dataset.user);
    userModal(u || null);
  },
  'save-user': async (e) => {
    if (!isAdmin()) { toast('إدارة المستخدمين لمدير النظام فقط', 'error'); return; }
    const orig = e.target.closest('[data-user]')?.dataset.user || '';
    const name = ($('#mu-name')?.value || '').trim();
    const username = ($('#mu-user')?.value || '').trim();
    const role = $('#mu-role')?.value || 'كاشير';
    const status = $('#mu-status')?.value || 'نشط';
    const email = ($('#mu-email')?.value || '').trim();
    const pass = $('#mu-pass')?.value || '';
    const perms = role === 'مدير النظام'
      ? ALL_VIEWS.slice()
      : [...document.querySelectorAll('#mu-perms input:checked')].map(cb => cb.value);
    if (!name || !username) { toast('يرجى إدخال الاسم واسم الدخول', 'error'); return; }
    const users = getUsers();
    const idx = users.findIndex(x => String(x.user).toLowerCase() === orig.toLowerCase());
    const isSelf = orig.toLowerCase() === String(SESSION.user).toLowerCase();
    if (isSelf && status !== 'نشط') { toast('لا يمكنك إيقاف حسابك الحالي', 'error'); return; }
    if (isSelf && role !== users[idx]?.role) { toast('لا يمكنك تغيير دورك أثناء تسجيل الدخول', 'error'); return; }
    if (!orig && users.some(x => String(x.user).toLowerCase() === username.toLowerCase())) {
      toast('اسم الدخول مستخدم بالفعل', 'error'); return;
    }
    if (!orig && !pass) { toast('كلمة المرور مطلوبة لمستخدم جديد', 'error'); return; }
    if (pass && pass.length < 6) { toast('كلمة المرور يجب أن تكون 6 أحرف على الأقل', 'error'); return; }

    const payload = { user: orig || username, name, email, role, status, perms };
    if (pass) payload.password = pass;

    try {
      await upsertUser(payload);
      if (isSelf) {
        SESSION.name = name;
        SESSION.role = role;
        persistSession();
        const setTxt = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
        setTxt('top-name', name); setTxt('um-name', name);
        setTxt('top-role', role); setTxt('um-role', role);
      }
      closeModal(); renderUsers(); applyPermissions();
      toast(orig ? `تم تحديث المستخدم «${name}»` : `تمت إضافة المستخدم «${name}» بدور ${role}`);
    } catch (err) {
      toast(err.message || 'تعذر حفظ المستخدم', 'error');
    }
  },
  'toggle-user': async (e) => {
    if (!isAdmin()) { toast('إدارة المستخدمين لمدير النظام فقط', 'error'); return; }
    const btn = e.target.closest('[data-user]');
    const u = btn?.dataset.user;
    if (!u) return;
    if (u === SESSION.user) { toast('لا يمكنك إيقاف حسابك الحالي', 'error'); return; }
    const target = getUsers().find(x => x.user === u);
    if (!target) return;
    const nextStatus = target.status === 'نشط' ? 'موقوف' : 'نشط';
    try {
      await upsertUser({ user: u, status: nextStatus });
      renderUsers();
      toast(nextStatus === 'نشط' ? `تم تفعيل حساب «${target.name}»` : `تم إيقاف حساب «${target.name}»`, nextStatus === 'نشط' ? 'success' : 'error');
    } catch (err) {
      toast(err.message || 'تعذر تحديث الحساب', 'error');
    }
  },
  'del-user': async (e) => {
    if (!isAdmin()) { toast('إدارة المستخدمين لمدير النظام فقط', 'error'); return; }
    const btn = e.target.closest('[data-user]');
    const u = btn?.dataset.user;
    if (!u || u === 'admin') return;
    if (u === SESSION.user) { toast('لا يمكنك حذف حسابك الحالي', 'error'); return; }
    if (!confirm(`هل تريد حذف المستخدم «${u}»؟`)) return;
    try {
      await deleteUserAccount(u);
      renderUsers();
      toast('تم حذف المستخدم', 'error');
    } catch (err) {
      toast(err.message || 'تعذر حذف المستخدم', 'error');
    }
  },
  'add-employee': () => employeeModal(null),
  'edit-employee': (e) => {
    const btn = e.target.closest('[data-emp]');
    const emp = EMPLOYEES.find(x => x.name === btn?.dataset.emp);
    employeeModal(emp || null);
  },
  'save-employee': (e) => {
    const orig = e.target.closest('[data-emp]')?.dataset.emp || '';
    const name = ($('#me-name')?.value || '').trim();
    if (!name) { toast('يرجى إدخال اسم الموظف', 'error'); return; }
    const role = ($('#me-role')?.value || '').trim() || 'موظف';
    const idx = orig ? EMPLOYEES.findIndex(x => x.name === orig) : -1;
    const prev = idx > -1 ? EMPLOYEES[idx] : {};
    const data = {
      name,
      role,
      phone: ($('#me-phone')?.value || '').trim(),
      join: ($('#me-join')?.value || '').trim() || '2026',
      salary: parseFloat($('#me-salary')?.value) || 0,
      rating: ($('#me-rating')?.value || '').trim() || '4.5',
      perf: parseInt($('#me-perf')?.value, 10) || 0,
      chip: prev.chip || 'blue',
      color: prev.color || 'av-2',
      attend: prev.attend || '—',
      leave: prev.leave || '—',
      status: prev.status || 'مباشر',
      task: prev.task || '—',
    };
    if (idx > -1) EMPLOYEES[idx] = data;
    else EMPLOYEES.unshift(data);
    DB.set('employees', EMPLOYEES);
    renderEmployees();
    closeModal();
    toast(idx > -1 ? `تم تحديث بيانات «${name}»` : `تمت إضافة الموظف «${name}»`);
  },
  'view-employee': (e) => {
    const name = e.target.closest('[data-emp]')?.dataset.emp;
    const emp = EMPLOYEES.find(x => x.name === name);
    if (!emp) { toast('الموظف غير موجود', 'error'); return; }
    openModal(`
      <div class="modal-head"><h3><i class="fa-solid fa-user-tie"></i> بطاقة الموظف</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
      <div class="modal-body">
        <div class="r-grid-2">
          <div class="field span-2"><label>الاسم</label><i class="fa-solid fa-user"></i><input type="text" readonly value="${esc(emp.name)}"></div>
          <div class="field"><label>الدور</label><i class="fa-solid fa-briefcase"></i><input type="text" readonly value="${esc(emp.role)}"></div>
          <div class="field"><label>رقم الجوال</label><i class="fa-solid fa-mobile-screen"></i><input type="text" readonly value="${esc(emp.phone || '—')}"></div>
          <div class="field"><label>سنة الانضمام</label><i class="fa-solid fa-calendar"></i><input type="text" readonly value="${esc(emp.join || '—')}"></div>
          <div class="field"><label>الراتب</label><i class="fa-solid fa-money-bill-wave"></i><input type="text" readonly value="${emp.salary ? cur(emp.salary) : '—'}"></div>
          <div class="field"><label>الحالة</label><i class="fa-solid fa-circle-check"></i><input type="text" readonly value="${emp.status === 'مباشر' ? 'مباشر' : 'إجازة'}"></div>
          <div class="field"><label>الحضور</label><i class="fa-solid fa-clock"></i><input type="text" readonly value="${esc(emp.attend || '—')}"></div>
          <div class="field"><label>الانصراف</label><i class="fa-solid fa-clock"></i><input type="text" readonly value="${esc(emp.leave || '—')}"></div>
          <div class="field"><label>التقييم</label><i class="fa-solid fa-star"></i><input type="text" readonly value="${esc(emp.rating || '—')}"></div>
          <div class="field"><label>أداء الشهر</label><i class="fa-solid fa-chart-line"></i><input type="text" readonly value="${esc(emp.perf ?? '—')}%"></div>
          <div class="field span-2"><label>المهمة الحالية</label><i class="fa-solid fa-list-check"></i><input type="text" readonly value="${esc(emp.task || '—')}"></div>
        </div>
      </div>
      <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إغلاق</button><button class="btn btn-accent" data-action="edit-employee" data-emp="${esc(emp.name)}"><i class="fa-solid fa-pen"></i> تعديل</button></div>
    `);
  },
  'del-employee': (e) => {
    const name = e.target.closest('[data-emp]')?.dataset.emp;
    const emp = EMPLOYEES.find(x => x.name === name);
    if (!emp) return;
    if (!confirm(`هل تريد حذف الموظف «${emp.name}»؟`)) return;
    EMPLOYEES = EMPLOYEES.filter(x => x.name !== name);
    DB.set('employees', EMPLOYEES);
    renderEmployees();
    closeModal();
    toast('تم حذف الموظف', 'error');
  },
  'add-purchase': () => {
    const today = new Date().toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' });
    const supplierOpts = SUPPLIERS.map(s => `<option value="${esc(s.name)}">${esc(s.name)}</option>`).join('');
    const known = [...new Set(PURCHASES.map(p => p.supplier).filter(Boolean))].filter(n => !SUPPLIERS.some(s => s.name === n)).map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join('');
    const prodOpts = PRODUCTS.map(p => `<option value="${esc(p.name)}">${esc(p.name)} — شراء ${cur(p.buy)} (متوفر ${Number(p.qty) || 0})</option>`).join('');
    PO_LINES = [];
    openModal(`
      <div class="modal-head"><h3><i class="fa-solid fa-plus"></i> فاتورة شراء جديدة</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
      <div class="modal-body">
        <div class="r-grid-2">
          <div class="field span-2"><label>المورد</label><i class="fa-solid fa-truck"></i>
            <input type="text" id="np-supplier" list="np-suppliers" placeholder="اختر أو اكتب اسم المورد">
            <datalist id="np-suppliers">${supplierOpts}${known}</datalist>
          </div>
        </div>
        <div class="r-section" style="margin-top:14px">
          <legend><i class="fa-solid fa-cart-plus"></i> اختيار المنتجات</legend>
          <div class="parts-add">
            <div class="field grow"><label>المنتج</label>
              <div class="select-wrap"><select id="po-product"><option value="">— اختر منتجاً —</option>${prodOpts}</select><i class="fa-solid fa-chevron-down"></i></div>
            </div>
            <div class="field"><label>الكمية</label><i class="fa-solid fa-hashtag"></i><input type="number" id="po-qty" value="1" min="1"></div>
            <div class="field"><label>سعر الشراء</label><i class="fa-solid fa-money-bill-wave"></i><input type="number" id="po-price" value="0" min="0"></div>
            <button class="btn btn-navy" data-action="add-po-line"><i class="fa-solid fa-plus"></i> إضافة</button>
          </div>
          <div class="parts-list" id="po-lines-list"></div>
          <div class="parts-empty" id="po-lines-empty">لم تُضف منتجات بعد — اختر المنتج والكمية وأضفها</div>
        </div>
        <div class="r-grid-2" style="margin-top:14px">
          <div class="field"><label>عدد الأصناف</label><i class="fa-solid fa-boxes-stacked"></i><input type="number" id="np-items" value="0" readonly></div>
          <div class="field"><label>التاريخ</label><i class="fa-solid fa-calendar"></i><input type="text" id="np-date" value="${esc(today)}"></div>
          <div class="field"><label>المبلغ المدفوع</label><i class="fa-solid fa-hand-holding-dollar"></i><input type="number" id="np-paid" value="0" min="0"></div>
        </div>
        <div class="cs-totals" style="margin-top:12px">
          <div><span>إجمالي الفاتورة (من المنتجات)</span><b id="po-lines-total">${cur(0)}</b></div>
        </div>
      </div>
      <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-new-purchase"><i class="fa-solid fa-floppy-disk"></i> حفظ الفاتورة</button></div>
    `);
    const prodSel = $('#po-product');
    if (prodSel) prodSel.addEventListener('change', () => {
      const p = PRODUCTS.find(x => x.name === prodSel.value);
      const priceEl = $('#po-price');
      if (p && priceEl) priceEl.value = Number(p.buy) || 0;
    });
    renderPOLines();
  },
  'add-po-line': () => {
    const sel = $('#po-product');
    if (!sel || !sel.value) { toast('اختر منتجاً أولاً', 'error'); return; }
    const p = PRODUCTS.find(x => x.name === sel.value);
    if (!p) return;
    const qty = parseQty($('#po-qty')?.value, 0);
    if (!qty) { toast('أدخل كمية صحيحة (1 أو أكثر)', 'error'); return; }
    const price = parseFloat($('#po-price')?.value);
    if (isNaN(price) || price <= 0) { toast('أدخل سعر شراء صحيحاً', 'error'); return; }
    const idx = PO_LINES.findIndex(x => x.name === p.name);
    if (idx > -1) PO_LINES[idx].qty += qty;
    else PO_LINES.push({ name: p.name, qty, price });
    toast(`أُضيف «${p.name}» × ${qty}`);
    renderPOLines();
  },
  'remove-po-line': (e) => {
    const btn = e.target.closest('[data-line]');
    if (!btn) return;
    PO_LINES = PO_LINES.filter(x => x.name !== btn.dataset.line);
    renderPOLines();
  },
  'save-new-purchase': () => {
    const supplier = ($('#np-supplier')?.value || '').trim();
    if (!supplier) { toast('يرجى إدخال اسم المورد', 'error'); return; }
    if (!PO_LINES.length) { toast('أضف منتجات للفاتورة أولاً', 'error'); return; }
    const paid = parseFloat($('#np-paid')?.value);
    const p = isNaN(paid) ? 0 : Math.max(paid, 0);
    const total = PO_LINES.reduce((s, l) => s + (Number(l.price) || 0) * l.qty, 0);
    const num = Math.max(0, ...PURCHASES.map(x => parseInt((x.no || '').replace(/\D/g, '') || 0, 10))) + 1;
    const no = 'PO-' + String(num).padStart(3, '0');
    const left = Math.max(total - p, 0);
    PURCHASES.unshift({
      no,
      supplier,
      items: PO_LINES.length,
      total,
      paid: p,
      left,
      status: left === 0 ? 'مدفوع' : (p > 0 ? 'جزئي' : 'غير مدفوع'),
      date: ($('#np-date')?.value || '').trim(),
      lines: PO_LINES.map(l => ({ ...l }))
    });
    DB.set('purchases', PURCHASES);
    PO_LINES.forEach(l => {
      const prod = PRODUCTS.find(x => x.name === l.name);
      if (prod) prod.qty = (Number(prod.qty) || 0) + l.qty;
    });
    if (PO_LINES.length) { DB.set('products', PRODUCTS); renderProducts(); }
    renderPurchases();
    renderFinancialStats(); renderDashboardStats(); renderPurchasesStats();
    PO_LINES = [];
    closeModal();
    toast(`تمت إضافة فاتورة الشراء ${no}`);
  },
  'add-po': () => {
    const today = new Date().toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' });
    const supplierOpts = SUPPLIERS.map(s => `<option value="${esc(s.name)}">${esc(s.name)}</option>`).join('');
    const prodOpts = PRODUCTS.map(p => `<option value="${esc(p.name)}">${esc(p.name)} — شراء ${cur(p.buy)} (متوفر ${Number(p.qty) || 0})</option>`).join('');
    PO_LINES = [];
    openModal(`
      <div class="modal-head"><h3><i class="fa-solid fa-file-circle-plus"></i> إنشاء أمر شراء جديد</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
      <div class="modal-body">
        <div class="r-grid-2">
          <div class="field span-2"><label>المورد</label><i class="fa-solid fa-truck"></i>
            <input type="text" id="np-supplier" list="np-suppliers" placeholder="اختر أو اكتب اسم المورد">
            <datalist id="np-suppliers">${supplierOpts}</datalist>
          </div>
          <div class="field"><label>التاريخ</label><i class="fa-solid fa-calendar"></i><input type="text" id="np-date" value="${esc(today)}"></div>
        </div>
        <div class="r-section" style="margin-top:14px">
          <legend><i class="fa-solid fa-cart-plus"></i> أصناف الأمر</legend>
          <div class="parts-add">
            <div class="field grow"><label>المنتج</label>
              <div class="select-wrap"><select id="po-product"><option value="">— اختر منتجاً —</option>${prodOpts}</select><i class="fa-solid fa-chevron-down"></i></div>
            </div>
            <div class="field"><label>الكمية</label><i class="fa-solid fa-hashtag"></i><input type="number" id="po-qty" value="1" min="1"></div>
            <div class="field"><label>سعر الشراء</label><i class="fa-solid fa-money-bill-wave"></i><input type="number" id="po-price" value="0" min="0"></div>
            <button class="btn btn-navy" data-action="add-po-line"><i class="fa-solid fa-plus"></i> إضافة</button>
          </div>
          <div class="parts-list" id="po-lines-list"></div>
          <div class="parts-empty" id="po-lines-empty">لم تُضف منتجات بعد — اختر المنتج والكمية وأضفها</div>
        </div>
        <div class="cs-totals" style="margin-top:12px">
          <div><span>إجمالي الأمر (من الأصناف)</span><b id="po-lines-total">${cur(0)}</b></div>
        </div>
      </div>
      <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-po"><i class="fa-solid fa-floppy-disk"></i> حفظ الأمر</button></div>
    `);
    const prodSel = $('#po-product');
    if (prodSel) prodSel.addEventListener('change', () => {
      const p = PRODUCTS.find(x => x.name === prodSel.value);
      const priceEl = $('#po-price');
      if (p && priceEl) priceEl.value = Number(p.buy) || 0;
    });
    renderPOLines();
  },
  'po-line-qty': (e) => {
    const btn = e.target.closest('[data-line][data-d]');
    if (!btn) return;
    const d = parseInt(btn.dataset.d, 10) || 0;
    const line = PO_LINES.find(x => x.name === btn.dataset.line);
    if (!line) return;
    const newQty = (Number(line.qty) || 0) + d;
    if (newQty < 1) { toast('الكمية لا تقل عن 1', 'error'); return; }
    line.qty = newQty;
    renderPOLines();
  },
  'save-po': () => {
    const supplier = ($('#np-supplier')?.value || '').trim();
    if (!supplier) { toast('يرجى إدخال اسم المورد', 'error'); return; }
    if (!PO_LINES.length) { toast('أضف أصنافاً للأمر أولاً', 'error'); return; }
    const total = PO_LINES.reduce((s, l) => s + (Number(l.price) || 0) * l.qty, 0);
    const num = Math.max(0, ...PORDERS.map(x => parseInt((x.no || '').replace(/\D/g, '') || 0, 10))) + 1;
    const no = 'PO-' + String(num).padStart(3, '0');
    PORDERS.unshift({
      no,
      supplier,
      items: PO_LINES.length,
      total,
      status: 'قيد التوريد',
      date: ($('#np-date')?.value || '').trim(),
      lines: PO_LINES.map(l => ({ ...l }))
    });
    DB.set('porders', PORDERS);
    renderPO();
    PO_LINES = [];
    closeModal();
    toast(`تم إنشاء أمر الشراء ${no}`);
  },
  'view-po': (e) => {
    const no = e.target.closest('[data-po]')?.dataset.po;
    const p = PORDERS.find(x => x.no === no);
    if (!p) { toast('أمر الشراء غير موجود', 'error'); return; }
    const linesHtml = Array.isArray(p.lines) && p.lines.length
      ? `<div class="r-section" style="margin-top:14px"><legend><i class="fa-solid fa-boxes-stacked"></i> الأصناف</legend><div class="parts-list">${p.lines.map(l => `<div class="part-row"><span class="part-name">${esc(l.name)}</span><span class="part-qty">× ${l.qty}</span><span class="part-price">${cur((Number(l.price) || 0) * l.qty)}</span></div>`).join('')}</div></div>`
      : `<div class="field"><label>عدد الأصناف</label><i class="fa-solid fa-boxes-stacked"></i><input type="text" readonly value="${p.items} صنف"></div>`;
    openModal(`
      <div class="modal-head"><h3><i class="fa-solid fa-eye"></i> أمر الشراء ${esc(p.no)}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
      <div class="modal-body">
        <div class="r-grid-2">
          <div class="field span-2"><label>المورد</label><i class="fa-solid fa-truck"></i><input type="text" readonly value="${esc(p.supplier)}"></div>
          <div class="field"><label>التاريخ</label><i class="fa-solid fa-calendar"></i><input type="text" readonly value="${esc(p.date)}"></div>
          <div class="field"><label>الحالة</label><i class="fa-solid fa-circle-check"></i><input type="text" readonly value="${p.status === 'مستلم' ? 'مستلم' : 'قيد التوريد'}"></div>
          ${linesHtml}
          <div class="field span-2"><label>إجمالي الأمر</label><i class="fa-solid fa-money-bill-wave"></i><input type="text" readonly value="${cur(p.total)}"></div>
        </div>
      </div>
      <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إغلاق</button></div>
    `);
  },
  'print-po': (e) => {
    const no = e.target.closest('[data-po]')?.dataset.po;
    const p = PORDERS.find(x => x.no === no);
    if (p) printDocument(buildPOHTML(p));
  },
  'del-po': (e) => {
    const no = e.target.closest('[data-po]')?.dataset.po;
    if (!no) return;
    if (!confirm('هل تريد مسح أمر الشراء ' + no + '؟')) return;
    PORDERS = PORDERS.filter(x => x.no !== no);
    DB.set('porders', PORDERS);
    renderPO();
    toast('تم مسح أمر الشراء ' + no);
  },
  'print-supplier': (e) => {
    const name = e.target.closest('[data-supplier]')?.dataset.supplier;
    const s = SUPPLIERS.find(x => x.name === name);
    if (s) printDocument(buildSupplierHTML(s));
  },
  'view-supplier': (e) => {
    const name = e.target.closest('[data-supplier]')?.dataset.supplier;
    const s = SUPPLIERS.find(x => x.name === name);
    if (!s) return;
    const prods = supplierProducts(s);
    const rows = prods.map(p => `
      <tr>
        <td><b>${esc(p.name)}</b><small class="bc-num">${esc(p.barcode || '')}</small></td>
        <td>${cur(p.sell)}</td>
        <td>${cur(p.buy)}</td>
        <td>${Number(p.qty) || 0}</td>
      </tr>`).join('');
    openModal(`
      <div class="modal-head"><h3><i class="fa-solid fa-truck-ramp-box"></i> ${esc(s.name)} <small style="color:#94A3B8;font-weight:400">(${prods.length} منتج)</small></h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
      <div class="modal-body">
        <div class="r-grid-2">
          <div class="field"><label>رقم الجوال</label><i class="fa-solid fa-phone"></i><input type="text" readonly value="${esc(s.phone || '—')}"></div>
          <div class="field"><label>العنوان</label><i class="fa-solid fa-location-dot"></i><input type="text" readonly value="${esc(s.address || '—')}"></div>
          <div class="field span-2"><label>التصنيفات</label><i class="fa-solid fa-layer-group"></i><input type="text" readonly value="${esc(s.cats || '—')}"></div>
          <div class="field"><label>الأرصدة المستحقة</label><i class="fa-solid fa-money-bill-wave"></i><input type="text" readonly value="${cur(s.due || 0)}"></div>
        </div>
        <div class="r-section" style="margin-top:14px">
          <legend><i class="fa-solid fa-box"></i> منتجات المورد <small style="color:#94A3B8;font-weight:400">(${prods.length})</small></legend>
          ${prods.length ? `<div class="table-wrap"><table class="table"><thead><tr><th>المنتج</th><th>سعر البيع</th><th>سعر الشراء</th><th>الكمية</th></tr></thead><tbody>${rows}</tbody></table></div>` : '<p style="text-align:center;color:#94A3B8;padding:22px">لا توجد منتجات مسجلة في تصنيفات هذا المورد</p>'}
        </div>
      </div>
      <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إغلاق</button><button class="btn btn-accent" data-action="print-supplier" data-supplier="${esc(s.name)}"><i class="fa-solid fa-print"></i> طباعة</button></div>
    `);
  },
  'view-category': (e) => {
    const cat = e.target.closest('[data-cat]')?.dataset.cat;
    if (!cat) return;
    const prods = PRODUCTS.filter(p => p.cat === cat);
    const rows = prods.map(p => `
      <tr>
        <td><b>${esc(p.name)}</b><small class="bc-num">${esc(p.barcode || '')}</small></td>
        <td>${cur(p.sell)}</td>
        <td>${cur(p.buy)}</td>
        <td>${Number(p.qty) || 0}</td>
      </tr>`).join('');
    openModal(`
      <div class="modal-head"><h3><i class="fa-solid fa-layer-group"></i> منتجات تصنيف «${esc(cat)}» <small style="color:#94A3B8;font-weight:400">(${prods.length})</small></h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
      <div class="modal-body">
        ${prods.length ? `<div class="table-wrap"><table class="table">
          <thead><tr><th>المنتج</th><th>سعر البيع</th><th>سعر الشراء</th><th>الكمية</th></tr></thead>
          <tbody>${rows}</tbody>
        </table></div>` : '<p style="text-align:center;color:#94A3B8;padding:22px">لا توجد منتجات في هذا التصنيف</p>'}
      </div>
      <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إغلاق</button></div>
    `);
  },
  'view-purchase': (e) => {
    const no = e.target.closest('[data-po]')?.dataset.po;
    const p = PURCHASES.find(x => x.no === no);
    if (!p) return;
    openModal(`
      <div class="modal-head"><h3><i class="fa-solid fa-eye"></i> فاتورة شراء ${esc(p.no)}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
      <div class="modal-body">
        <div class="r-grid-2">
          <div class="field span-2"><label>المورد</label><i class="fa-solid fa-truck"></i><input type="text" readonly value="${esc(p.supplier)}"></div>
          <div class="field"><label>عدد الأصناف</label><i class="fa-solid fa-boxes-stacked"></i><input type="text" readonly value="${p.items} صنف"></div>
          <div class="field"><label>التاريخ</label><i class="fa-solid fa-calendar"></i><input type="text" readonly value="${esc(p.date)}"></div>
          <div class="field"><label>إجمالي الفاتورة</label><i class="fa-solid fa-money-bill-wave"></i><input type="text" readonly value="${cur(p.total)}"></div>
          <div class="field"><label>المدفوع</label><i class="fa-solid fa-hand-holding-dollar"></i><input type="text" readonly value="${cur(p.paid)}"></div>
          <div class="field"><label>المتبقي</label><i class="fa-solid fa-hourglass-half"></i><input type="text" readonly value="${cur(p.left)}"></div>
          <div class="field"><label>الحالة</label><i class="fa-solid fa-circle-check"></i><input type="text" readonly value="${p.status}"></div>
          ${Array.isArray(p.lines) && p.lines.length ? `
          <div class="r-section" style="grid-column:1 / -1;margin-top:6px"><legend><i class="fa-solid fa-boxes-stacked"></i> الأصناف</legend><div class="parts-list">${p.lines.map(l => `<div class="part-row"><span class="part-name">${esc(l.name)}</span><span class="part-qty">× ${l.qty}</span><span class="part-price">${cur((Number(l.price) || 0) * l.qty)}</span></div>`).join('')}</div></div>` : ''}
        </div>
      </div>
      <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إغلاق</button><button class="btn btn-accent" data-action="edit-purchase" data-po="${esc(p.no)}"><i class="fa-solid fa-pen"></i> تعديل الفاتورة</button></div>
    `);
  },
  'edit-purchase': (e) => {
    const no = e.target.closest('[data-po]')?.dataset.po;
    const p = PURCHASES.find(x => x.no === no);
    if (!p) return;
    PO_LINES = Array.isArray(p.lines) ? p.lines.map(l => ({ ...l })) : [];
    openModal(`
      <div class="modal-head"><h3><i class="fa-solid fa-pen"></i> تعديل فاتورة شراء ${esc(p.no)}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
      <div class="modal-body">
        <div class="r-grid-2">
          <div class="field span-2"><label>المورد</label><i class="fa-solid fa-truck"></i><input type="text" id="pe-supplier" value="${esc(p.supplier)}"></div>
          <div class="field"><label>التاريخ</label><i class="fa-solid fa-calendar"></i><input type="text" id="pe-date" value="${esc(p.date)}"></div>
          <div class="field"><label>المبلغ المدفوع</label><i class="fa-solid fa-hand-holding-dollar"></i><input type="number" id="pe-paid" value="${p.paid}" min="0"></div>
        </div>
        <div class="r-section" style="margin-top:14px">
          <legend><i class="fa-solid fa-cart-plus"></i> أصناف الفاتورة <small id="pe-items-label" style="color:var(--text-2);font-weight:400"></small></legend>
          <div class="parts-list" id="po-lines-list"></div>
          <div class="parts-empty" id="po-lines-empty">لا توجد منتجات في هذه الفاتورة</div>
        </div>
        <div class="cs-totals" style="margin-top:12px">
          <div><span>إجمالي الأصناف</span><b id="po-lines-total">${cur(0)}</b></div>
        </div>
        <div class="r-grid-2" style="margin-top:14px">
          <div class="field"><label>عدد الأصناف</label><i class="fa-solid fa-boxes-stacked"></i><input type="number" id="pe-items" value="${PO_LINES.length}" min="0" readonly></div>
          <div class="field"><label>إجمالي الفاتورة</label><i class="fa-solid fa-money-bill-wave"></i><input type="number" id="pe-total" value="${p.total}" min="0"></div>
        </div>
      </div>
      <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-purchase-edit" data-po="${esc(p.no)}"><i class="fa-solid fa-check"></i> حفظ التعديلات</button></div>
    `);
    const prodSel = $('#po-product');
    if (prodSel) prodSel.addEventListener('change', () => {
      const pp = PRODUCTS.find(x => x.name === prodSel.value);
      const priceEl = $('#po-price');
      if (pp && priceEl) priceEl.value = Number(pp.buy) || 0;
    });
    renderPOLines();
  },
  'save-purchase-edit': (e) => {
    const no = e.target.closest('[data-po]')?.dataset.po;
    const p = PURCHASES.find(x => x.no === no);
    if (!p) return;
    p.supplier = ($('#pe-supplier')?.value || '').trim() || p.supplier;
    const items = parseInt($('#pe-items')?.value, 10);
    if (!isNaN(items) && items >= 0) p.items = items;
    if (PO_LINES.length) {
      p.items = PO_LINES.length;
      p.lines = PO_LINES.map(l => ({ ...l }));
    }
    const total = parseFloat($('#pe-total')?.value);
    const paid = parseFloat($('#pe-paid')?.value);
    if (!isNaN(total) && total >= 0) p.total = total;
    if (!isNaN(paid) && paid >= 0) p.paid = paid;
    p.date = ($('#pe-date')?.value || '').trim() || p.date;
    p.left = Math.max(p.total - p.paid, 0);
    p.status = p.left === 0 ? 'مدفوع' : (p.paid > 0 ? 'جزئي' : 'غير مدفوع');
    DB.set('purchases', PURCHASES);
    renderPurchases();
    closeModal();
    toast(`تم تعديل فاتورة الشراء ${p.no}`);
  },
  'stock-movement': () => { showView('inventory'); setTimeout(() => { const t = $$('.tab').find(t => t.dataset.tab === 'stock'); t && t.click(); }, 50); },
  'checkout': posCheckout,
  'confirm-checkout': () => {
    if (!POS_CART.length) { toast('السلة فارغة — أضف منتجات أولاً', 'error'); return; }
    if (!checkMinSalePrices()) return;
    commitSale(buildSale());
  },
  'sales-history': showSalesHistory,
  'pos-add': (e) => { const el = e.target.closest('[data-pos]'); if (el) posAdd(el.dataset.pos); },
  'pos-qty': (e) => { const el = e.target.closest('[data-pos]'); if (el) posQty(el.dataset.pos, parseInt(el.dataset.d || '0', 10)); },
  'pos-remove': (e) => { const el = e.target.closest('[data-pos]'); if (el) posRemove(el.dataset.pos); },
  'pos-pay': (e) => {
    const el = e.target.closest('[data-pay]');
    if (!el) return;
    if (e.target.classList.contains('pay-amt')) return;
    const method = el.dataset.pay;
    el.classList.toggle('active');
    const inp = document.querySelector(`.pay-amt[data-pay="${method}"]`);
    const isActive = el.classList.contains('active');
    if (inp) {
      inp.disabled = !isActive;
      if (isActive && !parseFloat(inp.value)) {
        const remaining = Math.max(0, posTotals().total - currentPaid());
        inp.value = remaining > 0 ? Math.round(remaining * 100) / 100 : '';
      }
    }
    updatePayUI();
  },
  'pos-filter': (e) => {
    const el = e.target.closest('[data-poscat]');
    if (!el) return;
    POS_FILTER.cat = el.dataset.poscat;
    const dd = el.closest('.dropdown'); if (dd) dd.classList.remove('open');
    renderPOS();
  },
  'view-sale': (e) => {
    const el = e.target.closest('[data-sale]');
    const s = SALES.find(x => x.no === el?.dataset.sale);
    if (s) receiptModal(s);
  },
  'edit-sale': (e) => {
    const el = e.target.closest('[data-sale]');
    const s = SALES.find(x => x.no === el?.dataset.sale);
    if (!s) return;
    PO_LINES = (s.items || []).map(i => ({ name: i.name, qty: i.qty, price: i.price }));
    openModal(`
      <div class="modal-head"><h3><i class="fa-solid fa-pen"></i> تعديل فاتورة بيع ${esc(s.no)}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
      <div class="modal-body">
        <div class="r-grid-2">
          <div class="field span-2"><label>العميل</label><i class="fa-solid fa-user"></i><input type="text" id="se-customer" value="${esc(s.customer || '')}"></div>
        </div>
        <div class="r-section" style="margin-top:14px">
          <legend><i class="fa-solid fa-cart-plus"></i> أصناف الفاتورة <small id="se-items-label" style="color:var(--text-2);font-weight:400"></small></legend>
          <div class="parts-list" id="po-lines-list"></div>
          <div class="parts-empty" id="po-lines-empty">لا توجد منتجات في هذه الفاتورة</div>
        </div>
        <div class="cs-totals" style="margin-top:12px">
          <div><span>إجمالي الأصناف</span><b id="po-lines-total">${cur(0)}</b></div>
        </div>
        <div class="r-grid-2" style="margin-top:14px">
          <div class="field"><label>عدد الأصناف</label><i class="fa-solid fa-boxes-stacked"></i><input type="number" id="se-items" value="${PO_LINES.length}" min="0" readonly></div>
          <div class="field"><label>الإجمالي (بعد الخصم والضريبة)</label><i class="fa-solid fa-money-bill-wave"></i><input type="number" id="se-total" value="${s.total}" min="0" readonly></div>
        </div>
        <div id="se-data" data-disc="${s.disc || 0}" data-tax-rate="${s.taxRate || 0}" data-tax-enabled="${s.taxEnabled === false ? 'false' : 'true'}" hidden></div>
      </div>
      <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-sale-edit" data-sale="${esc(s.no)}"><i class="fa-solid fa-check"></i> حفظ التعديلات</button></div>
    `);
    renderPOLines();
  },
  'save-sale-edit': (e) => {
    const no = e.target.closest('[data-sale]')?.dataset.sale;
    const s = SALES.find(x => x.no === no);
    if (!s) return;
    if (!PO_LINES.length) { toast('لا يمكن ترك الفاتورة بدون أصناف', 'error'); return; }
    s.customer = ($('#se-customer')?.value || '').trim() || s.customer;
    const editSub = PO_LINES.reduce((a, l) => a + (Number(l.price) || 0) * l.qty, 0);
    const editDisc = Math.min(Number(s.disc) || 0, editSub);
    const badEdit = firstBelowMinSale(PO_LINES, editDisc, editSub);
    if (badEdit) { toast(`لا يمكن بيع «${badEdit.name}» بأقل من ${cur(badEdit.min)} — السعر الحالي ${cur(badEdit.unit)}`, 'error'); return; }
    s.items = PO_LINES.map(l => ({ name: l.name, qty: l.qty, price: l.price }));
    const sub = editSub;
    const disc = Math.min(Number(s.disc) || 0, sub);
    const taxRate = Number(s.taxRate) || 0;
    const tax = s.taxEnabled === false ? 0 : (sub - disc) * taxRate / 100;
    s.sub = sub;
    s.disc = disc;
    s.tax = tax;
    s.total = sub - disc + tax;
    DB.set('sales', SALES);
    PO_LINES = [];
    closeModal();
    toast(`تم تعديل فاتورة البيع ${s.no}`);
  },
  'print-receipt-pos': () => {
    const sale = CURRENT_RECEIPT;
    if (!sale) return;
    const area = $('#print-invoice');
    if (!area) return;
    area.innerHTML = buildInvoiceHTML(sale);
    document.body.classList.add('printing');
    setTimeout(() => { window.print(); setTimeout(() => document.body.classList.remove('printing'), 800); }, 120);
  },
  'print-customer': () => printCustomerRecord(),
  'send-customer': () => sendCustomerRecord(),
  'save-receipt': () => {
    const sale = CURRENT_RECEIPT;
    if (!sale) { toast('لا توجد فاتورة لحفظها', 'error'); return; }
    const exists = SALES.some(s => s.no === sale.no);
    if (!exists) SALES.unshift(sale);
    DB.set('sales', SALES);
    renderFinancialStats(); renderDashboardStats();
    toast(exists ? `الفاتورة ${sale.no} محفوظة بالفعل` : `تم حفظ الفاتورة ${sale.no}`);
  },
  'daily-close': () => toast('تم تأكيد الإغلاق اليومي وجاهز للمراجعة', 'success'),
  'daily-report': () => {
    const today = new Date();
    const dayMonth = today.toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long' });
    const isToday = d => (d || '').includes(dayMonth);
    const sales = SALES.filter(s => isToday(s.date));
    const repairsToday = REPAIRS.filter(r => isToday(r.date));
    const deliveredToday = sales.filter(s => s.kind === 'repair');
    const purchases = PURCHASES.filter(p => isToday(p.date));
    const payBreak = m => sales.reduce((a, s) => a + (Array.isArray(s.payments) ? s.payments.filter(p => p.method === m).reduce((x, p) => x + (Number(p.amount) || 0), 0) : (s.pay === m ? (Number(s.total) || 0) : 0)), 0);
    const salesTotal = sales.reduce((a, s) => a + (Number(s.total) || 0), 0);
    const purchasesTotal = purchases.reduce((a, p) => a + (Number(p.total) || 0), 0);
    const fullDate = today.toLocaleDateString('ar-SA-u-ca-gregory', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    const report = `
      <div class="daily-report">
        <div class="dr-head"><h2>تقرير اليوم</h2><p>${fullDate}</p></div>
        <div class="dr-stats">
          <div class="dr-stat"><i class="fa-solid fa-bag-shopping"></i><span>مبيعات اليوم</span><b>${cur(salesTotal)}</b><small>${sales.length} فاتورة</small></div>
          <div class="dr-stat"><i class="fa-solid fa-wrench"></i><span>إصلاحات اليوم</span><b>${repairsToday.length}</b><small>${repairsToday.filter(r => r.status === 'delivered').length} مسلَّم</small></div>
          <div class="dr-stat"><i class="fa-solid fa-cart-arrow-down"></i><span>مشتريات اليوم</span><b>${cur(purchasesTotal)}</b><small>${purchases.length} فاتورة</small></div>
        </div>
        <div class="dr-rows">
          <div><span>مبيعات نقداً</span><b>${cur(payBreak('نقداً'))}</b></div>
          <div><span>مبيعات بطاقة</span><b>${cur(payBreak('بطاقة'))}</b></div>
          <div><span>مبيعات تحويل</span><b>${cur(payBreak('تحويل'))}</b></div>
          <div><span>مبيعات آجلة (مستحقة)</span><b class="text-red">${cur(payBreak('آجل'))}</b></div>
          <div><span>إيرادات إصلاحات مسلَّمة</span><b>${cur(deliveredToday.reduce((a, s) => a + (Number(s.total) || 0), 0))}</b></div>
          <div><span>إجمالي المشتريات</span><b>${cur(purchasesTotal)}</b></div>
        </div>
        <div class="dr-net"><span>الصافي (مبيعات − مشتريات)</span><b>${cur(salesTotal - purchasesTotal)}</b></div>
      </div>`;
    openModal(`
      <div class="modal-head"><h3><i class="fa-solid fa-calendar-day"></i> تقرير اليوم</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
      <div class="modal-body">${report}</div>
      <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إغلاق</button><button class="btn btn-accent" data-action="print-report-today"><i class="fa-solid fa-print"></i> طباعة التقرير</button></div>
    `);
  },
  'print-report-today': () => {
    const area = $('#print-invoice');
    const body = document.querySelector('.daily-report');
    if (!area || !body) return;
    area.innerHTML = body.outerHTML;
    document.body.classList.add('printing');
    setTimeout(() => { window.print(); setTimeout(() => document.body.classList.remove('printing'), 800); }, 120);
  },
  'change-logo': () => { const f = $('#logo-file'); if (f) f.click(); },
  'remove-logo': () => {
    delete SETTINGS.logo;
    DB.set('settings', SETTINGS);
    applyLogo();
    toast('تمت إزالة الشعار والعودة للشعار الافتراضي');
  },
  'save-settings': () => {
    SETTINGS.company = ($('#s-company-name')?.value || SETTINGS.company).trim();
    SETTINGS.cr = ($('#s-cr')?.value || '').trim();
    SETTINGS.taxno = ($('#s-taxno')?.value || '').trim();
    SETTINGS.mobile = ($('#s-mobile')?.value || '').trim();
    SETTINGS.phone = ($('#s-phone')?.value || '').trim();
    SETTINGS.address = ($('#s-address')?.value || '').trim();
    SETTINGS.invPrefix = ($('#s-inv-prefix')?.value || 'INV-').trim();
    SETTINGS.repPrefix = ($('#s-rep-prefix')?.value || 'RP-').trim();
    const taxSel = $('#s-tax-rate');
    if (taxSel) {
      SETTINGS.tax = taxSel.value === 'custom'
        ? (parseFloat($('#s-tax-custom')?.value) || 0)
        : parseFloat(taxSel.value);
    }
    const curSel = $('#s-currency');
    SETTINGS.currency = curSel?.value || 'جنيه مصري (ج.م)';
    SETTINGS.print = {
      main: $('#s-print-main')?.value || 'thermal80',
      secondary: $('#s-print-secondary')?.value || 'none',
      barcode: $('#s-print-barcode')?.value || 'none',
      paper: $('#s-print-paper')?.value || '80mm',
      copies: Math.min(Math.max(parseInt($('#s-print-copies')?.value, 10) || 1, 1), 10),
      allowInvoice: $('#s-print-allow-invoice') ? $('#s-print-allow-invoice').checked : true,
      orderNote: $('#s-print-order-note') ? $('#s-print-order-note').checked : true,
    };
    SETTINGS.social = SOCIAL_PLATFORMS.map(p => ({
      id: p.id, name: p.name, icon: p.icon,
      enabled: document.getElementById('so-' + p.id) ? document.getElementById('so-' + p.id).checked : false,
      url: (document.getElementById('so-url-' + p.id)?.value || '').trim(),
    }));
    SETTINGS.receiptFooter = ($('#s-receipt-footer')?.value || '').trim();
    SETTINGS.printTerms = $('#s-print-terms') ? $('#s-print-terms').checked : true;
    SETTINGS.terms = [0, 1, 2, 3].map(i => ($('#s-term-' + i)?.value || '').trim()).filter(Boolean);
    DB.set('settings', SETTINGS);
    const newSym = curSymbol(SETTINGS.currency);
    sweepCurrency(CURRENCY, newSym);
    CURRENCY = newSym;
    renderCustomers(); renderRepairs(); renderProducts(); renderSuppliers(); renderReturns(); renderPO(); renderPurchases();
    const h = $('.r-company h2'); if (h) h.textContent = SETTINGS.company;
    toast('تم حفظ الإعدادات بنجاح — العملة: ' + newSym);
  },
  'print-copies-up': () => { const c = $('#s-print-copies'); if (c) c.value = Math.min(parseInt(c.value || '1', 10) + 1, 10); },
  'print-copies-down': () => { const c = $('#s-print-copies'); if (c) c.value = Math.max(parseInt(c.value || '1', 10) - 1, 1); },
  'save-draft': () => toast('تم حفظ المسودة', 'info'),
  'print-receipt': () => { showView('new-repair'); setTimeout(() => printDocument(buildRepairReceiptHTML()), 120); },
  'toggle-user-menu': (e) => { const dd = $('#usr-dd'); if (dd) dd.classList.toggle('open'); },
  'logout': async () => {
    try { await apiFetch('/logout', { method: 'POST' }); } catch (err) {}
    clearSession();
    location.replace('login.html');
  },
  'print-report': () => window.print(),
  'export-pdf': () => {
    const area = $('#print-invoice');
    if (!area) return;
    const company = SETTINGS.company || 'Senior Pro';
    const now = new Date().toLocaleDateString('ar-SA-u-ca-gregory', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    const salesTotal = SALES.reduce((a, s) => a + (Number(s.total) || 0), 0);
    const rows = SALES.slice(0, 12).map(s => `
      <tr><td>${esc(s.no)}</td><td>${esc(s.customer || 'عميل نقدي')}</td><td>${s.items.reduce((a, i) => a + i.qty, 0)}</td><td>${cur(s.total)}</td><td>${esc(s.pay)}</td></tr>`).join('');
    area.innerHTML = `
      <div class="inv-wrap">
        <div class="inv-head">
          <div class="inv-logo">${safeLogo(SETTINGS.logo) ? `<img src="${safeLogo(SETTINGS.logo)}" alt="logo" style="width:100%;height:100%;object-fit:contain;border-radius:inherit;background:#fff">` : 'ظˆ'}</div>
          <div class="inv-brand"><h1>${esc(company)}</h1><p>تقرير مبيعات</p></div>
          <div class="inv-title"><h2>تقرير PDF</h2><b>${now}</b></div>
        </div>
        <div class="inv-info"><div><span>عدد الفواتير</span><b>${SALES.length}</b></div><div><span>إجمالي المبيعات</span><b>${cur(salesTotal)}</b></div><div><span>الإصلاحات النشطة</span><b>${REPAIRS.length}</b></div><div><span>المنتجات في المخزون</span><b>${PRODUCTS.length}</b></div></div>
        <table class="inv-table">
          <thead><tr><th>الفاتورة</th><th>العميل</th><th>الكمية</th><th>الإجمالي</th><th>الدفع</th></tr></thead>
          <tbody>${rows || '<tr><td colspan="5" style="text-align:center;color:#94A3B8">لا توجد مبيعات مسجلة</td></tr>'}</tbody>
        </table>
        <div class="inv-foot"><p>تقرير مبيعات — Senior Pro</p><small>${esc(company)} · ${now}</small></div>
      </div>`;
    document.body.classList.add('printing');
    setTimeout(() => { window.print(); setTimeout(() => { area.innerHTML = ''; document.body.classList.remove('printing'); }, 800); }, 120);
  },
  'export-excel': () => {
    const view = $('.view.active');
    let rows = [];
    if (view && view.id === 'view-customers') {
      rows = [['العميل', 'رقم الجوال', 'العنوان', 'الإصلاحات', 'ديون سابقة', 'المدفوعات', 'النوع']];
      CUSTOMERS.forEach(c => rows.push([c.name, c.phone, c.address, c.repairs, c.debt || 0, c.payments, c.type]));
    } else if (view && view.id === 'view-repairs') {
      rows = [['رقم الإصلاح', 'العميل', 'الجهاز', 'الحالة', 'المبلغ', 'الدفع', 'التاريخ']];
      REPAIRS.forEach(r => rows.push([r.id, r.customer, r.device, STATUS[r.status]?.label || r.status, r.amount, r.payment, r.date]));
    } else if (view && view.id === 'view-inventory') {
      rows = [['المنتج', 'الباركود', 'الفئة', 'سعر البيع', 'سعر الشراء', 'الكمية', 'الحد الأدنى', 'أقل سعر للبيع']];
      PRODUCTS.forEach(p => rows.push([p.name, p.barcode, p.cat, p.sell, p.buy, p.qty, p.low, p.minSell ?? '']));
    } else if (view && view.id === 'view-damages') {
      rows = [['الفاتورة', 'التاريخ', 'بند الهالك', 'عدد الأصناف', 'الإجمالي']];
      filteredDamages().forEach(d => rows.push([d.no, d.dateText || d.date, d.type || 'الرئيسي', (Array.isArray(d.lines) ? d.lines.length : 0), damageTotal(d)]));
    } else if (view && view.id === 'view-purchases') {
      rows = [['رقم الفاتورة', 'المورد', 'الأصناف', 'الإجمالي', 'المدفوع', 'المتبقي', 'الحالة', 'التاريخ']];
      PURCHASES.forEach(p => rows.push([p.no, p.supplier, p.items, p.total, p.paid, p.left, p.status, p.date]));
    } else if (view && view.id === 'view-financial') {
      rows = [['نوع التقرير', 'القيمة']];
      rows.push(['إجمالي المبيعات', SALES.reduce((a, s) => a + (Number(s.total) || 0), 0)]);
      rows.push(['إجمالي المشتريات', PURCHASES.reduce((a, p) => a + (Number(p.total) || 0), 0)]);
      rows.push(['قيمة الهالك', DAMAGES.reduce((a, d) => a + damageTotal(d), 0)]);
    } else if (view && view.id === 'view-sales') {
      rows = [['الفاتورة', 'العميل', 'الدفع', 'الإجمالي', 'الكاشير', 'التاريخ']];
      SALES.forEach(s => rows.push([s.no, s.customer || 'عميل نقدي', s.pay, s.total, s.cashier || '', s.date]));
    } else {
      rows = [['نوع السجل', 'القيمة', 'ملاحظات']];
      rows.push(['العملاء', CUSTOMERS.length, '']);
      rows.push(['الإصلاحات', REPAIRS.length, '']);
      rows.push(['المنتجات', PRODUCTS.length, '']);
    }
    const csv = '\ufeff' + rows.map(r => r.map(cell => {
      const s = String(cell ?? '').replace(/"/g, '""');
      return /[",\n]/.test(s) ? '"' + s + '"' : s;
    }).join(',')).join('\r\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'warsha-pro-report-' + new Date().toISOString().slice(0, 10) + '.csv';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 500);
    toast('تم تصدير الملف بنجاح');
  },
  'view-customer': (e) => { const tr = e.target.closest('tr'); customerHistoryModal(tr.dataset.customer || tr.querySelector('b').textContent); },
  'edit-customer': (e) => {
    const tr = e.target.closest('tr');
    const c = CUSTOMERS.find(x => x.name === tr?.dataset.customer);
    customerEditModal(c || null);
  },
  'save-customer-edit': (e) => {
    const orig = e.target.closest('[data-customer]')?.dataset.customer || '';
    const idx = CUSTOMERS.findIndex(c => c.name === orig);
    if (idx < 0) { toast('العميل غير موجود', 'error'); return; }
    const name = ($('#ec-name')?.value || '').trim();
    const phone = ($('#ec-phone')?.value || '').trim();
    if (!name || !phone) { toast('يرجى إدخال الاسم ورقم الجوال', 'error'); return; }
    CUSTOMERS[idx].name = name;
    CUSTOMERS[idx].phone = phone;
    CUSTOMERS[idx].address = ($('#ec-address')?.value || '').trim();
    CUSTOMERS[idx].debt = Math.max(0, parseFloat($('#ec-debt')?.value) || 0);
    CUSTOMERS[idx].notes = ($('#ec-notes')?.value || '').trim();
    DB.set('customers', CUSTOMERS);
    closeModal(); renderCustomers(); renderRepairs();
    toast(`تم تحديث بيانات العميل «${name}»`);
  },
  'del-customer': (e) => {
    const tr = e.target.closest('tr');
    const key = tr?.dataset.customer;
    if (!key) return;
    const linked = REPAIRS.some(r => r.customer === key) || SALES.some(s => s.customer === key) || INSTALLMENTS.some(i => i.customer === key);
    if (linked && !confirm(`العميل «${key}» مرتبط بإصلاحات/فواتير. حذفُه سيُيتّم سجلاته. هل تريد المتابعة؟`)) return;
    if (!linked && !confirm(`هل تريد حذف العميل «${key}»؟`)) return;
    CUSTOMERS = CUSTOMERS.filter(c => c.name !== key);
    DB.set('customers', CUSTOMERS); renderCustomers(); toast('تم حذف العميل', 'error');
  },
  'edit-product': (e) => {
    const tr = e.target.closest('tr');
    const p = PRODUCTS.find(x => x.name === tr?.dataset.product);
    productAddModal(p || null);
  },
  'del-product': (e) => {
    const tr = e.target.closest('tr');
    const name = tr?.dataset.product;
    if (!name) return;
    if (!confirm(`هل تريد حذف المنتج «${name}»؟`)) return;
    PRODUCTS = PRODUCTS.filter(p => p.name !== name);
    DB.set('products', PRODUCTS);
    renderProducts();
    toast(`تم حذف المنتج «${name}»`, 'error');
  },
  'edit-device': (e) => {
    const tr = e.target.closest('tr');
    const d = DEVICES.find(x => x.device === (tr?.querySelector('.cell-user b')?.textContent || ''));
    deviceEditModal(d || null);
  },
  'save-device-edit': (e) => {
    const orig = e.target.closest('[data-device]')?.dataset.device || '';
    const idx = DEVICES.findIndex(x => x.device === orig);
    if (idx < 0) { toast('الجهاز غير موجود', 'error'); return; }
    DEVICES[idx].device = ($('#ed-device')?.value || '').trim() || DEVICES[idx].device;
    const imei = ($('#ed-imei')?.value || '').trim();
    DEVICES[idx].imei = imei || DEVICES[idx].imei;
    DEVICES[idx].serial = imei || DEVICES[idx].serial;
    DEVICES[idx].customer = ($('#ed-customer')?.value || '').trim() || DEVICES[idx].customer;
    DEVICES[idx].tech = ($('#ed-tech')?.value || '').trim();
    const st = $('#ed-status')?.value;
    if (st && STATUS[st]) DEVICES[idx].status = st;
    renderDevices();
    closeModal();
    toast(`تم تحديث بيانات الجهاز «${DEVICES[idx].device}»`);
  },
  'edit-repair': (e) => {
    const tr = e.target.closest('tr');
    const r = REPAIRS.find(x => x.id === tr?.dataset.id);
    if (!r) return;
    const stOpts = Object.keys(STATUS).map(k => `<option value="${k}" ${k === r.status ? 'selected' : ''}>${STATUS[k].label}</option>`).join('');
    openModal(`
      <div class="modal-head"><h3><i class="fa-solid fa-pen"></i> تعديل الإصلاح ${esc(r.id)}</h3><button class="icon-btn" data-action="close-modal"><i class="fa-solid fa-xmark"></i></button></div>
      <div class="modal-body">
        <div class="r-grid-2">
          <div class="field span-2"><label>العميل</label><i class="fa-solid fa-user"></i><input type="text" id="er-customer" value="${esc(r.customer)}"></div>
          <div class="field span-2"><label>الجهاز</label><i class="fa-solid fa-mobile-screen-button"></i><input type="text" id="er-device" value="${esc(r.device)}"></div>
          <div class="field"><label>الحالة</label><div class="select-wrap"><i class="fa-solid fa-chevron-down"></i><select id="er-status">${stOpts}</select></div></div>
          <div class="field"><label>طريقة الدفع</label><div class="select-wrap"><i class="fa-solid fa-chevron-down"></i><select id="er-payment">
            <option ${r.payment === 'نقداً' ? 'selected' : ''}>نقداً</option>
            <option ${r.payment === 'بطاقة' ? 'selected' : ''}>بطاقة</option>
            <option ${r.payment === 'تحويل' ? 'selected' : ''}>تحويل</option>
            <option ${r.payment === 'آجل' ? 'selected' : ''}>آجل</option>
          </select></div></div>
          <div class="field"><label>المبلغ (${CURRENCY})</label><i class="fa-solid fa-money-bill-wave"></i><input type="number" id="er-amount" value="${esc(r.amount)}"></div>
        </div>
      </div>
      <div class="modal-foot"><button class="btn btn-ghost" data-action="close-modal">إلغاء</button><button class="btn btn-accent" data-action="save-repair-edit" data-id="${esc(r.id)}"><i class="fa-solid fa-check"></i> حفظ التغييرات</button></div>
    `);
  },
  'save-repair-edit': (e) => {
    const id = e.target.closest('[data-id]')?.dataset.id;
    const r = REPAIRS.find(x => x.id === id);
    if (!r) return;
    r.customer = ($('#er-customer')?.value || '').trim() || r.customer;
    r.device = ($('#er-device')?.value || '').trim() || r.device;
    r.status = $('#er-status')?.value || r.status;
    r.payment = $('#er-payment')?.value || r.payment;
    const amt = parseFloat($('#er-amount')?.value);
    if (!isNaN(amt)) { r.amount = amt; r.left = Math.max(amt - (Number(r.paid) || 0), 0); }
    let rev = r.revenueNo;
    if (r.status === 'delivered' && !r.revenueNo) rev = recordRepairRevenue(r);
    DB.set('repairs', REPAIRS);
    renderRepairs();
    updateTrackCard(r);
    closeModal();
    toast(`تم تحديث الإصلاح ${r.id} — الحالة: ${STATUS[r.status].label}` + (rev ? ` — سُجل الإيراد برقم ${rev}` : ''));
  },
  'track-repair': (e) => { const tr = e.target.closest('tr'); const r = REPAIRS.find(x => x.id === tr.dataset.id); updateTrackCard(r); const card = $('#track-card'); card.scrollIntoView({ behavior: 'smooth', block: 'center' }); },
  'add-installment': () => installmentAddModal(null),
  'view-installment': (e) => { const no = e.target.closest('[data-ins]')?.dataset.ins; installmentViewModal(no); },
  'pay-installment': (e) => { const no = e.target.closest('[data-ins]')?.dataset.ins; installmentPayModal(no); },
  'print-installment': (e) => { const no = e.target.closest('[data-ins]')?.dataset.ins; const plan = INSTALLMENTS.find(x => x.no === no); if (plan) printDocument(buildInstallmentHTML(plan)); },
  'save-installment': (e) => {
    const no = e.target.closest('[data-ins]')?.dataset.ins || '';
    const customer = ($('#ins-customer')?.value || '').trim();
    const itemsBox = $('#ins-items');
    const items = itemsBox ? [...itemsBox.querySelectorAll('.ins-item')].map(r => ({
      name: r.dataset.name,
      qty: Math.max(1, parseInt(r.querySelector('.ins-item-qty')?.value, 10) || 1),
      price: Math.max(0, parseFloat(r.querySelector('.ins-item-price')?.value) || 0)
    })) : [];
    const amount = items.length ? items.reduce((s, it) => s + it.qty * it.price, 0) : (parseFloat($('#ins-amount')?.value) || 0);
    const device = items.length ? (items.length === 1 ? items[0].name : items[0].name + ' +' + (items.length - 1)) : '';
    const down = Math.min(Math.max(parseFloat($('#ins-down')?.value) || 0, 0), amount);
    const months = Math.min(120, Math.max(1, parseInt($('#ins-months')?.value) || 1));
    if (!customer || !items.length || amount <= 0) { toast('يرجى إدخال العميل وإضافة منتج واحد على الأقل', 'error'); return; }
    const firstDue = $('#ins-first-due')?.value || '';
    const notes = ($('#ins-notes')?.value || '').trim();
    const rate = Math.min(1000, Math.max(0, parseFloat($('#ins-rate')?.value) || 0));
    const perMonth = Math.ceil(insFinanced({ amount, down, rate }) / months);
    if (no) {
      const idx = INSTALLMENTS.findIndex(x => x.no === no);
      if (idx < 0) { toast('الخطة غير موجودة', 'error'); return; }
      INSTALLMENTS[idx].customer = customer;
      INSTALLMENTS[idx].items = items;
      INSTALLMENTS[idx].device = device;
      INSTALLMENTS[idx].amount = amount;
      INSTALLMENTS[idx].down = down;
      INSTALLMENTS[idx].rate = rate;
      INSTALLMENTS[idx].months = months;
      INSTALLMENTS[idx].perMonth = perMonth;
      INSTALLMENTS[idx].firstDue = firstDue;
      INSTALLMENTS[idx].notes = notes;
      if (insRemaining(INSTALLMENTS[idx]) === 0) INSTALLMENTS[idx].status = 'مكتمل';
      DB.set('installments', INSTALLMENTS);
      renderInstallments();
      closeModal();
      toast(`تم تحديث خطة الأقساط ${no}`);
    } else {
      const newPlan = {
        no: 'INS-' + String(nextNum('', INSTALLMENTS)).padStart(3, '0'), customer, items, device, amount, down, rate, months, perMonth, fee: 0,
        firstDue, created: new Date().toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' }),
        notes, status: 'نشط', payments: []
      };
      INSTALLMENTS.push(newPlan);
      DB.set('installments', INSTALLMENTS);
      renderInstallments();
      closeModal();
      toast(`تم إنشاء خطة التقسيط ${newPlan.no}`);
    }
  },
  'save-installment-pay': (e) => {
    const no = e.target.closest('[data-ins]')?.dataset.ins;
    const plan = INSTALLMENTS.find(x => x.no === no);
    if (!plan) return;
    const amount = parseFloat($('#pay-amount')?.value) || 0;
    if (amount <= 0) { toast('يرجى إدخال مبلغ الدفعة', 'error'); return; }
    const remaining = insRemaining(plan);
    if (amount > remaining) { toast('مبلغ الدفعة أكبر من المتبقي', 'error'); return; }
    const rawDate = $('#pay-date')?.value || new Date().toISOString().slice(0, 10);
    const pd = new Date(rawDate + 'T00:00:00');
    const dateStr = isNaN(pd.getTime()) ? rawDate : pd.toLocaleDateString('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric' });
    plan.payments = plan.payments || [];
    plan.payments.push({ no: nextNum('PMT-', plan.payments), date: dateStr, amount, note: ($('#pay-note')?.value || '').trim() });
    if (insRemaining(plan) === 0) plan.status = 'مكتمل';
    DB.set('installments', INSTALLMENTS);
    renderInstallments();
    closeModal();
    toast(`تم تسجيل دفعة ${cur(amount)} على ${no}`);
  },
  'del-installment': (e) => {
    const no = e.target.closest('[data-ins]')?.dataset.ins;
    const plan = INSTALLMENTS.find(x => x.no === no);
    if (!plan) return;
    if (!confirm(`حذف خطة الأقساط ${no} للعميل «${plan.customer}»؟`)) return;
    INSTALLMENTS = INSTALLMENTS.filter(x => x.no !== no);
    DB.set('installments', INSTALLMENTS);
    renderInstallments();
    toast('تم حذف خطة الأقساط', 'error');
  },
  'export-installments': () => {
    const head = ['الخطة', 'العميل', 'الجهاز', 'إجمالي المبلغ', 'المقدم', 'الدفعة الشهرية', 'المدة', 'المحصل', 'المتبقي', 'الحالة'];
    const lines = INSTALLMENTS.map(i => [i.no, i.customer, i.device, i.amount, i.down, i.perMonth, i.months, insPaid(i), insRemaining(i), insStatus(i)]);
    const csv = '\uFEFF' + [head, ...lines].map(r => r.join(',')).join('\r\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'installments-' + new Date().toISOString().slice(0, 10) + '.csv';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 500);
    toast('تم تصدير ملف الأقساط بنجاح');
  },
};

/* ---------- Event binding ---------- */
document.addEventListener('click', (e) => {
  const viewEl = e.target.closest('[data-view]');
  if (viewEl) { showView(viewEl.dataset.view); return; }
  const actEl = e.target.closest('[data-action]');
  if (actEl) {
    const fn = ACTIONS[actEl.dataset.action];
    if (fn) fn(e);
    return;
  }
  const dd = e.target.closest('.dropdown');
  if (dd) { dd.classList.toggle('open'); const menu = $('.dropdown-menu', dd); if (menu) e.stopPropagation(); }
  const fabItem = e.target.closest('.fab-item');
  if (!fabItem) { const w = $('.fab-wrap'); if (w.classList.contains('open') && !e.target.closest('.fab-wrap')) { w.classList.remove('open'); $('#fab').classList.remove('open'); } }
});

document.addEventListener('click', (e) => {
  if (!e.target.closest('.dropdown')) { $$('.dropdown.open').forEach(d => d.classList.remove('open')); }
  if (!e.target.closest('.usr-dd')) { const u = $('#usr-dd'); if (u) u.classList.remove('open'); }
  if (!e.target.closest('.notif-panel') && !e.target.closest('[data-action="toggle-notif"]')) {
    $('#notif-panel').classList.remove('open');
  }
});

$('#sidebar-overlay').addEventListener('click', closeSidebar);
backdrop.addEventListener('click', closeModal);

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') { closeModal(); closeSidebar(); }
  if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); $('#global-search').focus(); }
});

/* Inventory tabs */
$$('.tab').forEach(t => t.addEventListener('click', () => {
  $$('.tab').forEach(x => x.classList.remove('active'));
  t.classList.add('active');
  $$('.tab-panel').forEach(p => p.classList.toggle('active', p.dataset.panel === t.dataset.tab));
  if (t.dataset.tab === 'quotes') renderQuotes();
  if (t.dataset.tab === 'orders') renderOrders();
  if (t.dataset.tab === 'returns') renderPosReturns();
  if (t.dataset.tab === 'purchase') renderPO();
}));

/* Settings nav */
$$('.snav').forEach(b => b.addEventListener('click', () => {
  $$('.snav').forEach(x => x.classList.remove('active'));
  b.classList.add('active');
  $$('.snav-panel').forEach(p => p.classList.toggle('active', p.dataset.spanel === b.dataset.snav));
  if (b.dataset.snav === 'barcode') { populateLabelProductSelect(); setTimeout(renderLabelPreview, 40); }
}));

/* Status chips filter */
$$('.chip-chip').forEach(c => c.addEventListener('click', () => {
  $$('.chip-chip').forEach(x => x.classList.remove('active'));
  c.classList.add('active');
  renderRepairs(c.dataset.status);
}));

/* Customer search */
$('#customer-search').addEventListener('input', (e) => {
  const q = e.target.value.trim();
  $$('#customers-table tr').forEach(tr => {
    tr.style.display = tr.dataset.customer.includes(q) ? '' : 'none';
  });
});

/* Repair search */
$('#repair-search').addEventListener('input', (e) => {
  const q = e.target.value.trim();
  const matched = REPAIRS.find(x => x.id === q || x.barcode === q);
  if (matched && !document.querySelector('#repairs-table tr[data-id="' + matched.id + '"]')) {
    $$('.chip-chip').forEach(x => x.classList.remove('active'));
    const all = document.querySelector('.chip-chip[data-status="all"]');
    if (all) all.classList.add('active');
    renderRepairs('all');
  }
  $$('#repairs-table tr').forEach(tr => {
    tr.style.display = tr.textContent.includes(q) ? '' : 'none';
  });
});

$('#repair-search').addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  const q = e.target.value.trim();
  const r = REPAIRS.find(x => x.id === q || x.barcode === q);
  if (r) {
    if (!document.querySelector('#repairs-table tr[data-id="' + r.id + '"]')) {
      $$('.chip-chip').forEach(x => x.classList.remove('active'));
      const all = document.querySelector('.chip-chip[data-status="all"]');
      if (all) all.classList.add('active');
      renderRepairs('all');
    }
    const tr = document.querySelector('#repairs-table tr[data-id="' + r.id + '"]');
    if (tr) { tr.style.display = ''; tr.scrollIntoView({ behavior: 'smooth', block: 'center' }); tr.classList.add('row-flash'); setTimeout(() => tr.classList.remove('row-flash'), 1600); }
    updateTrackCard(r);
    toast('تم العثور على ' + r.id + ' — ' + (STATUS[r.status]?.label || r.status));
  } else {
    toast('لم يتم العثور على الإصلاح', 'error');
  }
});

/* Track input */
$('#track-input').addEventListener('keydown', (e) => {
  if (e.key !== 'Enter') return;
  const q = e.target.value.trim();
  const r = REPAIRS.find(x => x.id === q || x.barcode === q);
  if (r) { updateTrackCard(r); toast(`تم العثور على ${r.id}`); }
  else toast('لم يتم العثور على الإصلاح', 'error');
});

/* Track card quick status update */
const trackStatusSel = $('#track-status');
if (trackStatusSel) trackStatusSel.addEventListener('change', () => {
    const r = REPAIRS.find(x => x.id === CURRENT_TRACK_ID);
    if (!r) return;
    setRepairStatus(r, trackStatusSel.value);
  });

/* Pricing calc */
let LAST_TOTAL = 0;
let CURRENT_RECEIPT_REPAIR = null;
function calcPricing() {
  const cost = parseFloat($('#repair-cost').value) || 0;
  const paid = parseFloat($('#paid-amount').value) || 0;
  const fee = 50;
  const partsTotal = REPAIR_PARTS.reduce((s, p) => s + (Number(p.price) || 0) * p.qty, 0);
  const total = cost + fee + partsTotal;
  const remaining = Math.max(total - paid, 0);
  LAST_TOTAL = total;
  $('#remaining-amount').value = remaining;
  $('#total-label').textContent = cur(total);
  const paidPct = total > 0 ? Math.round((Math.min(paid, total) / total) * 100) : 0;
  const leftPct = 100 - paidPct;
  const setW = (id, w) => { const el = document.getElementById(id); if (el) el.style.width = w + '%'; };
  setW('mb-paid', paidPct); setW('mb-left', leftPct);
  const setT = (id, txt) => { const el = document.getElementById(id); if (el) el.textContent = txt; };
  setT('mini-paid', `المدفوع: ${cur(Math.min(paid, total))}`);
  setT('mini-left', `المتبقي: ${cur(remaining)}`);
}
['repair-cost', 'paid-amount'].forEach(id => {
  const el = document.getElementById(id);
  if (el) el.addEventListener('input', calcPricing);
});

/* Repair row click -> track */
$('#repairs-table').addEventListener('click', (e) => {
  const row = e.target.closest('.repair-row');
  if (row && !e.target.closest('button')) updateTrackCard(REPAIRS.find(r => r.id === row.dataset.id));
});

/* Global search enter -> repairs */
$('#global-search').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    const q = e.target.value.trim();
    showView('repairs');
    if (q) { $('#repair-search').value = q; $('#repair-search').dispatchEvent(new Event('input')); }
  }
});

/* Barcode scan input enter */
document.addEventListener('keydown', (e) => {
  if (e.target && e.target.id === 'sc-barcode' && e.key === 'Enter') ACTIONS['scan-find']();
});

/* Print settings population */
function populatePrintSettings() {
  const p = SETTINGS.print || {};
  const setSel = (id, v) => { const el = $(id); if (el && v) el.value = v; };
  setSel('#s-print-main', p.main);
  setSel('#s-print-secondary', p.secondary);
  setSel('#s-print-barcode', p.barcode);
  setSel('#s-print-paper', p.paper);
  const c = $('#s-print-copies'); if (c) c.value = p.copies ?? 1;
  const ai = $('#s-print-allow-invoice'); if (ai) ai.checked = p.allowInvoice !== false;
  const on = $('#s-print-order-note'); if (on) on.checked = p.orderNote !== false;
}

/* Print size selector */
const PRINT_SIZES = { 'A4': 'A4', 'A5': 'A5', 'A6': 'A6', 'حراري 80mm': '80mm 297mm' };
$$('.print-size button').forEach(b => b.addEventListener('click', () => {
  $$('.print-size button').forEach(x => x.classList.remove('active'));
  b.classList.add('active');
  let el = $('#print-size-style');
  if (!el) { el = document.createElement('style'); el.id = 'print-size-style'; document.head.appendChild(el); }
  const size = PRINT_SIZES[b.textContent.trim()] || 'A4';
  el.textContent = size === 'A4' ? '' : `@media print { @page { size: ${size}; margin: 9mm; } }`;
}));

/* ---------- Init ---------- */
document.addEventListener('DOMContentLoaded', async () => {
  /* Restore the desktop sidebar collapse state the user last chose. */
  try {
    if (!window.matchMedia('(max-width: 860px)').matches &&
        localStorage.getItem('senior-sidebar-collapsed') === '1') {
      document.body.classList.add('sidebar-collapsed');
    }
  } catch (e) {}

  const ok = await DB.init();
  if (!ok) return; // session expired → already redirecting to login

  // Re-validate the session against the server and refresh role/permissions.
  try {
    const res = await apiFetch('/session');
    if (res.ok) {
      const data = await res.json();
      if (data && data.user) {
        SESSION.user = data.user.user;
        SESSION.name = data.user.name;
        SESSION.role = data.user.role;
        SESSION.perms = data.user.perms || [];
        persistSession();
      }
    }
  } catch (e) {}

  CUSTOMERS = DB.get('customers', SAMPLE_CUSTOMERS);
  REPAIRS = DB.get('repairs', SAMPLE_REPAIRS);
  PRODUCTS = DB.get('products', SAMPLE_PRODUCTS);
  PURCHASES = DB.get('purchases', SAMPLE_PURCHASES);
  PORDERS = DB.get('porders', SAMPLE_PORDERS);
  SUPPLIERS = DB.get('suppliers', SAMPLE_SUPPLIERS);
  SETTINGS = { ...DEFAULT_SETTINGS, ...(DB.get('settings', {}) || {}) };
  SALES = DB.get('sales', []);
  QUOTES = DB.get('quotes', []);
  ORDERS = DB.get('orders', []);
  RETURNS = DB.get('returns', SAMPLE_RETURNS);
  EMPLOYEES = DB.get('employees', SAMPLE_EMPLOYEES);
  CATEGORIES = DB.get('categories', SAMPLE_CATEGORIES);
  applySettingsMigrations();

  const now = new Date();
  const ar = now.toLocaleDateString('ar-SA-u-ca-gregory', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  $('#today-date').textContent = ar;
  $('#dash-date').textContent = ar;

  if (SESSION) {
    const first = (SESSION.name || 'مدير النظام').trim().split(' ')[0];
    const greet = $('#dash-greet'); if (greet) greet.textContent = 'مرحباً بك، ' + first + ' 👋';
    const setTxt = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    setTxt('top-name', SESSION.name); setTxt('um-name', SESSION.name);
    setTxt('top-role', SESSION.role); setTxt('um-role', SESSION.role);
  }

  const signCust = $('#sign-customer');
  const custName = $('#f-customer-name');
  if (custName) {
    if (signCust && custName.value.trim()) signCust.textContent = custName.value.trim();
    custName.addEventListener('input', () => { if (signCust) signCust.textContent = custName.value.trim() || 'توقيع العميل'; });
  }
  const sName = (SESSION && SESSION.name) || '';
  if (sName) {
    const sr = $('#sign-receiver'); if (sr) sr.textContent = sName;
    const st = $('#sign-tech'); if (st) st.textContent = sName;
  }

  CURRENCY = curSymbol(SETTINGS.currency) || 'ج.م';
  renderCustomers();
  renderRepairs();
  renderDevices();
  renderProducts();
  renderSuppliers();
  renderCategories();
  renderStock();
  renderPO();
  renderPurchases();
  renderInstallments();
  renderReturns();
  renderDamages();
  renderEmployees();
  renderUsers();
  renderPOS();
  renderCart();
  populatePosCustomers();
  populateRepairPartsSelect();
  populatePrintSettings();
  populateSocialSettings();
  populateInvoiceSettings();
  populateCompanySettings();
  populateLicensePanel();
  enforceLicense();
  initUpdatePanel();
  applyLogo();
  resetTrackCard();
  refreshLiveData();

  const posSearch = $('#pos-search');
  if (posSearch) posSearch.addEventListener('input', () => { POS_FILTER.q = posSearch.value; renderPOS(); });

  const insSegs = document.querySelectorAll('#view-installments .seg-btn');
  if (insSegs.length) insSegs.forEach(b => b.addEventListener('click', () => {
    insSegs.forEach(x => x.classList.remove('active'));
    b.classList.add('active');
    renderInstallments(b.textContent === 'الكل' ? 'all' : b.textContent === 'نشطة' ? 'نشط' : 'مكتمل');
  }));
  const posDisc = $('#pos-discount');
  if (posDisc) posDisc.addEventListener('input', () => renderCart());
  const posDiscType = $('#pos-discount-type');
  if (posDiscType) posDiscType.addEventListener('change', () => renderCart());
  const posTaxToggle = $('#pos-tax-toggle');
  if (posTaxToggle) posTaxToggle.addEventListener('change', () => renderCart());

  const dmAll = $('#dm-all');
  const dmFrom = $('#dm-from');
  const dmTo = $('#dm-to');
  if (dmFrom && dmTo) {
    const now = new Date();
    const first = new Date(now.getFullYear(), now.getMonth(), 1);
    dmFrom.value = new Date(first.getTime() - first.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    dmTo.value = todayISO();
  }
  const syncDmDates = () => {
    const off = !!(dmAll && dmAll.checked);
    if (dmFrom) dmFrom.disabled = off;
    if (dmTo) dmTo.disabled = off;
  };
  if (dmAll) dmAll.addEventListener('change', syncDmDates);
  syncDmDates();
  [dmFrom, dmTo].forEach(el => { if (el) el.addEventListener('change', () => { DM_FILTER.all = false; if (dmAll) dmAll.checked = false; syncDmDates(); }); });
  document.addEventListener('input', (e) => {
    if (e.target.classList && e.target.classList.contains('pay-amt')) renderCart();
  });

  const bgValue = $('#bg-value');
  if (bgValue) { bgValue.addEventListener('input', (e) => { BG_STATE.value = e.target.value; renderBarcodeGen(); }); }
  const bgType = $('#bg-type');
  if (bgType) { bgType.addEventListener('change', (e) => { BG_STATE.type = e.target.value; renderBarcodeGen(); }); }
  const bgSize = $('#bg-size');
  if (bgSize) { bgSize.addEventListener('change', (e) => { BG_STATE.size = e.target.value; renderBarcodeGen(); }); }
  populateBarcodeProductSelect();
  setupBarcodeLivePreview();
  renderBarcodeGen();
  initLabelDesigner();
  const bcReadInp = $('#bc-read-input');
  if (bcReadInp) bcReadInp.addEventListener('keydown', (e) => { if (e.key === 'Enter') bcReadResult(bcReadInp.value); });

  const importFile = $('#import-products-file');
  if (importFile) importFile.addEventListener('change', (e) => { handleProductsImport(e.target.files[0]); e.target.value = ''; });
  const prodSearch = $('#product-search');
  if (prodSearch) prodSearch.addEventListener('input', (e) => {
    const q = e.target.value.trim().toLowerCase();
    $$('#products-table tr').forEach(tr => {
      tr.style.display = !q || tr.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });
  
  /* Barcode reader auto-focus enhancement for product search */
  if (prodSearch) {
    prodSearch.addEventListener('focus', () => {
      prodSearch.select();
    });
  }

  updateReceiptCodes();

  initCharts();

  applyPermissions();
  updateDashPrivacyBtn();

  const initial = location.hash.replace('#/', '');
  if (initial && $('#view-' + initial)) showView(initial);
});

