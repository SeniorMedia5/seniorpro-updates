'use strict';
/* ============================================================
   Senior Pro — Database seed / password reset
   Usage:
     node seed.js                     → create the store + default admin if missing
     node seed.js admin NewPass123    → create/reset the admin password
   ============================================================ */

const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');
const paths = require('./lib/paths');

paths.ensureDirs();
/* Same resolution as the server: data dir DB, else the old in-app DB, else DB_FILE env. */
const DB_FILE = process.env.DB_FILE
  || (fs.existsSync(path.join(paths.dirs.data, 'senior.db')) ? path.join(paths.dirs.data, 'senior.db') : null)
  || (fs.existsSync(path.join(__dirname, 'senior.db')) ? path.join(__dirname, 'senior.db') : path.join(paths.dirs.data, 'senior.db'));
const db = new sqlite3.Database(DB_FILE);

const ALL_VIEWS = [
  'dashboard', 'customers', 'repairs', 'new-repair', 'devices', 'inventory',
  'sales', 'installments', 'purchases', 'financial', 'reports', 'employees', 'settings'
];

const DEFAULT_SETTINGS = {
  company: 'Senior Pro',
  invPrefix: 'INV-',
  repPrefix: 'RP-',
  tax: 15,
  currency: 'جنيه مصري (ج.م)',
  cr: '',
  taxno: '',
  mobile: '01005171136',
  phone: '01279599146',
  address: 'مصر - اسكندرية'
};

const run = (sql, params = []) => new Promise((resolve, reject) => {
  db.run(sql, params, function (err) { err ? reject(err) : resolve(this); });
});
const getRow = (sql, params = []) => new Promise((resolve, reject) => {
  db.get(sql, params, (err, row) => err ? reject(err) : resolve(row));
});

async function readDoc(key) {
  const row = await getRow('SELECT data FROM store WHERE key = ?', [key]);
  if (!row) return null;
  try { return JSON.parse(row.data); } catch (e) { return null; }
}

async function writeDoc(key, value) {
  await run(
    `INSERT INTO store (key, data, updated) VALUES (?, ?, ?)
     ON CONFLICT(key) DO UPDATE SET data = excluded.data, updated = excluded.updated`,
    [key, JSON.stringify(value), Date.now()]
  );
}

(async () => {
  try {
    await run(`CREATE TABLE IF NOT EXISTS store (
      key TEXT PRIMARY KEY,
      data TEXT NOT NULL,
      updated INTEGER NOT NULL
    )`);

    const username = process.argv[2] || 'admin';
    const password = process.argv[3] || 'admin123';
    const passHash = await bcrypt.hash(password, 10);

    const users = await readDoc('users');
    const list = Array.isArray(users) ? users : [];
    const idx = list.findIndex(u => String(u.user).toLowerCase() === username.toLowerCase());

    if (idx > -1) {
      list[idx].passHash = passHash;
      list[idx].status = 'نشط';
      await writeDoc('users', list);
      console.log(`تم تحديث كلمة المرور للمستخدم: ${username}`);
    } else {
      list.push({
        user: username,
        name: username === 'admin' ? 'مدير النظام' : username,
        role: username === 'admin' ? 'مدير النظام' : 'كاشير',
        email: '',
        status: 'نشط',
        perms: username === 'admin' ? ALL_VIEWS.slice() : [],
        passHash,
        created: Date.now()
      });
      await writeDoc('users', list);
      console.log(`تم إنشاء المستخدم: ${username}`);
    }

    if (!await readDoc('settings')) await writeDoc('settings', DEFAULT_SETTINGS);

    console.log(`اسم الدخول: ${username}`);
    console.log(`كلمة المرور: ${password}`);
    if (password === 'admin123') console.log('⚠  غيّر كلمة المرور الافتراضية من شاشة المستخدمين.');
    db.close();
  } catch (err) {
    console.error('خطأ:', err.message);
    db.close();
    process.exitCode = 1;
  }
})();
